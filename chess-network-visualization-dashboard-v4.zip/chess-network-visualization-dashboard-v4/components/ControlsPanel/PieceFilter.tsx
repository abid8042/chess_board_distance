
import React from 'react';
import { AVAILABLE_PIECE_TYPES } from '../../types'; // Using AVAILABLE_PIECE_TYPES

interface PieceFilterProps {
  selectedPieceTypes: string[]; // Changed from number[] to string[]
  selectedPieceColor: string | null;
  onPieceTypeChange: (types: string[]) => void; // Changed
  onPieceColorChange: (color: string | null) => void;
  // pieceTypeMap and pieceTypeIds are replaced by AVAILABLE_PIECE_TYPES
  pieceColorMap: { [key: string]: string };
}

const PieceFilter: React.FC<PieceFilterProps> = ({
  selectedPieceTypes,
  selectedPieceColor,
  onPieceTypeChange,
  onPieceColorChange,
  pieceColorMap
}) => {
  const handleTypeChange = (typeName: string) => { // typeName is now string e.g. "Pawn"
    const newSelectedTypes = selectedPieceTypes.includes(typeName)
      ? selectedPieceTypes.filter(t => t !== typeName)
      : [...selectedPieceTypes, typeName];
    onPieceTypeChange(newSelectedTypes);
  };

  return (
    <div className="space-y-3">
      <div>
        <p className="block text-xs font-medium text-slate-300 mb-1.5" title="Show only nodes (squares) that are currently occupied by the selected piece types (e.g., Pawns, Knights).">Filter by Piece Type</p>
        <div className="grid grid-cols-2 gap-x-2 gap-y-1.5">
          {AVAILABLE_PIECE_TYPES.map(typeName => ( // Iterate over string names
            <label 
              key={typeName} 
              className="flex items-center space-x-2 cursor-pointer group p-1 rounded-md hover:bg-slate-500/60 transition-colors"
              title={`Toggle filter for ${typeName}s. Check to include ${typeName}s, uncheck to exclude.`}
            >
              <input
                type="checkbox"
                checked={selectedPieceTypes.includes(typeName)}
                onChange={() => handleTypeChange(typeName)}
                className="form-checkbox h-3.5 w-3.5 text-sky-400 bg-slate-500 border-slate-400 rounded focus:ring-1 focus:ring-sky-400 focus:ring-offset-1 focus:ring-offset-slate-600"
                aria-label={`Filter by piece type ${typeName}`}
              />
              <span className="text-xs text-slate-300 group-hover:text-sky-300">{typeName}</span>
            </label>
          ))}
        </div>
      </div>
      <div>
        <p className="block text-xs font-medium text-slate-300 mb-1.5" title="Show only nodes (squares) that are currently occupied by pieces of the selected color (White or Black), or any color.">Filter by Piece Color</p>
        <div className="flex flex-wrap gap-x-3 gap-y-1.5">
          <label 
            className="flex items-center space-x-2 cursor-pointer group p-1 rounded-md hover:bg-slate-500/60 transition-colors"
            title="Show pieces of any color (both White and Black pieces that match other filters)."
          >
            <input
              type="radio"
              name="pieceColor"
              value=""
              checked={selectedPieceColor === null}
              onChange={() => onPieceColorChange(null)}
              className="form-radio h-3.5 w-3.5 text-sky-400 bg-slate-500 border-slate-400 focus:ring-1 focus:ring-sky-400 focus:ring-offset-1 focus:ring-offset-slate-600"
              aria-label="Filter by any piece color"
            />
            <span className="text-xs text-slate-300 group-hover:text-sky-300">Any</span>
          </label>
          {Object.entries(pieceColorMap).map(([value, label]) => (
            <label 
              key={value} 
              className="flex items-center space-x-2 cursor-pointer group p-1 rounded-md hover:bg-slate-500/60 transition-colors"
              title={`Show only ${label} pieces that match other active filters.`}
            >
              <input
                type="radio"
                name="pieceColor"
                value={value}
                checked={selectedPieceColor === value}
                onChange={() => onPieceColorChange(value)}
                className="form-radio h-3.5 w-3.5 text-sky-400 bg-slate-500 border-slate-400 focus:ring-1 focus:ring-sky-400 focus:ring-offset-1 focus:ring-offset-slate-600"
                aria-label={`Filter by piece color ${label}`}
              />
              <span className="text-xs text-slate-300 group-hover:text-sky-300">{label}</span>
            </label>
          ))}
        </div>
      </div>
    </div>
  );
};

export default React.memo(PieceFilter);
