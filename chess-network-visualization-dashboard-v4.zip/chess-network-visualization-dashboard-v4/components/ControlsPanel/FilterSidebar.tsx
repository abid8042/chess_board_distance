
import React from 'react';
import { FiltersState, DataRangesForFilters, FilterMetricKey, ProcessedNode, NodeNumericMetricKey } from '../../types';
import { DEGREE_CENTRALITY_METRICS_UI, BETWEENNESS_CENTRALITY_METRICS_UI, CLOSENESS_CENTRALITY_METRICS_UI, OTHER_NODE_METRICS_UI } from '../../constants';
import NodeSearch from './NodeSearch';
import PieceFilter from './PieceFilter';
import CommunityComponentFilter from './CommunityComponentFilter';
// DegreeCentralityFilter and GraphMetricNodeFilters are still used but their content is now more structured
import RangeSlider from '../RangeSlider';
import { PIECE_COLOR_MAP, AVAILABLE_PIECE_TYPES } from '../../types';


const ChevronDownIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={`w-4 h-4 transition-transform duration-200 ${className}`} viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
    <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
  </svg>
);

interface FilterCollapsibleSectionProps {
  title: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
  actionButton?: React.ReactNode; 
  tooltip?: string; 
}

const FilterCollapsibleSection: React.FC<FilterCollapsibleSectionProps> = ({ title, children, defaultOpen = false, actionButton, tooltip }) => {
  const [isOpen, setIsOpen] = React.useState(defaultOpen);

  return (
    <div className="bg-slate-600/60 rounded-lg border border-slate-500/70">
      <div className={`flex justify-between items-center w-full p-2.5 text-left hover:bg-slate-500/70 transition-colors duration-150 ${isOpen ? 'rounded-t-lg' : 'rounded-lg'}`}>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex-grow flex items-center text-xs font-medium text-slate-200 focus:outline-none focus-visible:ring-1 focus-visible:ring-sky-400"
          aria-expanded={isOpen}
          title={tooltip || `Click to ${isOpen ? 'collapse' : 'expand'} ${title} section`}
        >
          <span>{title}</span>
          <ChevronDownIcon className={`${isOpen ? 'transform rotate-180' : ''} text-slate-400 ml-1.5`} />
        </button>
        {actionButton && <div className="flex-shrink-0 ml-2">{actionButton}</div>}
      </div>
      {isOpen && (
        <div className="p-2.5 border-t border-slate-500/70 space-y-2.5">
          {children}
        </div>
      )}
    </div>
  );
};


interface MetricFilterGroupProps {
  metrics: { key: NodeNumericMetricKey; label: string; tooltip?: string }[];
  filters: FiltersState;
  dataRanges: DataRangesForFilters;
  onNumericFilterChange: (filterKey: FilterMetricKey, newRange: { min?: number; max?: number }) => void;
}

const MetricFilterGroup: React.FC<MetricFilterGroupProps> = ({ metrics, filters, dataRanges, onNumericFilterChange }) => {
  return (
    <div className="space-y-2.5">
      {metrics.map(metric => {
        const filterKey = metric.key; // This is NodeNumericMetricKey, which is FilterMetricKey
        const rangeData = dataRanges[filterKey];
        const filterValues = filters[filterKey]; // This is FilterValueRange
        
        if (!rangeData || !filterValues || typeof filterValues !== 'object' || !('currentMin' in filterValues)) {
            return (
                 <div key={filterKey} className="opacity-50">
                    <p className="block text-xs font-medium text-slate-400 mb-0.5">{metric.label}</p>
                    <p className="text-xs text-slate-500">Data not available for this metric.</p>
                </div>
            );
        }

        return (
          <RangeSlider
            key={filterKey}
            label={metric.label}
            metricKey={filterKey} // metricKey prop in RangeSlider is string, NodeNumericMetricKey is assignable
            minVal={filterValues.currentMin}
            maxVal={filterValues.currentMax}
            dataMin={rangeData.min}
            dataMax={rangeData.max}
            onMinChange={(val) => onNumericFilterChange(filterKey, { min: val })}
            onMaxChange={(val) => onNumericFilterChange(filterKey, { max: val })}
            tooltip={metric.tooltip || `Filter nodes by their ${metric.label} values.`}
          />
        );
      })}
    </div>
  );
};


interface FilterSidebarProps {
  filters: FiltersState;
  onFilterChange: <K extends keyof FiltersState>(filterType: K, value: FiltersState[K]) => void;
  onNumericFilterChange: (filterKey: FilterMetricKey, newRange: { min?: number; max?: number }) => void;
  dataRanges: DataRangesForFilters;
  processedNodes: ProcessedNode[]; 
  disabled: boolean;
  isNodeSelected: boolean;
}

const FilterSidebar: React.FC<FilterSidebarProps> = ({
  filters,
  onFilterChange,
  onNumericFilterChange,
  dataRanges,
  processedNodes,
  disabled,
  isNodeSelected 
}) => {
  const uniqueComponentIds = React.useMemo(() => {
    if (!processedNodes) return [];
    return Array.from(new Set(processedNodes.map(n => n.component_id))).sort((a,b) => a-b);
  }, [processedNodes]);

  const uniqueCommunityIds = React.useMemo(() => {
     if (!processedNodes) return [];
    return Array.from(new Set(processedNodes.map(n => n.community_id))).sort((a,b) => a-b);
  }, [processedNodes]);


  if (disabled) {
    return (
      <div className="opacity-60 p-2">
        <p className="text-xs text-slate-400">Filters are unavailable until data is loaded.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3"> 
        <FilterCollapsibleSection 
          title="Search & Piece Filters" 
          defaultOpen={true}
          tooltip="Filter nodes by text search (square ID or piece symbol), piece type (e.g., Pawn, Knight), or piece color (White/Black)."
        >
            <NodeSearch
              searchTerm={filters.searchTerm}
              onSearchTermChange={(val) => onFilterChange('searchTerm', val)}
            />
            <PieceFilter
                selectedPieceTypes={filters.pieceTypes} 
                selectedPieceColor={filters.pieceColor}
                onPieceTypeChange={(val) => onFilterChange('pieceTypes', val)}
                onPieceColorChange={(val) => onFilterChange('pieceColor', val)}
                pieceColorMap={PIECE_COLOR_MAP}
            />
        </FilterCollapsibleSection>
        
        <FilterCollapsibleSection 
          title="Structural Filters"
          tooltip="Filter nodes based on their graph component ID (separate subgraphs) or community ID (densely connected clusters within components)."
        >
            <CommunityComponentFilter
                selectedComponentIds={filters.componentIds}
                selectedCommunityIds={filters.communityIds}
                onComponentIdChange={(val) => onFilterChange('componentIds', val)}
                onCommunityIdChange={(val) => onFilterChange('communityIds', val)}
                availableComponentIds={uniqueComponentIds}
                availableCommunityIds={uniqueCommunityIds}
            />
        </FilterCollapsibleSection>
        
        <FilterCollapsibleSection 
          title="Degree Centrality Filters"
          tooltip="Filter nodes by their in-degree or out-degree centrality values. Centrality measures a node's importance in the network based on its connections."
        >
            <MetricFilterGroup
                metrics={DEGREE_CENTRALITY_METRICS_UI}
                filters={filters}
                dataRanges={dataRanges}
                onNumericFilterChange={onNumericFilterChange}
            />
        </FilterCollapsibleSection>

        <FilterCollapsibleSection 
          title="Betweenness Centrality Filters"
          tooltip="Filter nodes by their in-betweenness or out-betweenness centrality values. Betweenness measures how often a node lies on the shortest paths between other nodes."
        >
            <MetricFilterGroup
                metrics={BETWEENNESS_CENTRALITY_METRICS_UI}
                filters={filters}
                dataRanges={dataRanges}
                onNumericFilterChange={onNumericFilterChange}
            />
        </FilterCollapsibleSection>

        <FilterCollapsibleSection 
          title="Closeness Centrality Filters"
          tooltip="Filter nodes by their in-closeness or out-closeness centrality values. Closeness measures the average shortest distance from a node to all other reachable nodes."
        >
            <MetricFilterGroup
                metrics={CLOSENESS_CENTRALITY_METRICS_UI}
                filters={filters}
                dataRanges={dataRanges}
                onNumericFilterChange={onNumericFilterChange}
            />
        </FilterCollapsibleSection>
        
        <FilterCollapsibleSection 
          title="Other Node Metric Filters"
          tooltip="Filter nodes by various other calculated graph metrics, such as global variances, component averages, component variances, and deviations from component averages. These provide more nuanced views of node characteristics."
        >
            <MetricFilterGroup
                metrics={OTHER_NODE_METRICS_UI}
                filters={filters}
                dataRanges={dataRanges}
                onNumericFilterChange={onNumericFilterChange}
            />
        </FilterCollapsibleSection>
    </div>
  );
};

export default FilterSidebar;