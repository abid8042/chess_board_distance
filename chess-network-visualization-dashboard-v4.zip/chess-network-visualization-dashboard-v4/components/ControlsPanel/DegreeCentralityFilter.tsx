// This component is no longer needed.
// Its functionality has been integrated into FilterSidebar.tsx
// using the new MetricFilterGroup component and updated metric constants.
// This file can be safely DELETED.
