
import React from 'react';
import { ProcessedNode } from '../../types';

interface SelectedNodeInfoProps {
  nodeData: ProcessedNode | null;
}

const SelectedNodeInfo: React.FC<SelectedNodeInfoProps> = ({ nodeData }) => {
  if (!nodeData) {
    return null; 
  }

  // piece_type_name is now directly nodeData.piece_type (e.g. "Pawn") or derived in ProcessedNode.
  // piece_symbol is assumed to be on ProcessedNode.
  const { 
    id, piece_symbol, piece_color, piece_type, // piece_type is now string like "Pawn"
    component_id, community_id, 
    // Centralities
    in_degree_centrality, out_degree_centrality,
    in_betweenness_centrality, out_betweenness_centrality,
    in_closeness_centrality, out_closeness_centrality,
    // Global Variances
    in_degree_centrality_variance, out_degree_centrality_variance,
    in_betweenness_centrality_variance, out_betweenness_centrality_variance,
    in_closeness_centrality_variance, out_closeness_centrality_variance,
    // Component Averages
    in_degree_component_avg, out_degree_component_avg,
    in_betweenness_component_avg, out_betweenness_component_avg,
    in_closeness_component_avg, out_closeness_component_avg,
    // Component Variances
    in_degree_component_var, out_degree_component_var,
    in_betweenness_component_var, out_betweenness_component_var,
    in_closeness_component_var, out_closeness_component_var,
    // Deviations
    in_degree_deviation, out_degree_deviation,
    in_betweenness_deviation, out_betweenness_deviation,
    in_closeness_deviation, out_closeness_deviation,
    ...otherMetrics // Catch any other metrics if needed
  } = nodeData;


  const metricTooltips: Record<string, string> = {
    'Piece': 'Information about the chess piece currently on this square.',
    'Component ID': 'ID of the connected component this square belongs to.',
    'Community ID': 'ID of the community (dense subgraph) this square belongs to.',
    
    'In-Degree': 'In-Degree Centrality: Number of incoming influence links.',
    'Out-Degree': 'Out-Degree Centrality: Number of outgoing influence links.',
    'In-Betweenness': 'In-Betweenness Centrality: How often this node lies on shortest paths for incoming influence.',
    'Out-Betweenness': 'Out-Betweenness Centrality: How often this node lies on shortest paths for outgoing influence.',
    'In-Closeness': 'In-Closeness Centrality: Average shortest distance from all other nodes influencing this node.',
    'Out-Closeness': 'Out-Closeness Centrality: Average shortest distance from this node to all nodes it influences.',

    'In-Degree Var. (Global)': 'Global variance of In-Degree Centrality across all nodes in graph scope.',
    'Out-Degree Var. (Global)': 'Global variance of Out-Degree Centrality across all nodes.',
    'In-Betweenness Var. (Global)': 'Global variance of In-Betweenness Centrality.',
    'Out-Betweenness Var. (Global)': 'Global variance of Out-Betweenness Centrality.',
    'In-Closeness Var. (Global)': 'Global variance of In-Closeness Centrality.',
    'Out-Closeness Var. (Global)': 'Global variance of Out-Closeness Centrality.',

    'Avg Comp In-Degree': 'Average In-Degree of this node\'s component.',
    'Avg Comp Out-Degree': 'Average Out-Degree of this node\'s component.',
    'Avg Comp In-Betweenness': 'Average In-Betweenness of this node\'s component.',
    'Avg Comp Out-Betweenness': 'Average Out-Betweenness of this node\'s component.',
    'Avg Comp In-Closeness': 'Average In-Closeness of this node\'s component.',
    'Avg Comp Out-Closeness': 'Average Out-Closeness of this node\'s component.',
    
    'Comp In-Degree Var.': 'Variance of In-Degree within this node\'s component.',
    'Comp Out-Degree Var.': 'Variance of Out-Degree within this node\'s component.',
    'Comp In-Betweenness Var.': 'Variance of In-Betweenness within this node\'s component.',
    'Comp Out-Betweenness Var.': 'Variance of Out-Betweenness within this node\'s component.',
    'Comp In-Closeness Var.': 'Variance of In-Closeness within this node\'s component.',
    'Comp Out-Closeness Var.': 'Variance of Out-Closeness within this node\'s component.',

    'In-Degree Dev.': 'Deviation of this node\'s In-Degree from its component average.',
    'Out-Degree Dev.': 'Deviation of this node\'s Out-Degree from its component average.',
    'In-Betweenness Dev.': 'Deviation of In-Betweenness from component average.',
    'Out-Betweenness Dev.': 'Deviation of Out-Betweenness from component average.',
    'In-Closeness Dev.': 'Deviation of In-Closeness from component average.',
    'Out-Closeness Dev.': 'Deviation of Out-Closeness from component average.',
  };

  const displayMetrics: {label: string, value: any, tooltip?: string}[] = [
    { label: 'Piece', value: piece_symbol ? `${piece_type || 'Unknown Type'} (${piece_color || 'N/A'}, ${piece_symbol})` : "Empty", tooltip: metricTooltips['Piece'] },
    { label: 'Component ID', value: component_id, tooltip: metricTooltips['Component ID'] },
    { label: 'Community ID', value: community_id, tooltip: metricTooltips['Community ID'] },
    
    { label: 'In-Degree', value: in_degree_centrality, tooltip: metricTooltips['In-Degree'] },
    { label: 'Out-Degree', value: out_degree_centrality, tooltip: metricTooltips['Out-Degree'] },
    { label: 'In-Betweenness', value: in_betweenness_centrality, tooltip: metricTooltips['In-Betweenness'] },
    { label: 'Out-Betweenness', value: out_betweenness_centrality, tooltip: metricTooltips['Out-Betweenness'] },
    { label: 'In-Closeness', value: in_closeness_centrality, tooltip: metricTooltips['In-Closeness'] },
    { label: 'Out-Closeness', value: out_closeness_centrality, tooltip: metricTooltips['Out-Closeness'] },

    { label: 'In-Degree Var. (Global)', value: in_degree_centrality_variance, tooltip: metricTooltips['In-Degree Var. (Global)'] },
    { label: 'Out-Degree Var. (Global)', value: out_degree_centrality_variance, tooltip: metricTooltips['Out-Degree Var. (Global)'] },
    { label: 'In-Betweenness Var. (Global)', value: in_betweenness_centrality_variance, tooltip: metricTooltips['In-Betweenness Var. (Global)'] },
    { label: 'Out-Betweenness Var. (Global)', value: out_betweenness_centrality_variance, tooltip: metricTooltips['Out-Betweenness Var. (Global)'] },
    { label: 'In-Closeness Var. (Global)', value: in_closeness_centrality_variance, tooltip: metricTooltips['In-Closeness Var. (Global)'] },
    { label: 'Out-Closeness Var. (Global)', value: out_closeness_centrality_variance, tooltip: metricTooltips['Out-Closeness Var. (Global)'] },

    { label: 'Avg Comp In-Degree', value: in_degree_component_avg, tooltip: metricTooltips['Avg Comp In-Degree'] },
    { label: 'Avg Comp Out-Degree', value: out_degree_component_avg, tooltip: metricTooltips['Avg Comp Out-Degree'] },
    { label: 'Avg Comp In-Betweenness', value: in_betweenness_component_avg, tooltip: metricTooltips['Avg Comp In-Betweenness'] },
    { label: 'Avg Comp Out-Betweenness', value: out_betweenness_component_avg, tooltip: metricTooltips['Avg Comp Out-Betweenness'] },
    { label: 'Avg Comp In-Closeness', value: in_closeness_component_avg, tooltip: metricTooltips['Avg Comp In-Closeness'] },
    { label: 'Avg Comp Out-Closeness', value: out_closeness_component_avg, tooltip: metricTooltips['Avg Comp Out-Closeness'] },

    { label: 'Comp In-Degree Var.', value: in_degree_component_var, tooltip: metricTooltips['Comp In-Degree Var.'] },
    { label: 'Comp Out-Degree Var.', value: out_degree_component_var, tooltip: metricTooltips['Comp Out-Degree Var.'] },
    { label: 'Comp In-Betweenness Var.', value: in_betweenness_component_var, tooltip: metricTooltips['Comp In-Betweenness Var.'] },
    { label: 'Comp Out-Betweenness Var.', value: out_betweenness_component_var, tooltip: metricTooltips['Comp Out-Betweenness Var.'] },
    { label: 'Comp In-Closeness Var.', value: in_closeness_component_var, tooltip: metricTooltips['Comp In-Closeness Var.'] },
    { label: 'Comp Out-Closeness Var.', value: out_closeness_component_var, tooltip: metricTooltips['Comp Out-Closeness Var.'] },

    { label: 'In-Degree Dev.', value: in_degree_deviation, tooltip: metricTooltips['In-Degree Dev.'] },
    { label: 'Out-Degree Dev.', value: out_degree_deviation, tooltip: metricTooltips['Out-Degree Dev.'] },
    { label: 'In-Betweenness Dev.', value: in_betweenness_deviation, tooltip: metricTooltips['In-Betweenness Dev.'] },
    { label: 'Out-Betweenness Dev.', value: out_betweenness_deviation, tooltip: metricTooltips['Out-Betweenness Dev.'] },
    { label: 'In-Closeness Dev.', value: in_closeness_deviation, tooltip: metricTooltips['In-Closeness Dev.'] },
    { label: 'Out-Closeness Dev.', value: out_closeness_deviation, tooltip: metricTooltips['Out-Closeness Dev.'] },
  ];


  const formatValue = (val: any): string => {
    if (typeof val === 'number') {
      if (Number.isInteger(val)) return val.toString();
      if (Math.abs(val) < 0.001 && val !== 0) return val.toExponential(2);
      return val.toFixed(3);
    }
    return String(val);
  };

  return (
    <div className="max-h-[calc(50vh-3rem)] overflow-y-auto custom-scrollbar">
      <h3 className="text-sm font-semibold text-slate-100 mb-0.5 sticky top-0 bg-slate-700/90 backdrop-blur-sm py-1.5 -mx-3 px-3 border-b border-slate-600">
        Node: <span className="text-sky-300 font-bold">{nodeData.id}</span>
      </h3>
      <dl className="space-y-0.5 text-xs mt-1.5">
        {displayMetrics.map(item => {
          if (item.value === undefined || item.value === null || (typeof item.value === 'number' && isNaN(item.value))) {
            return null; 
          }
          return (
            <div key={item.label} className="flex justify-between items-baseline py-0.5 border-b border-slate-600/80 last:border-b-0">
              <dt className="text-slate-300 truncate pr-1.5" title={item.tooltip || item.label}>{item.label}:</dt>
              <dd className="font-medium text-slate-100 text-right pl-1.5 tabular-nums">
                {formatValue(item.value)}
              </dd>
            </div>
          );
        })}
      </dl>
    </div>
  );
};

export default React.memo(SelectedNodeInfo);

