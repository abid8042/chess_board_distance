
import React from 'react';
import { AggregateStats } from '../../types';

interface StatsDisplayProps {
  stats: AggregateStats | null;
  disabled: boolean;
}

const StatsDisplay: React.FC<StatsDisplayProps> = ({ stats, disabled }) => {
  if (disabled || !stats) { 
    return (
      <div className={`py-1 ${disabled ? 'opacity-60' : ''}`}>
        <p className="text-xs text-slate-400">Load data to view statistics.</p>
      </div>
    );
  }

  const formatValue = (value: number | null | undefined): string => {
    if (value === null || value === undefined || isNaN(value)) return 'N/A';
    // For diameters, which are now int in schema (but might be float in data)
    if (['out_diameter', 'in_diameter'].includes(itemLabel.toLowerCase().replace(/\s/g, '_')) && Number.isInteger(value)) {
        return value.toString();
    }
    if (Number.isInteger(value)) return value.toString();
    if (Math.abs(value) < 0.001 && value !== 0) return value.toExponential(2);
    return value.toFixed(3);
  };
  
  let itemLabel = ""; // Placeholder for current item label, used in formatValue. This is a bit of a hack.

  const statItems = [
    { label: "Fiedler Value", value: stats.fiedler_value, important: true, tooltip: "Fiedler Value (Algebraic Connectivity): Measures graph connectivity. Higher values indicate a more robustly connected graph." },
    { label: "Modularity", value: stats.modularity, important: true, tooltip: "Modularity: Strength of division of a network into modules. Positive values indicate community structure." },
    { label: "Community Count", value: stats.community_count, tooltip: "Total number of detected communities." },
    { label: "Clustering Coeff.", value: stats.clustering, tooltip: "Global Clustering Coefficient: Degree to which nodes tend to cluster together." },
    { label: "Out-Diameter", value: stats.out_diameter, tooltip: "Out-Diameter: Longest shortest path considering edge directions (outgoing)." },
    { label: "In-Diameter", value: stats.in_diameter, tooltip: "In-Diameter: Longest shortest path traversing edges in reverse (incoming)." },
    
    { label: "Avg. In-Degree", value: stats.in_degree_avg, tooltip: "Average In-Degree: Average number of incoming links per node." },
    { label: "In-Degree Var.", value: stats.in_degree_var, tooltip: "In-Degree Variance: Statistical variance of in-degrees across nodes." },
    { label: "Avg. Out-Degree", value: stats.out_degree_avg, tooltip: "Average Out-Degree: Average number of outgoing links per node." },
    { label: "Out-Degree Var.", value: stats.out_degree_var, tooltip: "Out-Degree Variance: Statistical variance of out-degrees across nodes." },

    { label: "Avg. In-Betweenness", value: stats.in_betweenness_avg, tooltip: "Average In-Betweenness Centrality: Average of how often nodes appear on shortest paths leading to them." },
    { label: "In-Betweenness Var.", value: stats.in_betweenness_var, tooltip: "In-Betweenness Centrality Variance: Variance of in-betweenness centrality." },
    { label: "Avg. Out-Betweenness", value: stats.out_betweenness_avg, tooltip: "Average Out-Betweenness Centrality: Average of how often nodes appear on shortest paths originating from them." },
    { label: "Out-Betweenness Var.", value: stats.out_betweenness_var, tooltip: "Out-Betweenness Centrality Variance: Variance of out-betweenness centrality." },

    { label: "Avg. In-Closeness", value: stats.in_closeness_avg, tooltip: "Average In-Closeness Centrality: Average of how close nodes are to all other nodes reachable by incoming paths." },
    { label: "In-Closeness Var.", value: stats.in_closeness_var, tooltip: "In-Closeness Centrality Variance: Variance of in-closeness centrality." },
    { label: "Avg. Out-Closeness", value: stats.out_closeness_avg, tooltip: "Average Out-Closeness Centrality: Average of how close nodes are to all other nodes they can reach." },
    { label: "Out-Closeness Var.", value: stats.out_closeness_var, tooltip: "Out-Closeness Centrality Variance: Variance of out-closeness centrality." },
    
    { label: "Size Entropy", value: stats.size_entropy, tooltip: "Size Entropy of Components: Measures diversity in component sizes." },
  ];

  return (
    <div className="py-1">
      <dl className="grid grid-cols-1 md:grid-cols-2 gap-x-3 gap-y-1 text-xs">
        {statItems.map(item => {
          itemLabel = item.label; // Update for formatValue context hack
          return (
            <div key={item.label} className={`flex justify-between items-baseline py-0.5 ${item.important ? 'col-span-1 md:col-span-2 border-b border-slate-600/70' : ''}`}>
              <dt className="text-slate-300 truncate pr-1" title={item.tooltip || item.label}>{item.label}:</dt>
              <dd className={`font-medium ${item.important ? 'text-sky-300 text-sm' : 'text-slate-100'} tabular-nums`}>{formatValue(item.value)}</dd>
            </div>
          );
        })}
      </dl>
    </div>
  );
};

export default React.memo(StatsDisplay);

