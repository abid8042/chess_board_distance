
import { FiltersState, FilterValueRange, LayoutType, GraphScope, NodeNumericMetricKey, NodeColoringMetricId, NODE_METRIC_KEYS } from './types';

export const INITIAL_FILTER_VALUE_RANGE: FilterValueRange = {
  currentMin: 0,
  currentMax: 1,
  dataMin: 0,
  dataMax: 1,
};

// Create a typed object for initial metric filters
const initialMetricFiltersTyped: { [K in NodeNumericMetricKey]: FilterValueRange } = {} as { [K in NodeNumericMetricKey]: FilterValueRange };
NODE_METRIC_KEYS.forEach(key => {
  initialMetricFiltersTyped[key] = { ...INITIAL_FILTER_VALUE_RANGE };
});

export const INITIAL_FILTERS_STATE: FiltersState = {
  searchTerm: '',
  pieceTypes: [], 
  pieceColor: null,
  componentIds: [],
  communityIds: [],
  ...initialMetricFiltersTyped // Spread the typed metric filters
};


export const LAYOUT_OPTIONS: { value: LayoutType; label: string }[] = [
  { value: 'force-directed', label: 'Force-Directed' },
  { value: 'radial', label: 'Radial' },
  { value: 'spiral', label: 'Spiral (Fixed Path)' },
];

export const GRAPH_SCOPE_OPTIONS: { value: GraphScope; label: string }[] = [
  { value: 'combined', label: 'Combined' },
  { value: 'white', label: 'White Pieces' },
  { value: 'black', label: 'Black Pieces' },
];

// Define categories for UI grouping. NODE_METRIC_KEYS contains all.
export const DEGREE_CENTRALITY_METRICS_UI: { key: NodeNumericMetricKey; label: string }[] = [
    { key: 'in_degree_centrality', label: 'In-Degree Centrality' },
    { key: 'out_degree_centrality', label: 'Out-Degree Centrality' },
];
export const BETWEENNESS_CENTRALITY_METRICS_UI: { key: NodeNumericMetricKey; label: string }[] = [
    { key: 'in_betweenness_centrality', label: 'In-Betweenness Centrality' },
    { key: 'out_betweenness_centrality', label: 'Out-Betweenness Centrality' },
];
export const CLOSENESS_CENTRALITY_METRICS_UI: { key: NodeNumericMetricKey; label: string }[] = [
    { key: 'in_closeness_centrality', label: 'In-Closeness Centrality' },
    { key: 'out_closeness_centrality', label: 'Out-Closeness Centrality' },
];

// For "Other Graph Metric Node Filters" section
export const OTHER_NODE_METRICS_UI: { key: NodeNumericMetricKey; label: string; tooltip?: string }[] = [
  // Global Variances (on node)
  { key: 'in_degree_centrality_variance', label: 'In-Degree Centrality Var.', tooltip: 'Global variance of in-degree centrality across all nodes.' },
  { key: 'out_degree_centrality_variance', label: 'Out-Degree Centrality Var.', tooltip: 'Global variance of out-degree centrality across all nodes.' },
  { key: 'in_betweenness_centrality_variance', label: 'In-Betweenness Centrality Var.', tooltip: 'Global variance of in-betweenness centrality.' },
  { key: 'out_betweenness_centrality_variance', label: 'Out-Betweenness Centrality Var.', tooltip: 'Global variance of out-betweenness centrality.' },
  { key: 'in_closeness_centrality_variance', label: 'In-Closeness Centrality Var.', tooltip: 'Global variance of in-closeness centrality.' },
  { key: 'out_closeness_centrality_variance', label: 'Out-Closeness Centrality Var.', tooltip: 'Global variance of out-closeness centrality.' },
  // Component Averages
  { key: 'in_degree_component_avg', label: 'Avg. Comp. In-Degree', tooltip: 'Average in-degree of the node\'s component.'  },
  { key: 'out_degree_component_avg', label: 'Avg. Comp. Out-Degree', tooltip: 'Average out-degree of the node\'s component.' },
  { key: 'in_betweenness_component_avg', label: 'Avg. Comp. In-Betweenness', tooltip: 'Average in-betweenness of the node\'s component.' },
  { key: 'out_betweenness_component_avg', label: 'Avg. Comp. Out-Betweenness', tooltip: 'Average out-betweenness of the node\'s component.' },
  { key: 'in_closeness_component_avg', label: 'Avg. Comp. In-Closeness', tooltip: 'Average in-closeness of the node\'s component.' },
  { key: 'out_closeness_component_avg', label: 'Avg. Comp. Out-Closeness', tooltip: 'Average out-closeness of the node\'s component.' },
  // Component Variances
  { key: 'in_degree_component_var', label: 'Comp. In-Degree Var.', tooltip: 'Variance of in-degree within the node\'s component.' },
  { key: 'out_degree_component_var', label: 'Comp. Out-Degree Var.', tooltip: 'Variance of out-degree within the node\'s component.' },
  { key: 'in_betweenness_component_var', label: 'Comp. In-Betweenness Var.', tooltip: 'Variance of in-betweenness within the node\'s component.' },
  { key: 'out_betweenness_component_var', label: 'Comp. Out-Betweenness Var.', tooltip: 'Variance of out-betweenness within the node\'s component.' },
  { key: 'in_closeness_component_var', label: 'Comp. In-Closeness Var.', tooltip: 'Variance of in-closeness within the node\'s component.' },
  { key: 'out_closeness_component_var', label: 'Comp. Out-Closeness Var.', tooltip: 'Variance of out-closeness within the node\'s component.' },
  // Deviations
  { key: 'in_degree_deviation', label: 'In-Degree Deviation', tooltip: 'Node\'s in-degree deviation from its component average.'  },
  { key: 'out_degree_deviation', label: 'Out-Degree Deviation', tooltip: 'Node\'s out-degree deviation from its component average.' },
  { key: 'in_betweenness_deviation', label: 'In-Betweenness Deviation', tooltip: 'Node\'s in-betweenness deviation from its component average.' },
  { key: 'out_betweenness_deviation', label: 'Out-Betweenness Deviation', tooltip: 'Node\'s out-betweenness deviation from its component average.' },
  { key: 'in_closeness_deviation', label: 'In-Closeness Deviation', tooltip: 'Node\'s in-closeness deviation from its component average.' },
  { key: 'out_closeness_deviation', label: 'Out-Closeness Deviation', tooltip: 'Node\'s out-closeness deviation from its component average.' },
];


export const SORTABLE_NODE_METRICS: { key: string; label: string }[] = [
  { key: 'id', label: 'Square ID' },
  { key: 'component_id', label: 'Component ID' },
  { key: 'community_id', label: 'Community ID' },
  // Add all numeric metrics from NODE_METRIC_KEYS for sorting
  ...NODE_METRIC_KEYS.map(key => ({
    key: key,
    // Attempt to find a better label from UI groups, fallback to formatted key
    label: [...DEGREE_CENTRALITY_METRICS_UI, ...BETWEENNESS_CENTRALITY_METRICS_UI, ...CLOSENESS_CENTRALITY_METRICS_UI, ...OTHER_NODE_METRICS_UI].find(m => m.key === key)?.label || key.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')
  }))
];

export const NODE_COLORING_METRIC_OPTIONS: { value: NodeColoringMetricId; label: string }[] = [
  { value: 'default', label: 'Default (Component-Community)' },
  { value: 'component_id_color', label: 'Component ID' },
  { value: 'community_id_color', label: 'Community ID' },
  // Add all numeric metrics from NODE_METRIC_KEYS for coloring
   ...NODE_METRIC_KEYS.map(key => ({
    value: key,
    label: [...DEGREE_CENTRALITY_METRICS_UI, ...BETWEENNESS_CENTRALITY_METRICS_UI, ...CLOSENESS_CENTRALITY_METRICS_UI, ...OTHER_NODE_METRICS_UI].find(m => m.key === key)?.label || key.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')
  }))
];