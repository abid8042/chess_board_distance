// index.tsx
import React20 from "react";
import ReactDOM from "react-dom/client";

// App.tsx
import { useState as useState6, useEffect as useEffect4, useMemo as useMemo3, useCallback as useCallback3, useRef as useRef2 } from "react";

// types.ts
var NODE_METRIC_KEYS = [
  "in_degree_centrality",
  "out_degree_centrality",
  "in_betweenness_centrality",
  "out_betweenness_centrality",
  "in_closeness_centrality",
  "out_closeness_centrality",
  "in_degree_centrality_variance",
  "out_degree_centrality_variance",
  "in_betweenness_centrality_variance",
  "out_betweenness_centrality_variance",
  "in_closeness_centrality_variance",
  "out_closeness_centrality_variance",
  "in_degree_component_avg",
  "out_degree_component_avg",
  "in_betweenness_component_avg",
  "out_betweenness_component_avg",
  "in_closeness_component_avg",
  "out_closeness_component_avg",
  "in_degree_component_var",
  "out_degree_component_var",
  "in_betweenness_component_var",
  "out_betweenness_component_var",
  "in_closeness_component_var",
  "out_closeness_component_var",
  "in_degree_deviation",
  "out_degree_deviation",
  "in_betweenness_deviation",
  "out_betweenness_deviation",
  "in_closeness_deviation",
  "out_closeness_deviation"
];
var NUMERIC_PIECE_TYPE_TO_NAME_MAP = {
  1: "Pawn",
  2: "Knight",
  3: "Bishop",
  4: "Rook",
  5: "Queen",
  6: "King"
};
var AVAILABLE_PIECE_TYPES = ["Pawn", "Knight", "Bishop", "Rook", "Queen", "King"];
var PIECE_COLOR_MAP = {
  "white": "White",
  "black": "Black"
};

// constants.ts
var INITIAL_FILTER_VALUE_RANGE = {
  currentMin: 0,
  currentMax: 1,
  dataMin: 0,
  dataMax: 1
};
var initialMetricFiltersTyped = {};
NODE_METRIC_KEYS.forEach((key) => {
  initialMetricFiltersTyped[key] = { ...INITIAL_FILTER_VALUE_RANGE };
});
var INITIAL_FILTERS_STATE = {
  searchTerm: "",
  pieceTypes: [],
  pieceColor: null,
  componentIds: [],
  communityIds: [],
  ...initialMetricFiltersTyped
  // Spread the typed metric filters
};
var LAYOUT_OPTIONS = [
  { value: "force-directed", label: "Force-Directed" },
  { value: "radial", label: "Radial" },
  { value: "spiral", label: "Spiral (Fixed Path)" }
];
var GRAPH_SCOPE_OPTIONS = [
  { value: "combined", label: "Combined" },
  { value: "white", label: "White Pieces" },
  { value: "black", label: "Black Pieces" }
];
var DEGREE_CENTRALITY_METRICS_UI = [
  { key: "in_degree_centrality", label: "In-Degree Centrality" },
  { key: "out_degree_centrality", label: "Out-Degree Centrality" }
];
var BETWEENNESS_CENTRALITY_METRICS_UI = [
  { key: "in_betweenness_centrality", label: "In-Betweenness Centrality" },
  { key: "out_betweenness_centrality", label: "Out-Betweenness Centrality" }
];
var CLOSENESS_CENTRALITY_METRICS_UI = [
  { key: "in_closeness_centrality", label: "In-Closeness Centrality" },
  { key: "out_closeness_centrality", label: "Out-Closeness Centrality" }
];
var OTHER_NODE_METRICS_UI = [
  // Global Variances (on node)
  { key: "in_degree_centrality_variance", label: "In-Degree Centrality Var.", tooltip: "Global variance of in-degree centrality across all nodes." },
  { key: "out_degree_centrality_variance", label: "Out-Degree Centrality Var.", tooltip: "Global variance of out-degree centrality across all nodes." },
  { key: "in_betweenness_centrality_variance", label: "In-Betweenness Centrality Var.", tooltip: "Global variance of in-betweenness centrality." },
  { key: "out_betweenness_centrality_variance", label: "Out-Betweenness Centrality Var.", tooltip: "Global variance of out-betweenness centrality." },
  { key: "in_closeness_centrality_variance", label: "In-Closeness Centrality Var.", tooltip: "Global variance of in-closeness centrality." },
  { key: "out_closeness_centrality_variance", label: "Out-Closeness Centrality Var.", tooltip: "Global variance of out-closeness centrality." },
  // Component Averages
  { key: "in_degree_component_avg", label: "Avg. Comp. In-Degree", tooltip: "Average in-degree of the node's component." },
  { key: "out_degree_component_avg", label: "Avg. Comp. Out-Degree", tooltip: "Average out-degree of the node's component." },
  { key: "in_betweenness_component_avg", label: "Avg. Comp. In-Betweenness", tooltip: "Average in-betweenness of the node's component." },
  { key: "out_betweenness_component_avg", label: "Avg. Comp. Out-Betweenness", tooltip: "Average out-betweenness of the node's component." },
  { key: "in_closeness_component_avg", label: "Avg. Comp. In-Closeness", tooltip: "Average in-closeness of the node's component." },
  { key: "out_closeness_component_avg", label: "Avg. Comp. Out-Closeness", tooltip: "Average out-closeness of the node's component." },
  // Component Variances
  { key: "in_degree_component_var", label: "Comp. In-Degree Var.", tooltip: "Variance of in-degree within the node's component." },
  { key: "out_degree_component_var", label: "Comp. Out-Degree Var.", tooltip: "Variance of out-degree within the node's component." },
  { key: "in_betweenness_component_var", label: "Comp. In-Betweenness Var.", tooltip: "Variance of in-betweenness within the node's component." },
  { key: "out_betweenness_component_var", label: "Comp. Out-Betweenness Var.", tooltip: "Variance of out-betweenness within the node's component." },
  { key: "in_closeness_component_var", label: "Comp. In-Closeness Var.", tooltip: "Variance of in-closeness within the node's component." },
  { key: "out_closeness_component_var", label: "Comp. Out-Closeness Var.", tooltip: "Variance of out-closeness within the node's component." },
  // Deviations
  { key: "in_degree_deviation", label: "In-Degree Deviation", tooltip: "Node's in-degree deviation from its component average." },
  { key: "out_degree_deviation", label: "Out-Degree Deviation", tooltip: "Node's out-degree deviation from its component average." },
  { key: "in_betweenness_deviation", label: "In-Betweenness Deviation", tooltip: "Node's in-betweenness deviation from its component average." },
  { key: "out_betweenness_deviation", label: "Out-Betweenness Deviation", tooltip: "Node's out-betweenness deviation from its component average." },
  { key: "in_closeness_deviation", label: "In-Closeness Deviation", tooltip: "Node's in-closeness deviation from its component average." },
  { key: "out_closeness_deviation", label: "Out-Closeness Deviation", tooltip: "Node's out-closeness deviation from its component average." }
];
var SORTABLE_NODE_METRICS = [
  { key: "id", label: "Square ID" },
  { key: "component_id", label: "Component ID" },
  { key: "community_id", label: "Community ID" },
  // Add all numeric metrics from NODE_METRIC_KEYS for sorting
  ...NODE_METRIC_KEYS.map((key) => ({
    key,
    // Attempt to find a better label from UI groups, fallback to formatted key
    label: [...DEGREE_CENTRALITY_METRICS_UI, ...BETWEENNESS_CENTRALITY_METRICS_UI, ...CLOSENESS_CENTRALITY_METRICS_UI, ...OTHER_NODE_METRICS_UI].find((m) => m.key === key)?.label || key.split("_").map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" ")
  }))
];
var NODE_COLORING_METRIC_OPTIONS = [
  { value: "default", label: "Default (Component-Community)" },
  { value: "component_id_color", label: "Component ID" },
  { value: "community_id_color", label: "Community ID" },
  // Add all numeric metrics from NODE_METRIC_KEYS for coloring
  ...NODE_METRIC_KEYS.map((key) => ({
    value: key,
    label: [...DEGREE_CENTRALITY_METRICS_UI, ...BETWEENNESS_CENTRALITY_METRICS_UI, ...CLOSENESS_CENTRALITY_METRICS_UI, ...OTHER_NODE_METRICS_UI].find((m) => m.key === key)?.label || key.split("_").map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" ")
  }))
];

// src/constants.ts
var VISUAL_NODE_BASE_RADIUS_PIECE = 20;
var VISUAL_NODE_BASE_RADIUS_EMPTY = 14;
var PHYSICS_NODE_BASE_RADIUS_PIECE = 16;
var PHYSICS_NODE_BASE_RADIUS_EMPTY = 11;
var PHYSICS_NODE_COLLIDE_PADDING = 2;
var NODE_VISUAL_SCALING_REFERENCE_DIMENSION = 800;
var NODE_VISUAL_SCALING_MIN_FACTOR = 0.8;
var NODE_VISUAL_SCALING_MAX_FACTOR = 1.2;
var DEFAULT_LAYOUT_PARAMS = {
  "force-directed": {
    linkDistance: 50,
    linkStrength: 0.07,
    chargeStrength: -120,
    collideStrength: 0.7,
    centerStrength: 0.03,
    // General center strength for single component
    componentCenterStrength: 0.08
    // Strength for pulling components apart/together
  },
  "radial": {
    chargeStrength: -70,
    linkDistanceFactor: 0.4,
    // Multiplier for default link distance
    linkStrengthFactor: 0.9,
    // Multiplier for default link strength
    radialStrength: 0.8,
    // Strength pulling nodes to their ideal radius
    ringMinRadiusFactor: 4,
    // Multiplied by largest node radius to set min ring radius
    maxOuterRadiusFactor: 2.5
    // Divides min(width,height) to get max spread
  },
  "spiral": {
    coils: 3,
    maxRadiusMargin: 40,
    // Pixels from edge
    linkDistance: 15,
    linkStrength: 0.01
  }
};
var LAYOUT_PARAMETER_DEFINITIONS = {
  "force-directed": [
    { key: "linkDistance", label: "Link Distance", type: "slider", min: 10, max: 200, step: 1, description: "Target distance between linked nodes. Higher values spread linked nodes further apart." },
    { key: "linkStrength", label: "Link Strength", type: "slider", min: 0.01, max: 1, step: 0.01, description: "How strongly links pull nodes together. Higher values make links more rigid." },
    { key: "chargeStrength", label: "Charge Strength", type: "slider", min: -500, max: -10, step: 1, description: "Simulates electrostatic charge. Negative values make nodes repel each other. More negative means stronger repulsion." },
    { key: "collideStrength", label: "Collide Strength", type: "slider", min: 0.1, max: 1, step: 0.05, description: "Strength of the collision force preventing nodes from overlapping. Higher values make nodes less likely to overlap." },
    { key: "centerStrength", label: "Center Strength (Overall)", type: "slider", min: 0.01, max: 0.5, step: 0.01, description: "How strongly all nodes are pulled towards the center of the visualization. Effective when there is a single connected component." },
    { key: "componentCenterStrength", label: "Component Separation", type: "slider", min: 0.01, max: 0.5, step: 0.01, description: "Strength of pulling nodes towards their respective component centers. Helps separate distinct components if multiple exist. Higher values increase separation." }
  ],
  "radial": [
    { key: "chargeStrength", label: "Charge Strength", type: "slider", min: -300, max: -10, step: 1, description: "Repulsive force between nodes. Helps spread nodes within their rings. More negative means stronger repulsion." },
    { key: "linkDistanceFactor", label: "Link Distance Factor", type: "slider", min: 0.1, max: 2, step: 0.05, description: "Multiplier for the base link distance. Adjusts how far linked nodes are from each other within the radial constraints." },
    { key: "linkStrengthFactor", label: "Link Strength Factor", type: "slider", min: 0.1, max: 2, step: 0.05, description: "Multiplier for the base link strength. Adjusts how rigidly links hold nodes together." },
    { key: "radialStrength", label: "Radial Strength", type: "slider", min: 0.1, max: 1, step: 0.05, description: "How strongly nodes are pulled towards their designated ring/radius. Higher values make rings more defined." },
    { key: "ringMinRadiusFactor", label: "Min. Ring Radius Factor", type: "slider", min: 1, max: 10, step: 0.5, description: "Factor multiplied by the largest node radius to determine the minimum radius of the innermost ring. Prevents central crowding." },
    { key: "maxOuterRadiusFactor", label: "Max. Outer Radius Factor", type: "slider", min: 1.5, max: 5, step: 0.1, description: "Divides the smaller of SVG width/height to determine the maximum extent of the outermost ring. Controls overall spread of rings." }
  ],
  "spiral": [
    { key: "coils", label: "Number of Coils", type: "slider", min: 1, max: 10, step: 0.5, description: "The number of full rotations the spiral makes from center to edge. More coils pack nodes tighter or extend the spiral." },
    { key: "maxRadiusMargin", label: "Max Radius Margin (px)", type: "slider", min: 10, max: 150, step: 5, description: "The margin (in pixels) from the edge of the visualization area to the outermost point of the spiral. Controls how close the spiral gets to the borders." },
    { key: "linkDistance", label: "Link Distance", type: "slider", min: 5, max: 70, step: 1, description: "Target distance for links in the spiral layout. As nodes are fixed, this mainly affects link rendering and any subtle physics if enabled." },
    { key: "linkStrength", label: "Link Strength", type: "slider", min: 1e-3, max: 0.2, step: 1e-3, description: "Strength of links in the spiral layout. Less impactful as node positions are fixed, but can influence link appearance or minor adjustments if physics are slightly active." }
  ]
};
var PIECE_UNICODE_MAP = {
  "P": "\u2659",
  "N": "\u2658",
  "B": "\u2657",
  "R": "\u2656",
  "Q": "\u2655",
  "K": "\u2654",
  // White
  "p": "\u265F",
  "n": "\u265E",
  "b": "\u265D",
  "r": "\u265C",
  "q": "\u265B",
  "k": "\u265A"
  // Black
};
var ZOOM_TO_FIT_PADDING = 50;
var ZOOM_SETTLE_DELAY = 300;

// utils/dataProcessor.ts
function getPieceSymbol(type, color2) {
  if (!type || !color2) return null;
  const lowerType = type.toLowerCase();
  const typeInitial = lowerType === "knight" ? "N" : type[0]?.toUpperCase();
  if (!typeInitial) return null;
  let symbol = color2.toLowerCase() === "white" ? typeInitial.toUpperCase() : typeInitial.toLowerCase();
  if (lowerType === "knight") {
    symbol = color2.toLowerCase() === "white" ? "N" : "n";
  }
  return symbol;
}
function processMoveData(moveData, graphScope) {
  const targetGraph = moveData.g[graphScope];
  const dataRangesForFilters = {};
  NODE_METRIC_KEYS.forEach((key) => {
    dataRangesForFilters[key] = { min: Infinity, max: -Infinity };
  });
  const pieceMapBySquare = /* @__PURE__ */ new Map();
  moveData.p.forEach((p) => {
    if (p.st === "active") {
      pieceMapBySquare.set(p.sq, p);
    }
  });
  const processedNodes = targetGraph.nds.map((nd) => {
    let resolvedPieceTypeString = null;
    if (typeof nd.piece_type === "number") {
      resolvedPieceTypeString = NUMERIC_PIECE_TYPE_TO_NAME_MAP[nd.piece_type] || null;
    } else if (typeof nd.piece_type === "string") {
      resolvedPieceTypeString = nd.piece_type;
    }
    const { piece_type: originalPieceType, ...restOfNd } = nd;
    const augmentedNode = {
      ...restOfNd,
      piece_type: resolvedPieceTypeString,
      // Store the resolved string version
      groupTag: `${nd.component_id}-${nd.community_id}`
    };
    if (augmentedNode.has_piece) {
      const pieceOnSquare = pieceMapBySquare.get(nd.id);
      if (pieceOnSquare) {
        augmentedNode.original_piece_id = pieceOnSquare.id;
        augmentedNode.piece_type_name = pieceOnSquare.t.charAt(0).toUpperCase() + pieceOnSquare.t.slice(1);
        if (pieceOnSquare.t === "knight") augmentedNode.piece_type_name = "Knight";
        if (!augmentedNode.piece_type && augmentedNode.piece_type_name) {
          augmentedNode.piece_type = augmentedNode.piece_type_name;
        }
        if (augmentedNode.piece_symbol === null || augmentedNode.piece_symbol === void 0) {
          augmentedNode.piece_symbol = getPieceSymbol(augmentedNode.piece_type_name, pieceOnSquare.c);
        }
        if (!augmentedNode.piece_color && pieceOnSquare.c) {
          augmentedNode.piece_color = pieceOnSquare.c;
        }
      } else if (augmentedNode.piece_type) {
        augmentedNode.piece_type_name = augmentedNode.piece_type;
        if (!augmentedNode.piece_symbol && augmentedNode.piece_color) {
          augmentedNode.piece_symbol = getPieceSymbol(augmentedNode.piece_type, augmentedNode.piece_color);
        }
      }
    }
    NODE_METRIC_KEYS.forEach((key) => {
      const value = augmentedNode[key];
      if (typeof value === "number" && !isNaN(value)) {
        if (value < dataRangesForFilters[key].min) dataRangesForFilters[key].min = value;
        if (value > dataRangesForFilters[key].max) dataRangesForFilters[key].max = value;
      }
    });
    return augmentedNode;
  });
  NODE_METRIC_KEYS.forEach((key) => {
    if (dataRangesForFilters[key].min === Infinity) dataRangesForFilters[key].min = 0;
    if (dataRangesForFilters[key].max === -Infinity) dataRangesForFilters[key].max = 0;
    if (dataRangesForFilters[key].min > dataRangesForFilters[key].max) {
      if (dataRangesForFilters[key].min === dataRangesForFilters[key].max) {
        dataRangesForFilters[key].min = Math.max(0, dataRangesForFilters[key].min - 0.5);
        dataRangesForFilters[key].max = dataRangesForFilters[key].max + 0.5;
        if (dataRangesForFilters[key].min === dataRangesForFilters[key].max && dataRangesForFilters[key].min === 0) {
          dataRangesForFilters[key].max = 1;
        }
      } else {
        [dataRangesForFilters[key].min, dataRangesForFilters[key].max] = [dataRangesForFilters[key].max, dataRangesForFilters[key].min];
      }
    }
  });
  const processedLinks = targetGraph.lks.map((lk) => {
    let finalLinkPieceType = null;
    if (typeof lk.piece_type === "number") {
      finalLinkPieceType = NUMERIC_PIECE_TYPE_TO_NAME_MAP[lk.piece_type] || null;
    } else if (typeof lk.piece_type === "string") {
      finalLinkPieceType = lk.piece_type;
    }
    return {
      source: lk.source,
      target: lk.target,
      weight: lk.weight,
      piece_symbol: lk.piece_symbol,
      piece_color: lk.piece_color,
      piece_type: finalLinkPieceType
      // Ensure ProcessedLink.piece_type is string | null
    };
  });
  const communityGroupsMap = /* @__PURE__ */ new Map();
  processedNodes.forEach((node) => {
    if (!communityGroupsMap.has(node.groupTag)) {
      communityGroupsMap.set(node.groupTag, []);
    }
    communityGroupsMap.get(node.groupTag).push(node);
  });
  const communityGroups = Array.from(communityGroupsMap.entries()).map(([tag, nodes]) => ({
    groupTag: tag,
    nodes
  }));
  return {
    nodes: processedNodes,
    links: processedLinks,
    communityGroups,
    aggregateStats: targetGraph.agg,
    dataRangesForFilters
  };
}
function applyFiltersAndSort(nodes, links, filters, sortConfig) {
  let filteredNodes = nodes.filter((node) => {
    if (filters.searchTerm) {
      const term = filters.searchTerm.toLowerCase();
      const nodeIdMatch = node.id.toLowerCase().includes(term);
      const pieceSymbolMatch = node.has_piece && node.piece_symbol && node.piece_symbol.toLowerCase().includes(term);
      if (!nodeIdMatch && !pieceSymbolMatch) return false;
    }
    if (filters.pieceTypes.length > 0) {
      if (!node.has_piece || !node.piece_type || !filters.pieceTypes.includes(node.piece_type)) {
        return false;
      }
    }
    if (filters.pieceColor) {
      if (!node.has_piece || node.piece_color !== filters.pieceColor) {
        return false;
      }
    }
    if (filters.componentIds.length > 0) {
      if (!filters.componentIds.includes(node.component_id)) {
        return false;
      }
    }
    if (filters.communityIds.length > 0) {
      if (!filters.communityIds.includes(node.community_id)) {
        return false;
      }
    }
    for (const key of NODE_METRIC_KEYS) {
      const filterKeyTyped = key;
      const filterRange = filters[filterKeyTyped];
      if (filterRange && typeof filterRange === "object" && "currentMin" in filterRange && "currentMax" in filterRange) {
        const nodeValue = node[filterKeyTyped];
        if (typeof nodeValue === "number" && !isNaN(nodeValue)) {
          if (nodeValue < filterRange.currentMin || nodeValue > filterRange.currentMax) {
            return false;
          }
        } else if (filterRange.currentMin > filterRange.dataMin || filterRange.currentMax < filterRange.dataMax) {
          return false;
        }
      }
    }
    return true;
  });
  const { key: sortKey, order: sortOrder } = sortConfig;
  const filteredSortedNodes = [...filteredNodes].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];
    if (valA === null || valA === void 0) return sortOrder === "asc" ? -1 : 1;
    if (valB === null || valB === void 0) return sortOrder === "asc" ? 1 : -1;
    if (typeof valA === "string" && typeof valB === "string") {
      return sortOrder === "asc" ? valA.localeCompare(valB) : valB.localeCompare(valA);
    }
    if (typeof valA === "number" && typeof valB === "number") {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }
    return 0;
  });
  const filteredNodeIds = new Set(filteredSortedNodes.map((n) => n.id));
  const filteredLinks = links.filter((link) => {
    const sourceId = typeof link.source === "string" ? link.source : link.source.id;
    const targetId = typeof link.target === "string" ? link.target : link.target.id;
    return filteredNodeIds.has(sourceId) && filteredNodeIds.has(targetId);
  });
  return { filteredSortedNodes, filteredLinks };
}
function getCapturedPieces(allMoves, currentMoveIndex) {
  if (!allMoves || allMoves.length === 0) return [];
  const relevantPieces = /* @__PURE__ */ new Map();
  for (let i = 0; i <= Math.min(currentMoveIndex, allMoves.length - 1); i++) {
    const move = allMoves[i];
    move.p.forEach((piece) => {
      relevantPieces.set(piece.id, { ...piece });
    });
  }
  return Array.from(relevantPieces.values()).filter(
    (p) => p.st === "captured" && p.cap !== null && p.cap <= currentMoveIndex
    // p.cap should be the move index it was captured
  ).sort((a, b) => (a.cap ?? 0) - (b.cap ?? 0));
}

// components/ControlsPanel/FileUpload.tsx
import React, { useCallback } from "react";

// utils/schemaValidator.ts
function logValidationError(context, message, value) {
  console.error(`Validation Error in ${context}: ${message}`, value !== void 0 ? `Value: ${JSON.stringify(value)}` : "");
  console.trace();
  return false;
}
function validateGenericProperties(obj, checks, context) {
  for (const check of checks) {
    const value = obj[check.key];
    if (check.isArray) {
      if (value === void 0 && check.canBeNull) continue;
      if (value === null && check.canBeNull) continue;
      if (!Array.isArray(value)) {
        return logValidationError(context, `Property '${check.key}' is not an array. Expected array${check.canBeNull ? " or null/undefined" : ""}.`, value);
      }
      if (check.arrayItemType) {
        for (let i = 0; i < value.length; i++) {
          const item = value[i];
          const itemTypeSpec = typeof check.arrayItemType === "string" ? { type: check.arrayItemType } : check.arrayItemType;
          if (item === null && itemTypeSpec.canBeNull) continue;
          if (item === void 0 && itemTypeSpec.canBeNull) continue;
          const typeCheckPassed = Array.isArray(itemTypeSpec.type) ? itemTypeSpec.type.includes(typeof item) : typeof item === itemTypeSpec.type;
          if (!typeCheckPassed) {
            return logValidationError(context, `Item at index ${i} in array '${check.key}' is type ${typeof item}, expected ${itemTypeSpec.type}${itemTypeSpec.canBeNull ? " or null/undefined" : ""}.`, item);
          }
        }
      }
    } else {
      if (check.canBeNull) {
        if (value !== null && value !== void 0) {
          const typeCheckPassed = Array.isArray(check.type) ? check.type.includes(typeof value) : typeof value === check.type;
          if (!typeCheckPassed) {
            return logValidationError(context, `Property '${check.key}' is present with type ${typeof value}, but expected type ${check.type} (or null/undefined).`, value);
          }
        }
      } else {
        if (value === null || value === void 0) {
          return logValidationError(context, `Required property '${check.key}' is missing, null, or undefined. Expected type ${check.type}.`, value);
        }
        const typeCheckPassed = Array.isArray(check.type) ? check.type.includes(typeof value) : typeof value === check.type;
        if (!typeCheckPassed) {
          return logValidationError(context, `Property '${check.key}' is present with type ${typeof value}, but expected type ${check.type}.`, value);
        }
      }
    }
  }
  return true;
}
function validateNodeData(node, parentContext) {
  const context = `${parentContext} -> node ID '${node?.id || "Unknown"}'`;
  if (typeof node !== "object" || node === null) {
    return logValidationError(parentContext, `Node data is not an object or is null. Received: ${String(node)}`);
  }
  const checks = [
    { key: "id", type: "string" },
    { key: "position", type: "string" },
    { key: "has_piece", type: "boolean" },
    { key: "piece_symbol", type: "string", canBeNull: true },
    { key: "piece_color", type: "string", canBeNull: true },
    { key: "piece_type", type: ["string", "number"], canBeNull: true },
    // Allow string or number
    { key: "in_degree_centrality", type: "number" },
    { key: "out_degree_centrality", type: "number" },
    { key: "in_betweenness_centrality", type: "number" },
    { key: "out_betweenness_centrality", type: "number" },
    { key: "in_closeness_centrality", type: "number" },
    { key: "out_closeness_centrality", type: "number" },
    { key: "in_degree_centrality_variance", type: "number" },
    { key: "out_degree_centrality_variance", type: "number" },
    { key: "in_betweenness_centrality_variance", type: "number" },
    { key: "out_betweenness_centrality_variance", type: "number" },
    { key: "in_closeness_centrality_variance", type: "number" },
    { key: "out_closeness_centrality_variance", type: "number" },
    { key: "community_id", type: "number" },
    { key: "component_id", type: "number" },
    { key: "in_degree_component_avg", type: "number" },
    { key: "out_degree_component_avg", type: "number" },
    { key: "in_betweenness_component_avg", type: "number" },
    { key: "out_betweenness_component_avg", type: "number" },
    { key: "in_closeness_component_avg", type: "number" },
    { key: "out_closeness_component_avg", type: "number" },
    { key: "in_degree_component_var", type: "number" },
    { key: "out_degree_component_var", type: "number" },
    { key: "in_betweenness_component_var", type: "number" },
    { key: "out_betweenness_component_var", type: "number" },
    { key: "in_closeness_component_var", type: "number" },
    { key: "out_closeness_component_var", type: "number" },
    { key: "in_degree_deviation", type: "number" },
    { key: "out_degree_deviation", type: "number" },
    { key: "in_betweenness_deviation", type: "number" },
    { key: "out_betweenness_deviation", type: "number" },
    { key: "in_closeness_deviation", type: "number" },
    { key: "out_closeness_deviation", type: "number" }
  ];
  if (node.hasOwnProperty("type") && typeof node.type !== "string") {
    return logValidationError(context, `Optional property 'type' is present but not a string.`, node.type);
  }
  return validateGenericProperties(node, checks, context);
}
function validateLinkData(link, parentContext) {
  const context = `${parentContext} -> link source '${link?.source || "Unknown"}' to target '${link?.target || "Unknown"}'`;
  if (typeof link !== "object" || link === null) {
    return logValidationError(parentContext, `Link data is not an object or is null. Received: ${String(link)}`);
  }
  const checks = [
    { key: "source", type: "string" },
    { key: "target", type: "string" },
    { key: "weight", type: "number" },
    { key: "piece_symbol", type: "string", canBeNull: true },
    { key: "piece_color", type: "string", canBeNull: true },
    { key: "piece_type", type: ["string", "number"], canBeNull: true }
    // Allow string or number
  ];
  if (link.hasOwnProperty("type") && typeof link.type !== "string") {
    return logValidationError(context, `Optional property 'type' is present but not a string.`, link.type);
  }
  return validateGenericProperties(link, checks, context);
}
function validatePieceData(piece, parentContext) {
  const context = `${parentContext} -> piece ID '${piece?.id || "Unknown"}'`;
  if (typeof piece !== "object" || piece === null) {
    return logValidationError(parentContext, `Piece data is not an object or is null. Received: ${String(piece)}`);
  }
  const checks = [
    { key: "id", type: "string" },
    { key: "t", type: "string" },
    { key: "c", type: "string" },
    { key: "sq", type: "string" },
    { key: "st", type: "string" },
    { key: "mc", type: "number" },
    { key: "cap", type: "number", canBeNull: true }
  ];
  return validateGenericProperties(piece, checks, context);
}
function validateAggStats(agg, parentContext) {
  const context = `${parentContext} -> agg_stats`;
  if (typeof agg !== "object" || agg === null) {
    return logValidationError(parentContext, `AggregateStats is not an object or is null. Received: ${String(agg)}`);
  }
  const checks = [
    { key: "fiedler_value", type: "number", canBeNull: true },
    { key: "out_diameter", type: "number" },
    { key: "in_diameter", type: "number" },
    { key: "in_degree_avg", type: "number" },
    { key: "in_degree_var", type: "number" },
    { key: "out_degree_avg", type: "number" },
    { key: "out_degree_var", type: "number" },
    { key: "in_betweenness_avg", type: "number" },
    { key: "in_betweenness_var", type: "number" },
    { key: "out_betweenness_avg", type: "number" },
    { key: "out_betweenness_var", type: "number" },
    { key: "in_closeness_avg", type: "number" },
    { key: "in_closeness_var", type: "number" },
    { key: "out_closeness_avg", type: "number" },
    { key: "out_closeness_var", type: "number" },
    { key: "modularity", type: "number" },
    { key: "community_count", type: "number" },
    { key: "clustering", type: "number" },
    { key: "size_entropy", type: "number" }
  ];
  return validateGenericProperties(agg, checks, context);
}
function validateComponentData(comp, parentContext) {
  const context = `${parentContext} -> component index '${comp?.index || "Unknown"}'`;
  if (typeof comp !== "object" || comp === null) {
    return logValidationError(parentContext, `ComponentData is not an object or is null. Received: ${String(comp)}`);
  }
  const primitiveChecks = [
    { key: "index", type: "number" },
    { key: "size", type: "number" },
    { key: "fiedler", type: "number", canBeNull: true },
    { key: "out_diameter", type: "number" },
    { key: "in_diameter", type: "number" },
    { key: "modularity", type: "number" },
    { key: "community_count", type: "number" },
    { key: "clustering", type: "number" },
    { key: "in_degree_centrality_avg", type: "number" },
    { key: "in_degree_centrality_var", type: "number" },
    { key: "out_degree_centrality_avg", type: "number" },
    { key: "out_degree_centrality_var", type: "number" },
    { key: "in_betweenness_centrality_avg", type: "number" },
    { key: "in_betweenness_centrality_var", type: "number" },
    { key: "out_betweenness_centrality_avg", type: "number" },
    { key: "out_betweenness_centrality_var", type: "number" },
    { key: "in_closeness_centrality_avg", type: "number" },
    { key: "in_closeness_centrality_var", type: "number" },
    { key: "out_closeness_centrality_avg", type: "number" },
    { key: "out_closeness_centrality_var", type: "number" }
  ];
  if (!validateGenericProperties(comp, primitiveChecks, context)) {
    return false;
  }
  const isValidPathArray = (paths, pathKey) => {
    if (!Array.isArray(paths)) {
      return logValidationError(context, `Property '${pathKey}' is not an array.`, paths);
    }
    for (let i = 0; i < paths.length; i++) {
      const p = paths[i];
      if (!Array.isArray(p) || p.length !== 2 || typeof p[0] !== "string" || typeof p[1] !== "string") {
        return logValidationError(context, `Element at index ${i} in '${pathKey}' is not a [string, string] tuple.`, p);
      }
    }
    return true;
  };
  const arrayChecks = [
    { key: "out_diameter_paths", type: "path_array" },
    { key: "in_diameter_paths", type: "path_array" },
    { key: "nodes", type: "array", itemType: "string" }
  ];
  for (const check of arrayChecks) {
    const value = comp[check.key];
    if (check.type === "path_array") {
      if (!isValidPathArray(value, check.key)) return false;
    } else if (check.type === "array") {
      if (!Array.isArray(value)) {
        return logValidationError(context, `Property '${check.key}' is not an array.`, value);
      }
      if (check.itemType) {
        for (let i = 0; i < value.length; i++) {
          if (typeof value[i] !== check.itemType) {
            return logValidationError(context, `Item at index ${i} in array '${check.key}' is type ${typeof value[i]}, expected ${check.itemType}.`, value[i]);
          }
        }
      }
    }
  }
  return true;
}
function validateGraphScopeData(gsd, parentContext) {
  const context = `${parentContext} -> graph_scope_data`;
  if (typeof gsd !== "object" || gsd === null) {
    return logValidationError(parentContext, `GraphScopeData is not an object or is null. Received: ${String(gsd)}`);
  }
  if (!gsd.hasOwnProperty("agg") || !validateAggStats(gsd.agg, context)) {
    if (!gsd.hasOwnProperty("agg")) return logValidationError(context, `Property 'agg' is missing.`);
    return false;
  }
  if (!gsd.hasOwnProperty("cmp") || !Array.isArray(gsd.cmp)) {
    return logValidationError(context, `Property 'cmp' is missing or not an array.`, gsd.cmp);
  }
  for (let i = 0; i < gsd.cmp.length; i++) {
    if (!validateComponentData(gsd.cmp[i], `${context} -> cmp index ${i}`)) return false;
  }
  if (!gsd.hasOwnProperty("nds") || !Array.isArray(gsd.nds)) {
    return logValidationError(context, `Property 'nds' is missing or not an array.`, gsd.nds);
  }
  for (let i = 0; i < gsd.nds.length; i++) {
    if (!validateNodeData(gsd.nds[i], `${context} -> nds index ${i}`)) return false;
  }
  if (!gsd.hasOwnProperty("lks") || !Array.isArray(gsd.lks)) {
    return logValidationError(context, `Property 'lks' is missing or not an array.`, gsd.lks);
  }
  for (let i = 0; i < gsd.lks.length; i++) {
    if (!validateLinkData(gsd.lks[i], `${context} -> lks index ${i}`)) return false;
  }
  return true;
}
function validateMoveData(move, moveIndex) {
  const context = `Move index ${moveIndex}`;
  if (typeof move !== "object" || move === null) {
    return logValidationError(`Root`, `Move data at index ${moveIndex} is not an object or is null. Received: ${String(move)}`);
  }
  if (typeof move.n !== "number") {
    return logValidationError(context, `Property 'n' is type ${typeof move.n}, expected number.`, move.n);
  }
  if (typeof move.m !== "string") {
    return logValidationError(context, `Property 'm' is type ${typeof move.m}, expected string.`, move.m);
  }
  if (typeof move.f !== "string") {
    return logValidationError(context, `Property 'f' is type ${typeof move.f}, expected string.`, move.f);
  }
  if (!Array.isArray(move.p)) {
    return logValidationError(context, `Property 'p' (pieces) is not an array.`, move.p);
  }
  for (let i = 0; i < move.p.length; i++) {
    if (!validatePieceData(move.p[i], `${context} -> piece index ${i}`)) return false;
  }
  if (typeof move.g !== "object" || move.g === null) {
    return logValidationError(context, `Property 'g' (graph data) is not an object or is null.`, move.g);
  }
  const scopes = ["combined", "white", "black"];
  for (const scope of scopes) {
    if (!move.g.hasOwnProperty(scope)) {
      return logValidationError(context, `Property 'g.${scope}' (graph scope data) is missing.`);
    }
    if (typeof move.g[scope] !== "object" || move.g[scope] === null) {
      return logValidationError(context, `Property 'g.${scope}' (graph scope data) is not an object or is null.`, move.g[scope]);
    }
    if (!validateGraphScopeData(move.g[scope], `${context}, '${scope}' scope`)) return false;
  }
  return true;
}
function validateSchema(jsonText) {
  let parsedData;
  try {
    parsedData = JSON.parse(jsonText);
  } catch (e) {
    const error = e;
    logValidationError("JSON Parsing", error.message);
    return { isValid: false, data: null, error: `Invalid JSON: ${error.message}` };
  }
  if (typeof parsedData !== "object" || parsedData === null) {
    logValidationError("Root", "Parsed JSON is not an object or is null.");
    return { isValid: false, data: null, error: "Data is not an object." };
  }
  const data = parsedData;
  if (typeof data.metadata !== "object" || data.metadata === null) {
    logValidationError("Root", "Metadata is not an object or is null.");
    return { isValid: false, data: null, error: "Invalid metadata: not an object." };
  }
  if (typeof data.metadata.schema_version !== "string") {
    logValidationError("Root", `Metadata 'schema_version' is type ${typeof data.metadata.schema_version}, expected string.`, data.metadata.schema_version);
    return { isValid: false, data: null, error: "Invalid metadata: schema_version is not a string." };
  }
  if (typeof data.metadata.description !== "string") {
    logValidationError("Root", `Metadata 'description' is type ${typeof data.metadata.description}, expected string.`, data.metadata.description);
    return { isValid: false, data: null, error: "Invalid metadata: description is not a string." };
  }
  if (!Array.isArray(data.moves)) {
    logValidationError("Root", "'moves' property is not an array.");
    return { isValid: false, data: null, error: "Moves array is missing." };
  }
  if (data.moves.length === 0) {
    logValidationError("Root", "Moves array is empty. Application requires at least one move (initial board setup).");
    return { isValid: false, data: null, error: "Moves array is empty. At least one move is required." };
  }
  for (let i = 0; i < data.moves.length; i++) {
    if (!validateMoveData(data.moves[i], i)) {
      return { isValid: false, data: null, error: `Invalid data in move index ${i}. Check console for specific validation failures logged by individual validators.` };
    }
  }
  return { isValid: true, data, error: null };
}

// components/ControlsPanel/FileUpload.tsx
import { jsx, jsxs } from "react/jsx-runtime";
var UploadIcon = ({ className }) => /* @__PURE__ */ jsx("svg", { className: `w-5 h-5 ${className || ""}`, viewBox: "0 0 20 20", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx("path", { fillRule: "evenodd", d: "M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM6.293 6.707a1 1 0 010-1.414l3-3a1 1 0 011.414 0l3 3a1 1 0 01-1.414 1.414L11 5.414V13a1 1 0 11-2 0V5.414L7.707 6.707a1 1 0 01-1.414 0z", clipRule: "evenodd" }) });
var FileUpload = ({ onFileUpload, setLoading, setError, disabled, currentDataSourceName }) => {
  const handleFileChange = useCallback((event) => {
    if (disabled) return;
    const file = event.target.files?.[0];
    if (file) {
      setLoading(true);
      setError(null);
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const text = e.target?.result;
          const validationResult = validateSchema(text);
          if (validationResult.isValid && validationResult.data) {
            onFileUpload(validationResult.data, file.name);
          } else {
            setError(validationResult.error || "Unknown validation error.");
            console.error("Validation Error:", validationResult.error);
            onFileUpload(null, "");
          }
        } catch (err) {
          setError(`Error processing file: ${err.message}`);
          console.error("File Processing Error:", err);
          onFileUpload(null, "");
        } finally {
          setLoading(false);
        }
      };
      reader.onerror = () => {
        setError("Failed to read file.");
        setLoading(false);
        onFileUpload(null, "");
      };
      reader.readAsText(file);
    }
    if (event.target) {
      event.target.value = "";
    }
  }, [onFileUpload, setLoading, setError, disabled]);
  return /* @__PURE__ */ jsxs("div", { className: `flex items-center space-x-2 ${disabled ? "opacity-60 cursor-not-allowed" : ""}`, children: [
    /* @__PURE__ */ jsxs(
      "label",
      {
        htmlFor: "file-upload-header",
        className: `flex items-center px-3 py-1.5 text-xs sm:text-sm font-medium text-white bg-sky-500 hover:bg-sky-600 rounded-md border border-sky-700 shadow-sm transition-colors duration-150 focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-offset-slate-800 focus-within:ring-sky-400 ${disabled ? "pointer-events-none" : "cursor-pointer"}`,
        title: currentDataSourceName ? `Change data source (currently: ${currentDataSourceName})` : "Load a chess game data file (JSON format) to visualize the network",
        children: [
          /* @__PURE__ */ jsx(UploadIcon, { className: "mr-1.5 h-4 w-4 text-sky-100 flex-shrink-0" }),
          /* @__PURE__ */ jsx("span", { children: currentDataSourceName ? "Change Data" : "Load Game Data" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              id: "file-upload-header",
              type: "file",
              accept: ".json",
              onChange: handleFileChange,
              className: "sr-only",
              "aria-describedby": "file-upload-status",
              disabled
            }
          )
        ]
      }
    ),
    currentDataSourceName && /* @__PURE__ */ jsx("p", { id: "file-upload-status", className: "text-xs text-slate-300 truncate max-w-[100px] sm:max-w-[150px]", title: `Currently loaded: ${currentDataSourceName}`, children: currentDataSourceName })
  ] });
};
var FileUpload_default = React.memo(FileUpload);

// components/ControlsPanel/MoveSelector.tsx
import React2, { useState, useEffect } from "react";
import { jsx as jsx2, jsxs as jsxs2 } from "react/jsx-runtime";
var ChevronLeftIcon = ({ className }) => /* @__PURE__ */ jsx2("svg", { className: `w-5 h-5 ${className || ""}`, viewBox: "0 0 20 20", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx2("path", { fillRule: "evenodd", d: "M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z", clipRule: "evenodd" }) });
var ChevronRightIcon = ({ className }) => /* @__PURE__ */ jsx2("svg", { className: `w-5 h-5 ${className || ""}`, viewBox: "0 0 20 20", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx2("path", { fillRule: "evenodd", d: "M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z", clipRule: "evenodd" }) });
var MoveSelector = ({ currentMoveIndex, totalMoves, currentMoveSAN, onMoveChange, disabled }) => {
  const [inputValue, setInputValue] = useState(currentMoveIndex.toString());
  useEffect(() => {
    setInputValue(currentMoveIndex.toString());
  }, [currentMoveIndex]);
  const handleInputChange = (event) => {
    setInputValue(event.target.value);
  };
  const processInput = () => {
    const num = parseInt(inputValue, 10);
    if (!isNaN(num) && totalMoves > 0) {
      const newIndex = Math.max(0, Math.min(num, totalMoves - 1));
      if (newIndex !== currentMoveIndex) {
        onMoveChange(newIndex);
      }
      setInputValue(newIndex.toString());
    } else {
      setInputValue(currentMoveIndex.toString());
    }
  };
  const handleInputBlur = () => {
    processInput();
  };
  const handleInputKeyDown = (event) => {
    if (event.key === "Enter") {
      processInput();
      event.currentTarget.blur();
    }
  };
  if (disabled || totalMoves === 0) {
    return /* @__PURE__ */ jsxs2("div", { className: "flex flex-col items-start space-y-1.5 text-sm text-slate-400 opacity-70", children: [
      /* @__PURE__ */ jsxs2("div", { className: "flex items-center space-x-2", children: [
        /* @__PURE__ */ jsx2(
          "button",
          {
            className: "p-1.5 rounded-md bg-slate-700 hover:bg-slate-600 cursor-not-allowed",
            disabled: true,
            title: "Previous move (disabled: no data loaded)",
            children: /* @__PURE__ */ jsx2(ChevronLeftIcon, { className: "text-slate-500" })
          }
        ),
        /* @__PURE__ */ jsxs2("div", { className: "text-center w-24 sm:w-28", children: [
          /* @__PURE__ */ jsx2("span", { className: "font-medium block", title: "Current move number / Total moves", children: "Move: --/--" }),
          /* @__PURE__ */ jsx2("span", { className: "text-xs block h-4", title: "Standard Algebraic Notation (SAN) of the current move", children: "Load data" })
        ] }),
        /* @__PURE__ */ jsx2(
          "input",
          {
            type: "number",
            value: "--",
            className: "w-12 text-center bg-slate-700 border border-slate-600 rounded-md px-1 py-0.5 text-xs text-slate-500 cursor-not-allowed",
            disabled: true,
            title: "Go to move number (disabled: no data loaded)"
          }
        ),
        /* @__PURE__ */ jsx2(
          "button",
          {
            className: "p-1.5 rounded-md bg-slate-700 hover:bg-slate-600 cursor-not-allowed",
            disabled: true,
            title: "Next move (disabled: no data loaded)",
            children: /* @__PURE__ */ jsx2(ChevronRightIcon, { className: "text-slate-500" })
          }
        )
      ] }),
      /* @__PURE__ */ jsx2("div", { className: "w-full pt-1 px-1", children: /* @__PURE__ */ jsx2(
        "input",
        {
          type: "range",
          min: "0",
          max: "0",
          value: "0",
          className: "w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-not-allowed accent-slate-500",
          disabled: true,
          "aria-label": "Move slider (disabled). Load data to enable.",
          title: "Move slider (disabled: no data loaded)"
        }
      ) })
    ] });
  }
  const displaySAN = currentMoveSAN && currentMoveSAN !== "start" ? `${currentMoveSAN}` : "Initial Position";
  const uniqueSliderId = "move-selector-range-header";
  const handlePrev = () => onMoveChange(currentMoveIndex - 1);
  const handleNext = () => onMoveChange(currentMoveIndex + 1);
  return /* @__PURE__ */ jsxs2("div", { className: `flex flex-col items-start space-y-1.5 ${disabled ? "opacity-60 cursor-not-allowed" : ""}`, children: [
    /* @__PURE__ */ jsxs2("div", { className: "flex items-center space-x-1.5 sm:space-x-2", children: [
      /* @__PURE__ */ jsx2(
        "button",
        {
          onClick: handlePrev,
          disabled: disabled || currentMoveIndex === 0,
          className: "p-1.5 rounded-md bg-sky-500 hover:bg-sky-600 text-white disabled:bg-slate-600 disabled:text-slate-400 disabled:cursor-not-allowed transition-colors shadow",
          "aria-label": "Previous Move",
          title: "Go to the previous move in the game",
          children: /* @__PURE__ */ jsx2(ChevronLeftIcon, {})
        }
      ),
      /* @__PURE__ */ jsxs2("div", { className: "text-center flex-shrink-0 w-28 sm:w-32", children: [
        /* @__PURE__ */ jsxs2("label", { htmlFor: uniqueSliderId, className: "text-xs sm:text-sm font-medium text-slate-100 whitespace-nowrap block", title: "Current move number out of total moves available", children: [
          "Move ",
          /* @__PURE__ */ jsx2("span", { className: "font-bold text-sky-300", children: currentMoveIndex }),
          " / ",
          totalMoves - 1
        ] }),
        /* @__PURE__ */ jsx2(
          "p",
          {
            className: "text-[10px] sm:text-xs text-slate-300 mt-0.5 h-3 sm:h-4 truncate",
            title: `Current move in Standard Algebraic Notation (SAN): ${displaySAN}`,
            children: displaySAN
          }
        )
      ] }),
      /* @__PURE__ */ jsx2(
        "input",
        {
          type: "number",
          value: inputValue,
          onChange: handleInputChange,
          onBlur: handleInputBlur,
          onKeyDown: handleInputKeyDown,
          min: "0",
          max: totalMoves > 0 ? totalMoves - 1 : 0,
          className: "w-12 sm:w-14 text-center bg-slate-700 text-slate-100 border border-slate-600 rounded-md px-1 py-0.5 text-xs focus:ring-1 focus:ring-sky-400 focus:border-sky-400 disabled:bg-slate-800 disabled:text-slate-500 disabled:cursor-not-allowed",
          disabled,
          "aria-label": "Go to move number",
          title: "Enter a move number (0 to total moves - 1) to jump directly to it"
        }
      ),
      /* @__PURE__ */ jsx2(
        "button",
        {
          onClick: handleNext,
          disabled: disabled || currentMoveIndex >= totalMoves - 1,
          className: "p-1.5 rounded-md bg-sky-500 hover:bg-sky-600 text-white disabled:bg-slate-600 disabled:text-slate-400 disabled:cursor-not-allowed transition-colors shadow",
          "aria-label": "Next Move",
          title: "Go to the next move in the game",
          children: /* @__PURE__ */ jsx2(ChevronRightIcon, {})
        }
      )
    ] }),
    /* @__PURE__ */ jsx2("div", { id: "move-slider-details-header", className: "w-full pt-1 px-1", children: /* @__PURE__ */ jsx2(
      "input",
      {
        id: uniqueSliderId,
        type: "range",
        min: "0",
        max: totalMoves - 1,
        value: currentMoveIndex,
        onChange: (e) => onMoveChange(parseInt(e.target.value, 10)),
        className: "w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer accent-sky-400 focus:outline-none focus:ring-1 focus:ring-sky-300/50 focus:ring-offset-1 focus:ring-offset-slate-800 disabled:accent-slate-500 disabled:cursor-not-allowed",
        disabled,
        "aria-label": `Move slider: Current move ${currentMoveIndex} of ${totalMoves - 1}. SAN: ${displaySAN}. Use this slider to quickly scrub through the game's moves.`,
        title: `Move slider: ${currentMoveIndex} / ${totalMoves - 1}. SAN: ${displaySAN}. Drag to navigate moves.`
      }
    ) })
  ] });
};
var MoveSelector_default = React2.memo(MoveSelector);

// components/ControlsPanel/LayoutSelector.tsx
import React3, { useState as useState2 } from "react";

// components/VisualizationPanel/Tooltip.tsx
import { jsx as jsx3 } from "react/jsx-runtime";
var Tooltip = ({ content, x, y, visible }) => {
  if (!visible) return null;
  return /* @__PURE__ */ jsx3(
    "div",
    {
      className: `tooltip ${visible ? "visible" : ""}`,
      style: {
        left: `${x + 15}px`,
        top: `${y + 15}px`
        // Opacity and transform are now handled by CSS in index.html
      },
      role: "tooltip",
      "aria-hidden": !visible,
      children: typeof content === "string" ? /* @__PURE__ */ jsx3("pre", { children: content }) : content
    }
  );
};
var Tooltip_default = Tooltip;

// components/ControlsPanel/LayoutSelector.tsx
import { Fragment, jsx as jsx4, jsxs as jsxs3 } from "react/jsx-runtime";
var HelpIcon = ({ className, onMouseOver, onMouseOut, ariaLabel }) => /* @__PURE__ */ jsx4(
  "svg",
  {
    className: `w-3.5 h-3.5 text-slate-400 hover:text-sky-300 cursor-help inline-block ml-1.5 flex-shrink-0 ${className || ""}`,
    viewBox: "0 0 20 20",
    fill: "currentColor",
    "aria-hidden": "true",
    onMouseOver,
    onMouseOut,
    role: "button",
    tabIndex: 0,
    "aria-label": ariaLabel,
    onFocus: onMouseOver,
    onBlur: onMouseOut,
    onKeyDown: (e) => {
      if (e.key === "Enter" || e.key === " ") onMouseOver(e);
    },
    children: /* @__PURE__ */ jsx4("path", { fillRule: "evenodd", d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.504l-1.414 2.121A1 1 0 008.586 10H9v2a1 1 0 102 0v-2.414a1 1 0 00-.293-.707l-1.414-1.414A1 1 0 009 7zm0 8a1 1 0 100-2 1 1 0 000 2z", clipRule: "evenodd" })
  }
);
var LayoutSelector = ({ currentLayout, onLayoutChange, disabled }) => {
  const [activeHelpTooltip, setActiveHelpTooltip] = useState2(null);
  const layoutBriefDescriptions = {
    "force-directed": "Force-Directed Layout: Simulates physical forces to arrange nodes. Good for discovering organic structures.",
    "radial": "Radial Layout: Arranges nodes in concentric circles. Useful for hierarchical or categorical data.",
    "spiral": "Spiral Layout (Fixed Path): Places nodes along a pre-defined spiral path, ordered by sort configuration."
  };
  const detailedLayoutDescriptions = {
    "force-directed": /* @__PURE__ */ jsxs3("div", { className: "text-left max-w-md", children: [
      /* @__PURE__ */ jsx4("p", { className: "font-semibold mb-1.5", children: "Force-Directed Layout" }),
      /* @__PURE__ */ jsx4("p", { className: "mb-1", children: "Positions nodes using a physics-based simulation." }),
      /* @__PURE__ */ jsxs3("ul", { className: "list-disc list-inside space-y-0.5 text-xs mb-1", children: [
        /* @__PURE__ */ jsxs3("li", { children: [
          /* @__PURE__ */ jsx4("strong", { children: "Attraction & Repulsion:" }),
          " Linked nodes attract (like springs), all nodes repel (like magnets)."
        ] }),
        /* @__PURE__ */ jsxs3("li", { children: [
          /* @__PURE__ */ jsx4("strong", { children: "Dynamic Positioning:" }),
          " Nodes evolve to a stable state where forces balance."
        ] }),
        /* @__PURE__ */ jsxs3("li", { children: [
          /* @__PURE__ */ jsx4("strong", { children: "Organic Structure Discovery:" }),
          " Excellent for revealing inherent clusters, central nodes, and bridges."
        ] })
      ] }),
      /* @__PURE__ */ jsx4("p", { className: "font-medium text-xs mb-0.5", children: "Usefulness:" }),
      /* @__PURE__ */ jsxs3("ul", { className: "list-disc list-inside space-y-0.5 text-xs mb-1.5", children: [
        /* @__PURE__ */ jsx4("li", { children: "Identifying natural groupings and communities." }),
        /* @__PURE__ */ jsx4("li", { children: "Understanding overall topology and connectivity." }),
        /* @__PURE__ */ jsx4("li", { children: "Visualizing complex networks with unknown structures." })
      ] }),
      /* @__PURE__ */ jsx4("p", { className: "text-xs", children: 'Adjust parameters (link distance/strength, charge, centering) in "Force-Directed Parameters" to fine-tune.' })
    ] }),
    "radial": /* @__PURE__ */ jsxs3("div", { className: "text-left max-w-md", children: [
      /* @__PURE__ */ jsx4("p", { className: "font-semibold mb-1.5", children: "Radial Layout" }),
      /* @__PURE__ */ jsx4("p", { className: "mb-1", children: "Arranges nodes in concentric circles, like ripples in a pond." }),
      /* @__PURE__ */ jsx4("p", { className: "font-medium text-xs mb-0.5", children: "How it works in this app:" }),
      /* @__PURE__ */ jsxs3("ul", { className: "list-disc list-inside space-y-0.5 text-xs mb-1", children: [
        /* @__PURE__ */ jsxs3("li", { children: [
          /* @__PURE__ */ jsx4("strong", { children: "Grouping:" }),
          " Nodes grouped by their `groupTag` (component_id + community_id)."
        ] }),
        /* @__PURE__ */ jsxs3("li", { children: [
          /* @__PURE__ */ jsx4("strong", { children: "Ordering Rings:" }),
          ' Groups ordered by "Sort Nodes By" config. E.g., sort by Component ID for inner/outer rings based on ID. Numeric metrics use group average.'
        ] }),
        /* @__PURE__ */ jsxs3("li", { children: [
          /* @__PURE__ */ jsx4("strong", { children: "Placing Nodes:" }),
          " Each group forms a ring; nodes spread angularly within their ring."
        ] })
      ] }),
      /* @__PURE__ */ jsx4("p", { className: "font-medium text-xs mb-0.5", children: "Usefulness:" }),
      /* @__PURE__ */ jsxs3("ul", { className: "list-disc list-inside space-y-0.5 text-xs mb-1.5", children: [
        /* @__PURE__ */ jsx4("li", { children: "Visualizing hierarchical or categorical data in layers." }),
        /* @__PURE__ */ jsx4("li", { children: "Clearly showing component/community membership on distinct rings." }),
        /* @__PURE__ */ jsx4("li", { children: "Visualizing how sorted metrics change across structural groups." })
      ] }),
      /* @__PURE__ */ jsx4("p", { className: "text-xs", children: 'Adjust "Radial Parameters" (ring strength, link settings, radius factors) for appearance.' })
    ] }),
    "spiral": /* @__PURE__ */ jsxs3("div", { className: "text-left max-w-md", children: [
      /* @__PURE__ */ jsx4("p", { className: "font-semibold mb-1.5", children: "Spiral Layout (Fixed Path)" }),
      /* @__PURE__ */ jsx4("p", { className: "mb-1", children: "Arranges nodes along a predetermined spiral path." }),
      /* @__PURE__ */ jsxs3("ul", { className: "list-disc list-inside space-y-0.5 text-xs mb-1", children: [
        /* @__PURE__ */ jsxs3("li", { children: [
          /* @__PURE__ */ jsx4("strong", { children: "Fixed Positions:" }),
          " Node positions are calculated once and remain fixed."
        ] }),
        /* @__PURE__ */ jsxs3("li", { children: [
          /* @__PURE__ */ jsx4("strong", { children: "Order-Dependent:" }),
          ' Node position primarily determined by its rank from "Sort Nodes By" config.'
        ] }),
        /* @__PURE__ */ jsxs3("li", { children: [
          /* @__PURE__ */ jsx4("strong", { children: "Path Visualization:" }),
          " Nodes placed sequentially along an Archimedean spiral, outward from center."
        ] })
      ] }),
      /* @__PURE__ */ jsx4("p", { className: "font-medium text-xs mb-0.5", children: "Usefulness:" }),
      /* @__PURE__ */ jsxs3("ul", { className: "list-disc list-inside space-y-0.5 text-xs mb-1.5", children: [
        /* @__PURE__ */ jsx4("li", { children: "Visualizing data where sequence or rank is paramount (e.g., ranked lists)." }),
        /* @__PURE__ */ jsx4("li", { children: "Providing a compact, ordered representation for linear progressions." }),
        /* @__PURE__ */ jsx4("li", { children: "Comparing attributes based on sequential position." })
      ] }),
      /* @__PURE__ */ jsx4("p", { className: "text-xs", children: 'Adjust "Spiral Parameters" (Number of Coils, Max Radius Margin) for spiral shape. Link parameters affect visual clarity.' })
    ] })
  };
  const showHelpTooltip = (event, layoutValue) => {
    const targetRect = event.currentTarget.getBoundingClientRect();
    setActiveHelpTooltip({
      content: detailedLayoutDescriptions[layoutValue],
      x: targetRect.right + 5,
      // Position to the right of the icon
      y: targetRect.top + window.scrollY,
      // Align with the top of the icon
      visible: true
    });
  };
  const hideHelpTooltip = () => {
    setActiveHelpTooltip(null);
  };
  return /* @__PURE__ */ jsxs3(Fragment, { children: [
    /* @__PURE__ */ jsxs3("div", { className: `py-2 ${disabled ? "opacity-60" : ""}`, children: [
      /* @__PURE__ */ jsx4("p", { className: "block text-sm font-medium text-slate-200 mb-2", title: "Choose the algorithm used to position nodes in the graph visualization. Different layouts highlight different aspects of the network structure.", children: "Layout Algorithm" }),
      /* @__PURE__ */ jsx4("div", { className: "space-y-1.5", children: LAYOUT_OPTIONS.map((option) => /* @__PURE__ */ jsxs3(
        "div",
        {
          className: `flex items-center p-2.5 rounded-lg transition-colors duration-150 ${disabled ? "cursor-not-allowed" : "hover:bg-slate-600/70"} ${currentLayout === option.value ? "bg-sky-700/40" : "bg-slate-700/50 hover:bg-slate-600"}`,
          children: [
            /* @__PURE__ */ jsx4(
              "input",
              {
                type: "radio",
                name: "layout",
                id: `layout-option-${option.value}`,
                value: option.value,
                checked: currentLayout === option.value,
                onChange: () => onLayoutChange(option.value),
                className: "form-radio h-4 w-4 text-sky-400 bg-slate-500 border-slate-400 focus:ring-2 focus:ring-sky-400 focus:ring-offset-2 focus:ring-offset-slate-700 transition duration-150 ease-in-out disabled:cursor-not-allowed",
                disabled,
                "aria-label": option.label
              }
            ),
            /* @__PURE__ */ jsx4(
              "label",
              {
                htmlFor: `layout-option-${option.value}`,
                className: `ml-2.5 text-sm ${currentLayout === option.value ? "text-sky-200 font-medium" : "text-slate-300"} ${disabled ? "cursor-not-allowed" : "cursor-pointer"}`,
                title: layoutBriefDescriptions[option.value] || `Select ${option.label} layout`,
                children: option.label
              }
            ),
            /* @__PURE__ */ jsx4(
              HelpIcon,
              {
                onMouseOver: (e) => showHelpTooltip(e, option.value),
                onMouseOut: hideHelpTooltip,
                ariaLabel: `More information about ${option.label} layout`
              }
            )
          ]
        },
        option.value
      )) }),
      disabled && /* @__PURE__ */ jsx4("p", { className: "text-xs text-slate-400 mt-2", children: "Load data to select layout." })
    ] }),
    activeHelpTooltip && /* @__PURE__ */ jsx4(Tooltip_default, { ...activeHelpTooltip })
  ] });
};
var LayoutSelector_default = React3.memo(LayoutSelector);

// components/ControlsPanel/GraphScopeSelector.tsx
import React4 from "react";
import { jsx as jsx5, jsxs as jsxs4 } from "react/jsx-runtime";
var GraphScopeSelector = ({ currentScope, onScopeChange, disabled }) => {
  const scopeDescriptions = {
    "combined": "Combined Scope: Visualizes the influences and connections from both White and Black pieces together on the board. Shows the complete interaction network.",
    "white": "White Pieces Scope: Focuses exclusively on White pieces and the squares they influence or control. Useful for analyzing White's board presence and control.",
    "black": "Black Pieces Scope: Focuses exclusively on Black pieces and the squares they influence or control. Useful for analyzing Black's board presence and control."
  };
  return /* @__PURE__ */ jsxs4("div", { className: `py-2 ${disabled ? "opacity-60" : ""}`, children: [
    /* @__PURE__ */ jsx5("label", { htmlFor: "graph-scope-selector", className: "block text-sm font-medium text-slate-200 mb-1.5", title: "Select which set of pieces and their influences to display in the graph. This changes the underlying data used for visualization and statistics.", children: "Graph Scope" }),
    /* @__PURE__ */ jsx5(
      "select",
      {
        id: "graph-scope-selector",
        value: currentScope,
        onChange: (e) => onScopeChange(e.target.value),
        className: "block w-full pl-3 pr-10 py-2 text-sm bg-slate-100 text-slate-800 border border-slate-400/80 focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-sky-400 rounded-lg shadow-sm transition-colors duration-150 disabled:opacity-70 disabled:cursor-not-allowed disabled:bg-slate-300/20 disabled:text-slate-400",
        disabled,
        "aria-label": "Select graph scope: which pieces' influences are shown",
        title: "Determines which set of pieces (Combined, White only, or Black only) and their influences are visualized in the graph and used for metric calculations.",
        children: GRAPH_SCOPE_OPTIONS.map((option) => /* @__PURE__ */ jsx5(
          "option",
          {
            value: option.value,
            className: "text-slate-800",
            title: scopeDescriptions[option.value] || `Set graph scope to ${option.label}`,
            children: option.label
          },
          option.value
        ))
      }
    ),
    disabled && /* @__PURE__ */ jsx5("p", { className: "text-xs text-slate-400 mt-2", children: "Load data to select scope." })
  ] });
};
var GraphScopeSelector_default = React4.memo(GraphScopeSelector);

// components/ControlsPanel/NodeColoringSelector.tsx
import React5 from "react";
import { jsx as jsx6, jsxs as jsxs5 } from "react/jsx-runtime";
var NodeColoringSelector = ({ currentColoringMetric, onColoringMetricChange, disabled }) => {
  const metricDescriptions = {
    // Use string for key to allow dynamic access
    "default": "Default: Colors nodes based on a combination of their Component ID and Community ID, providing a general structural overview using distinct categorical colors.",
    "component_id_color": "Component ID: Colors nodes categorically based on their connected component ID. Helps distinguish separate subgraphs in the network.",
    "community_id_color": "Community ID: Colors nodes categorically based on their detected community ID. Useful for identifying densely connected clusters within components.",
    "in_degree_centrality": "In-Degree Centrality: Colors nodes on a sequential scale based on their in-degree. Highlights nodes that receive many influences or connections.",
    "out_degree_centrality": "Out-Degree Centrality: Colors nodes on a sequential scale based on their out-degree. Highlights nodes that exert many influences or make many connections.",
    "in_degree_centrality_variance": "In-Degree Centrality Variance (Graph Metric): Colors nodes based on the overall graph's in-degree variance. This is a single value for the graph, so all nodes will share a color representing this scheme if chosen, primarily for legend consistency. Does not reflect per-node variance.",
    "out_degree_centrality_variance": "Out-Degree Centrality Variance (Graph Metric): Colors nodes based on the overall graph's out-degree variance. Similar to In-Degree Var., it is a graph-wide metric.",
    "in_degree_component_avg": "Average Component In-Degree: Colors nodes sequentially based on the average in-degree of the component they belong to. Highlights components with generally high/low incoming connectivity.",
    "in_degree_deviation": "In-Degree Deviation from Component Avg.: Colors nodes sequentially based on how much their individual in-degree deviates from the average in-degree of their component. Highlights nodes that are unusually high/low connected within their local group.",
    "out_degree_component_avg": "Average Component Out-Degree: Colors nodes sequentially based on the average out-degree of their component. Highlights components with generally high/low outgoing connectivity.",
    "out_degree_deviation": "Out-Degree Deviation from Component Avg.: Colors nodes sequentially based on how much their individual out-degree deviates from the average out-degree of their component. Highlights nodes that exert unusually high/low influence within their local group."
  };
  return /* @__PURE__ */ jsxs5("div", { className: `py-2 ${disabled ? "opacity-60" : ""}`, children: [
    /* @__PURE__ */ jsx6("label", { htmlFor: "node-coloring-selector", className: "block text-sm font-medium text-slate-200 mb-1.5", title: "Choose a metric to determine the color of each node in the graph. This helps visually identify patterns based on the selected attribute.", children: "Node Coloring Metric" }),
    /* @__PURE__ */ jsx6(
      "select",
      {
        id: "node-coloring-selector",
        value: currentColoringMetric,
        onChange: (e) => onColoringMetricChange(e.target.value),
        className: "block w-full pl-3 pr-10 py-2 text-sm bg-slate-100 text-slate-800 border border-slate-400/80 focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-sky-400 rounded-lg shadow-sm transition-colors duration-150 disabled:opacity-70 disabled:cursor-not-allowed disabled:bg-slate-300/20 disabled:text-slate-400",
        disabled,
        "aria-label": "Select node coloring metric",
        title: "Select the metric used to color nodes. Categorical metrics use distinct colors; sequential metrics use a color gradient.",
        children: NODE_COLORING_METRIC_OPTIONS.map((option) => /* @__PURE__ */ jsx6(
          "option",
          {
            value: option.value,
            className: "text-slate-800",
            title: metricDescriptions[option.value] || `Color nodes by ${option.label}`,
            children: option.label
          },
          option.value
        ))
      }
    ),
    disabled && /* @__PURE__ */ jsx6("p", { className: "text-xs text-slate-400 mt-2", children: "Load data to select coloring metric." })
  ] });
};
var NodeColoringSelector_default = React5.memo(NodeColoringSelector);

// components/ControlsPanel/SequentialColorPaletteSelector.tsx
import React6 from "react";

// src/colorPaletteConstants.ts
import * as d3 from "d3";
var SEQUENTIAL_COLOR_PALETTE_OPTIONS = [
  { value: "viridis", label: "Viridis", description: "Perceptually uniform, vibrant, and good for colorblindness. Ranges from purple through blue, green to yellow." },
  { value: "magma", label: "Magma", description: "Perceptually uniform. Ranges from black through purple, red, orange, to yellow." },
  { value: "plasma", label: "Plasma", description: "Perceptually uniform. Ranges from blue/purple through red, orange, to yellow." },
  { value: "cividis", label: "Cividis", description: "Perceptually uniform and designed for viewers with color vision deficiency (deuteranomaly and protanomaly). Ranges from blue to yellow." },
  { value: "cool", label: "Cool", description: "Sequential palette from cyan to magenta." },
  { value: "blues", label: "Blues", description: "Sequential single-hue palette from light blue to dark blue." }
];
var D3_SEQUENTIAL_INTERPOLATORS = {
  viridis: d3.interpolateViridis,
  magma: d3.interpolateMagma,
  plasma: d3.interpolatePlasma,
  cividis: d3.interpolateCividis,
  cool: d3.interpolateCool,
  blues: d3.interpolateBlues
};

// components/ControlsPanel/SequentialColorPaletteSelector.tsx
import { jsx as jsx7, jsxs as jsxs6 } from "react/jsx-runtime";
var SequentialColorPaletteSelector = ({
  currentPalette,
  onPaletteChange,
  disabled
}) => {
  if (disabled) {
    return null;
  }
  return /* @__PURE__ */ jsxs6("div", { className: `py-2 ${disabled ? "opacity-60" : ""}`, children: [
    /* @__PURE__ */ jsx7(
      "label",
      {
        htmlFor: "sequential-color-palette-selector",
        className: "block text-sm font-medium text-slate-200 mb-1.5",
        title: "Choose a color scheme for visualizing continuous numeric data. Different palettes offer various aesthetic and perceptual properties.",
        children: "Sequential Color Palette"
      }
    ),
    /* @__PURE__ */ jsx7(
      "select",
      {
        id: "sequential-color-palette-selector",
        value: currentPalette,
        onChange: (e) => onPaletteChange(e.target.value),
        className: "block w-full pl-3 pr-10 py-2 text-sm bg-slate-100 text-slate-800 border border-slate-400/80 focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-sky-400 rounded-lg shadow-sm transition-colors duration-150 disabled:opacity-70 disabled:cursor-not-allowed disabled:bg-slate-300/20 disabled:text-slate-400",
        disabled,
        "aria-label": "Select sequential color palette for numeric node coloring",
        title: "Select the color palette for nodes when a numeric coloring metric is active.",
        children: SEQUENTIAL_COLOR_PALETTE_OPTIONS.map((option) => /* @__PURE__ */ jsx7(
          "option",
          {
            value: option.value,
            className: "text-slate-800",
            title: option.description || `Use ${option.label} palette`,
            children: option.label
          },
          option.value
        ))
      }
    ),
    disabled && /* @__PURE__ */ jsx7("p", { className: "text-xs text-slate-400 mt-2", children: "Palette selection available for numeric coloring metrics." })
  ] });
};
var SequentialColorPaletteSelector_default = React6.memo(SequentialColorPaletteSelector);

// components/ControlsPanel/LayoutParametersEditor.tsx
import React7, { useState as useState3 } from "react";
import { Fragment as Fragment2, jsx as jsx8, jsxs as jsxs7 } from "react/jsx-runtime";
var HelpIcon2 = ({ className }) => /* @__PURE__ */ jsx8("svg", { className: `w-3.5 h-3.5 text-slate-400 hover:text-sky-300 cursor-help ${className || ""}`, viewBox: "0 0 20 20", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx8("path", { fillRule: "evenodd", d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.504l-1.414 2.121A1 1 0 008.586 10H9v2a1 1 0 102 0v-2.414a1 1 0 00-.293-.707l-1.414-1.414A1 1 0 009 7zm0 8a1 1 0 100-2 1 1 0 000 2z", clipRule: "evenodd" }) });
var LayoutParametersEditor = ({
  currentLayout,
  layoutParams,
  onParamChange,
  disabled
}) => {
  const [activeHelpTooltip, setActiveHelpTooltip] = useState3(null);
  const paramDefinitions = LAYOUT_PARAMETER_DEFINITIONS[currentLayout];
  if (disabled || !paramDefinitions || paramDefinitions.length === 0) {
    return /* @__PURE__ */ jsx8("div", { className: `py-1 ${disabled ? "opacity-60" : ""}`, children: /* @__PURE__ */ jsx8("p", { className: "text-xs text-slate-400/80", children: disabled ? "Load data to configure layout parameters." : "No parameters for this layout." }) });
  }
  return /* @__PURE__ */ jsxs7(Fragment2, { children: [
    /* @__PURE__ */ jsx8("div", { className: `space-y-2.5 ${disabled ? "opacity-60" : ""}`, children: paramDefinitions.map((paramDef) => {
      const paramKey = paramDef.key;
      const currentValue = layoutParams[paramKey];
      const inputId = `layout-param-${currentLayout}-${String(paramKey)}`;
      const formattedValue = typeof currentValue === "number" ? currentValue.toFixed(paramDef.step && paramDef.step < 1 ? paramDef.step.toString().split(".")[1]?.length || 2 : 0) : "N/A";
      return /* @__PURE__ */ jsxs7("div", { className: "grid grid-cols-[auto,1fr,minmax(0,max-content)] items-center gap-x-2", children: [
        /* @__PURE__ */ jsxs7("div", { className: "flex items-center space-x-1 col-span-1", children: [
          /* @__PURE__ */ jsx8("label", { htmlFor: inputId, className: "text-xs text-slate-300 truncate", title: `${paramDef.label} (Current: ${formattedValue}). ${paramDef.description || ""}`, children: paramDef.label }),
          paramDef.description && /* @__PURE__ */ jsx8(
            "span",
            {
              onMouseOver: (e) => setActiveHelpTooltip({ content: paramDef.description || "No description available.", x: e.pageX, y: e.pageY, visible: true }),
              onMouseOut: () => setActiveHelpTooltip(null),
              className: "flex-shrink-0",
              "aria-label": `Help for ${paramDef.label}`,
              children: /* @__PURE__ */ jsx8(HelpIcon2, {})
            }
          )
        ] }),
        /* @__PURE__ */ jsx8(
          "input",
          {
            id: inputId,
            type: "range",
            min: paramDef.min,
            max: paramDef.max,
            step: paramDef.step,
            value: currentValue,
            onChange: (e) => onParamChange(currentLayout, paramKey, parseFloat(e.target.value)),
            className: "w-full h-1.5 bg-slate-400/70 rounded-lg appearance-none cursor-pointer accent-sky-400 focus:outline-none focus:ring-1 focus:ring-sky-300/70 focus:ring-offset-1 focus:ring-offset-slate-700 col-span-1 disabled:opacity-50",
            disabled,
            "aria-label": `${paramDef.label}. Min: ${paramDef.min}, Max: ${paramDef.max}, Current: ${formattedValue}`,
            title: `Adjust ${paramDef.label}. Range: ${paramDef.min} to ${paramDef.max}. Current: ${formattedValue}. ${paramDef.description || ""}`
          }
        ),
        /* @__PURE__ */ jsx8("span", { className: "text-xs text-slate-200 text-right tabular-nums col-span-1", title: `Current value for ${paramDef.label}: ${formattedValue}`, children: formattedValue })
      ] }, String(paramKey));
    }) }),
    activeHelpTooltip && /* @__PURE__ */ jsx8(Tooltip_default, { ...activeHelpTooltip })
  ] });
};
var LayoutParametersEditor_default = React7.memo(LayoutParametersEditor);

// components/ControlsPanel/FilterSidebar.tsx
import React12 from "react";

// components/ControlsPanel/NodeSearch.tsx
import React8 from "react";
import { jsx as jsx9, jsxs as jsxs8 } from "react/jsx-runtime";
var NodeSearch = ({ searchTerm, onSearchTermChange }) => {
  return /* @__PURE__ */ jsxs8("div", { children: [
    /* @__PURE__ */ jsx9("label", { htmlFor: "node-search", className: "block text-xs font-medium text-slate-300 mb-1", children: "Search Nodes (ID or Piece)" }),
    /* @__PURE__ */ jsx9(
      "input",
      {
        id: "node-search",
        type: "text",
        value: searchTerm,
        onChange: (e) => onSearchTermChange(e.target.value),
        placeholder: "e.g., e4 or N",
        className: "block w-full px-3 py-2 text-sm bg-slate-100 text-slate-800 border border-slate-400/70 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-sky-400 placeholder-slate-400",
        "aria-label": "Search nodes by ID or piece symbol",
        title: "Filter nodes by searching their square ID (e.g., 'a1', 'h8') or the symbol of the piece currently on them (e.g., 'N' for Knight, 'q' for black Queen, 'P' for white Pawn). Case-insensitive."
      }
    )
  ] });
};
var NodeSearch_default = React8.memo(NodeSearch);

// components/ControlsPanel/PieceFilter.tsx
import React9 from "react";
import { jsx as jsx10, jsxs as jsxs9 } from "react/jsx-runtime";
var PieceFilter = ({
  selectedPieceTypes,
  selectedPieceColor,
  onPieceTypeChange,
  onPieceColorChange,
  pieceColorMap
}) => {
  const handleTypeChange = (typeName) => {
    const newSelectedTypes = selectedPieceTypes.includes(typeName) ? selectedPieceTypes.filter((t) => t !== typeName) : [...selectedPieceTypes, typeName];
    onPieceTypeChange(newSelectedTypes);
  };
  return /* @__PURE__ */ jsxs9("div", { className: "space-y-3", children: [
    /* @__PURE__ */ jsxs9("div", { children: [
      /* @__PURE__ */ jsx10("p", { className: "block text-xs font-medium text-slate-300 mb-1.5", title: "Show only nodes (squares) that are currently occupied by the selected piece types (e.g., Pawns, Knights).", children: "Filter by Piece Type" }),
      /* @__PURE__ */ jsx10("div", { className: "grid grid-cols-2 gap-x-2 gap-y-1.5", children: AVAILABLE_PIECE_TYPES.map((typeName) => (
        // Iterate over string names
        /* @__PURE__ */ jsxs9(
          "label",
          {
            className: "flex items-center space-x-2 cursor-pointer group p-1 rounded-md hover:bg-slate-500/60 transition-colors",
            title: `Toggle filter for ${typeName}s. Check to include ${typeName}s, uncheck to exclude.`,
            children: [
              /* @__PURE__ */ jsx10(
                "input",
                {
                  type: "checkbox",
                  checked: selectedPieceTypes.includes(typeName),
                  onChange: () => handleTypeChange(typeName),
                  className: "form-checkbox h-3.5 w-3.5 text-sky-400 bg-slate-500 border-slate-400 rounded focus:ring-1 focus:ring-sky-400 focus:ring-offset-1 focus:ring-offset-slate-600",
                  "aria-label": `Filter by piece type ${typeName}`
                }
              ),
              /* @__PURE__ */ jsx10("span", { className: "text-xs text-slate-300 group-hover:text-sky-300", children: typeName })
            ]
          },
          typeName
        )
      )) })
    ] }),
    /* @__PURE__ */ jsxs9("div", { children: [
      /* @__PURE__ */ jsx10("p", { className: "block text-xs font-medium text-slate-300 mb-1.5", title: "Show only nodes (squares) that are currently occupied by pieces of the selected color (White or Black), or any color.", children: "Filter by Piece Color" }),
      /* @__PURE__ */ jsxs9("div", { className: "flex flex-wrap gap-x-3 gap-y-1.5", children: [
        /* @__PURE__ */ jsxs9(
          "label",
          {
            className: "flex items-center space-x-2 cursor-pointer group p-1 rounded-md hover:bg-slate-500/60 transition-colors",
            title: "Show pieces of any color (both White and Black pieces that match other filters).",
            children: [
              /* @__PURE__ */ jsx10(
                "input",
                {
                  type: "radio",
                  name: "pieceColor",
                  value: "",
                  checked: selectedPieceColor === null,
                  onChange: () => onPieceColorChange(null),
                  className: "form-radio h-3.5 w-3.5 text-sky-400 bg-slate-500 border-slate-400 focus:ring-1 focus:ring-sky-400 focus:ring-offset-1 focus:ring-offset-slate-600",
                  "aria-label": "Filter by any piece color"
                }
              ),
              /* @__PURE__ */ jsx10("span", { className: "text-xs text-slate-300 group-hover:text-sky-300", children: "Any" })
            ]
          }
        ),
        Object.entries(pieceColorMap).map(([value, label]) => /* @__PURE__ */ jsxs9(
          "label",
          {
            className: "flex items-center space-x-2 cursor-pointer group p-1 rounded-md hover:bg-slate-500/60 transition-colors",
            title: `Show only ${label} pieces that match other active filters.`,
            children: [
              /* @__PURE__ */ jsx10(
                "input",
                {
                  type: "radio",
                  name: "pieceColor",
                  value,
                  checked: selectedPieceColor === value,
                  onChange: () => onPieceColorChange(value),
                  className: "form-radio h-3.5 w-3.5 text-sky-400 bg-slate-500 border-slate-400 focus:ring-1 focus:ring-sky-400 focus:ring-offset-1 focus:ring-offset-slate-600",
                  "aria-label": `Filter by piece color ${label}`
                }
              ),
              /* @__PURE__ */ jsx10("span", { className: "text-xs text-slate-300 group-hover:text-sky-300", children: label })
            ]
          },
          value
        ))
      ] })
    ] })
  ] });
};
var PieceFilter_default = React9.memo(PieceFilter);

// components/ControlsPanel/CommunityComponentFilter.tsx
import React10 from "react";
import { jsx as jsx11, jsxs as jsxs10 } from "react/jsx-runtime";
var MultiSelectCheckboxes = ({ label, options, selectedOptions, onChange, entityName, tooltip }) => {
  const handleCheckboxChange = (optionId) => {
    const newSelected = selectedOptions.includes(optionId) ? selectedOptions.filter((id) => id !== optionId) : [...selectedOptions, optionId];
    onChange(newSelected);
  };
  if (options.length === 0) {
    return /* @__PURE__ */ jsxs10("p", { className: "text-xs text-slate-400/80", children: [
      "No ",
      entityName.toLowerCase(),
      " IDs available for the current data selection."
    ] });
  }
  return /* @__PURE__ */ jsxs10("div", { children: [
    /* @__PURE__ */ jsx11("p", { className: "block text-xs font-medium text-slate-300 mb-1", title: tooltip || `Filter nodes by their ${entityName} ID. Select one or more IDs to include in the visualization.`, children: label }),
    /* @__PURE__ */ jsx11("div", { className: "max-h-28 overflow-y-auto bg-slate-500/50 border border-slate-400/60 rounded-md p-1.5 space-y-1 custom-scrollbar", children: options.map((optionId) => /* @__PURE__ */ jsxs10(
      "label",
      {
        className: "flex items-center space-x-2 cursor-pointer text-xs text-slate-300 hover:text-sky-300 transition-colors px-1.5 py-1 rounded hover:bg-slate-400/40",
        title: `Toggle filter for ${entityName} ID ${optionId}. Check to include, uncheck to exclude.`,
        children: [
          /* @__PURE__ */ jsx11(
            "input",
            {
              type: "checkbox",
              checked: selectedOptions.includes(optionId),
              onChange: () => handleCheckboxChange(optionId),
              className: "form-checkbox h-3.5 w-3.5 text-sky-400 bg-slate-500 border-slate-400 rounded focus:ring-1 focus:ring-sky-400 focus:ring-offset-1 focus:ring-offset-slate-600",
              "aria-label": `Filter by ${entityName} ID ${optionId}`
            }
          ),
          /* @__PURE__ */ jsxs10("span", { children: [
            "ID: ",
            optionId
          ] })
        ]
      },
      optionId
    )) })
  ] });
};
var CommunityComponentFilter = ({
  selectedComponentIds,
  selectedCommunityIds,
  onComponentIdChange,
  onCommunityIdChange,
  availableComponentIds,
  availableCommunityIds
}) => {
  return /* @__PURE__ */ jsxs10("div", { className: "space-y-3", children: [
    /* @__PURE__ */ jsx11(
      MultiSelectCheckboxes,
      {
        label: "Filter by Component ID",
        options: availableComponentIds,
        selectedOptions: selectedComponentIds,
        onChange: onComponentIdChange,
        entityName: "Component",
        tooltip: "Select specific connected components of the graph to display. Components are distinct subgraphs where all nodes are reachable from each other, but there are no paths between different components."
      }
    ),
    /* @__PURE__ */ jsx11(
      MultiSelectCheckboxes,
      {
        label: "Filter by Community ID",
        options: availableCommunityIds,
        selectedOptions: selectedCommunityIds,
        onChange: onCommunityIdChange,
        entityName: "Community",
        tooltip: "Select specific communities (groups of densely connected nodes) within components to display. Community detection algorithms identify these clusters. Helps find functional groups or tightly-knit structures."
      }
    )
  ] });
};
var CommunityComponentFilter_default = React10.memo(CommunityComponentFilter);

// components/RangeSlider.tsx
import React11 from "react";
import { jsx as jsx12, jsxs as jsxs11 } from "react/jsx-runtime";
var RangeSlider = ({
  label,
  metricKey,
  minVal,
  maxVal,
  dataMin,
  dataMax,
  onMinChange,
  onMaxChange,
  step,
  // Use provided step
  tooltip
}) => {
  const handleMinChange = (e) => {
    const newMin = parseFloat(e.target.value);
    if (newMin <= maxVal) {
      onMinChange(newMin);
    } else {
      onMinChange(maxVal);
    }
  };
  const handleMaxChange = (e) => {
    const newMax = parseFloat(e.target.value);
    if (newMax >= minVal) {
      onMaxChange(newMax);
    } else {
      onMaxChange(minVal);
    }
  };
  const range2 = dataMax - dataMin;
  const dynamicStep = step !== void 0 ? step : (
    // Use provided step first
    range2 <= 0 ? 0.01 : range2 < 2 ? 0.01 : range2 < 10 ? 0.1 : range2 < 100 ? 0.5 : 1
  );
  const formatValue = (val) => {
    if (val === void 0 || val === null) return "N/A";
    const numVal = Number(val);
    if (isNaN(numVal)) return "N/A";
    const currentStep = step !== void 0 ? step : dynamicStep;
    let decimalPlaces = 0;
    if (currentStep < 1) {
      const stepStr = currentStep.toString();
      if (stepStr.includes(".")) {
        decimalPlaces = stepStr.split(".")[1].length;
      }
    }
    if (Math.abs(numVal) < 1e-4 && numVal !== 0 && decimalPlaces < 3) return numVal.toExponential(1);
    return numVal.toFixed(decimalPlaces);
  };
  const formattedMinVal = formatValue(minVal);
  const formattedMaxVal = formatValue(maxVal);
  const formattedDataMin = formatValue(dataMin);
  const formattedDataMax = formatValue(dataMax);
  return /* @__PURE__ */ jsxs11("div", { className: "mb-2", children: [
    /* @__PURE__ */ jsx12("label", { className: "block text-xs font-medium text-slate-300 mb-1", title: tooltip || `Filter nodes by the '${label}' metric. Adjust the sliders to set the desired range (min: ${formattedDataMin}, max: ${formattedDataMax}).`, children: label }),
    /* @__PURE__ */ jsxs11("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ jsxs11("div", { className: "flex items-center space-x-2", children: [
        /* @__PURE__ */ jsx12(
          "input",
          {
            type: "range",
            min: dataMin,
            max: dataMax,
            value: minVal,
            onChange: handleMinChange,
            step: dynamicStep,
            className: "w-full h-1.5 bg-slate-400/70 rounded-lg appearance-none cursor-pointer accent-sky-400 focus:outline-none focus:ring-1 focus:ring-sky-300/70 focus:ring-offset-1 focus:ring-offset-slate-600",
            id: `${metricKey}-min-slider`,
            "aria-label": `${label} minimum value slider. Current range: ${formattedMinVal} to ${formattedMaxVal}. Data range: ${formattedDataMin} to ${formattedDataMax}.`,
            title: `Set minimum value for ${label}. Current: ${formattedMinVal}. Data range: ${formattedDataMin} to ${formattedDataMax}.`
          }
        ),
        /* @__PURE__ */ jsx12("span", { className: "text-xs text-slate-200 w-10 text-right tabular-nums", title: `Current minimum filter value for ${label}: ${formattedMinVal}`, children: formattedMinVal })
      ] }),
      /* @__PURE__ */ jsxs11("div", { className: "flex items-center space-x-2", children: [
        /* @__PURE__ */ jsx12(
          "input",
          {
            type: "range",
            min: dataMin,
            max: dataMax,
            value: maxVal,
            onChange: handleMaxChange,
            step: dynamicStep,
            className: "w-full h-1.5 bg-slate-400/70 rounded-lg appearance-none cursor-pointer accent-pink-400 focus:outline-none focus:ring-1 focus:ring-pink-300/70 focus:ring-offset-1 focus:ring-offset-slate-600",
            id: `${metricKey}-max-slider`,
            "aria-label": `${label} maximum value slider. Current range: ${formattedMinVal} to ${formattedMaxVal}. Data range: ${formattedDataMin} to ${formattedDataMax}.`,
            title: `Set maximum value for ${label}. Current: ${formattedMaxVal}. Data range: ${formattedDataMin} to ${formattedDataMax}.`
          }
        ),
        /* @__PURE__ */ jsx12("span", { className: "text-xs text-slate-200 w-10 text-right tabular-nums", title: `Current maximum filter value for ${label}: ${formattedMaxVal}`, children: formattedMaxVal })
      ] })
    ] })
  ] });
};
var RangeSlider_default = React11.memo(RangeSlider);

// components/ControlsPanel/FilterSidebar.tsx
import { jsx as jsx13, jsxs as jsxs12 } from "react/jsx-runtime";
var ChevronDownIcon = ({ className }) => /* @__PURE__ */ jsx13("svg", { className: `w-4 h-4 transition-transform duration-200 ${className}`, viewBox: "0 0 20 20", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx13("path", { fillRule: "evenodd", d: "M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z", clipRule: "evenodd" }) });
var FilterCollapsibleSection = ({ title, children, defaultOpen = false, actionButton, tooltip }) => {
  const [isOpen, setIsOpen] = React12.useState(defaultOpen);
  return /* @__PURE__ */ jsxs12("div", { className: "bg-slate-600/60 rounded-lg border border-slate-500/70", children: [
    /* @__PURE__ */ jsxs12("div", { className: `flex justify-between items-center w-full p-2.5 text-left hover:bg-slate-500/70 transition-colors duration-150 ${isOpen ? "rounded-t-lg" : "rounded-lg"}`, children: [
      /* @__PURE__ */ jsxs12(
        "button",
        {
          onClick: () => setIsOpen(!isOpen),
          className: "flex-grow flex items-center text-xs font-medium text-slate-200 focus:outline-none focus-visible:ring-1 focus-visible:ring-sky-400",
          "aria-expanded": isOpen,
          title: tooltip || `Click to ${isOpen ? "collapse" : "expand"} ${title} section`,
          children: [
            /* @__PURE__ */ jsx13("span", { children: title }),
            /* @__PURE__ */ jsx13(ChevronDownIcon, { className: `${isOpen ? "transform rotate-180" : ""} text-slate-400 ml-1.5` })
          ]
        }
      ),
      actionButton && /* @__PURE__ */ jsx13("div", { className: "flex-shrink-0 ml-2", children: actionButton })
    ] }),
    isOpen && /* @__PURE__ */ jsx13("div", { className: "p-2.5 border-t border-slate-500/70 space-y-2.5", children })
  ] });
};
var MetricFilterGroup = ({ metrics, filters, dataRanges, onNumericFilterChange }) => {
  return /* @__PURE__ */ jsx13("div", { className: "space-y-2.5", children: metrics.map((metric) => {
    const filterKey = metric.key;
    const rangeData = dataRanges[filterKey];
    const filterValues = filters[filterKey];
    if (!rangeData || !filterValues || typeof filterValues !== "object" || !("currentMin" in filterValues)) {
      return /* @__PURE__ */ jsxs12("div", { className: "opacity-50", children: [
        /* @__PURE__ */ jsx13("p", { className: "block text-xs font-medium text-slate-400 mb-0.5", children: metric.label }),
        /* @__PURE__ */ jsx13("p", { className: "text-xs text-slate-500", children: "Data not available for this metric." })
      ] }, filterKey);
    }
    return /* @__PURE__ */ jsx13(
      RangeSlider_default,
      {
        label: metric.label,
        metricKey: filterKey,
        minVal: filterValues.currentMin,
        maxVal: filterValues.currentMax,
        dataMin: rangeData.min,
        dataMax: rangeData.max,
        onMinChange: (val) => onNumericFilterChange(filterKey, { min: val }),
        onMaxChange: (val) => onNumericFilterChange(filterKey, { max: val }),
        tooltip: metric.tooltip || `Filter nodes by their ${metric.label} values.`
      },
      filterKey
    );
  }) });
};
var FilterSidebar = ({
  filters,
  onFilterChange,
  onNumericFilterChange,
  dataRanges,
  processedNodes,
  disabled,
  isNodeSelected
}) => {
  const uniqueComponentIds = React12.useMemo(() => {
    if (!processedNodes) return [];
    return Array.from(new Set(processedNodes.map((n) => n.component_id))).sort((a, b) => a - b);
  }, [processedNodes]);
  const uniqueCommunityIds = React12.useMemo(() => {
    if (!processedNodes) return [];
    return Array.from(new Set(processedNodes.map((n) => n.community_id))).sort((a, b) => a - b);
  }, [processedNodes]);
  if (disabled) {
    return /* @__PURE__ */ jsx13("div", { className: "opacity-60 p-2", children: /* @__PURE__ */ jsx13("p", { className: "text-xs text-slate-400", children: "Filters are unavailable until data is loaded." }) });
  }
  return /* @__PURE__ */ jsxs12("div", { className: "space-y-3", children: [
    /* @__PURE__ */ jsxs12(
      FilterCollapsibleSection,
      {
        title: "Search & Piece Filters",
        defaultOpen: true,
        tooltip: "Filter nodes by text search (square ID or piece symbol), piece type (e.g., Pawn, Knight), or piece color (White/Black).",
        children: [
          /* @__PURE__ */ jsx13(
            NodeSearch_default,
            {
              searchTerm: filters.searchTerm,
              onSearchTermChange: (val) => onFilterChange("searchTerm", val)
            }
          ),
          /* @__PURE__ */ jsx13(
            PieceFilter_default,
            {
              selectedPieceTypes: filters.pieceTypes,
              selectedPieceColor: filters.pieceColor,
              onPieceTypeChange: (val) => onFilterChange("pieceTypes", val),
              onPieceColorChange: (val) => onFilterChange("pieceColor", val),
              pieceColorMap: PIECE_COLOR_MAP
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ jsx13(
      FilterCollapsibleSection,
      {
        title: "Structural Filters",
        tooltip: "Filter nodes based on their graph component ID (separate subgraphs) or community ID (densely connected clusters within components).",
        children: /* @__PURE__ */ jsx13(
          CommunityComponentFilter_default,
          {
            selectedComponentIds: filters.componentIds,
            selectedCommunityIds: filters.communityIds,
            onComponentIdChange: (val) => onFilterChange("componentIds", val),
            onCommunityIdChange: (val) => onFilterChange("communityIds", val),
            availableComponentIds: uniqueComponentIds,
            availableCommunityIds: uniqueCommunityIds
          }
        )
      }
    ),
    /* @__PURE__ */ jsx13(
      FilterCollapsibleSection,
      {
        title: "Degree Centrality Filters",
        tooltip: "Filter nodes by their in-degree or out-degree centrality values. Centrality measures a node's importance in the network based on its connections.",
        children: /* @__PURE__ */ jsx13(
          MetricFilterGroup,
          {
            metrics: DEGREE_CENTRALITY_METRICS_UI,
            filters,
            dataRanges,
            onNumericFilterChange
          }
        )
      }
    ),
    /* @__PURE__ */ jsx13(
      FilterCollapsibleSection,
      {
        title: "Betweenness Centrality Filters",
        tooltip: "Filter nodes by their in-betweenness or out-betweenness centrality values. Betweenness measures how often a node lies on the shortest paths between other nodes.",
        children: /* @__PURE__ */ jsx13(
          MetricFilterGroup,
          {
            metrics: BETWEENNESS_CENTRALITY_METRICS_UI,
            filters,
            dataRanges,
            onNumericFilterChange
          }
        )
      }
    ),
    /* @__PURE__ */ jsx13(
      FilterCollapsibleSection,
      {
        title: "Closeness Centrality Filters",
        tooltip: "Filter nodes by their in-closeness or out-closeness centrality values. Closeness measures the average shortest distance from a node to all other reachable nodes.",
        children: /* @__PURE__ */ jsx13(
          MetricFilterGroup,
          {
            metrics: CLOSENESS_CENTRALITY_METRICS_UI,
            filters,
            dataRanges,
            onNumericFilterChange
          }
        )
      }
    ),
    /* @__PURE__ */ jsx13(
      FilterCollapsibleSection,
      {
        title: "Other Node Metric Filters",
        tooltip: "Filter nodes by various other calculated graph metrics, such as global variances, component averages, component variances, and deviations from component averages. These provide more nuanced views of node characteristics.",
        children: /* @__PURE__ */ jsx13(
          MetricFilterGroup,
          {
            metrics: OTHER_NODE_METRICS_UI,
            filters,
            dataRanges,
            onNumericFilterChange
          }
        )
      }
    )
  ] });
};
var FilterSidebar_default = FilterSidebar;

// components/ControlsPanel/SortOptions.tsx
import React13 from "react";
import { jsx as jsx14, jsxs as jsxs13 } from "react/jsx-runtime";
var ArrowUpIcon = ({ className }) => /* @__PURE__ */ jsx14("svg", { className: `w-3.5 h-3.5 ${className || ""}`, viewBox: "0 0 20 20", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx14("path", { fillRule: "evenodd", d: "M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z", clipRule: "evenodd" }) });
var ArrowDownIcon = ({ className }) => /* @__PURE__ */ jsx14("svg", { className: `w-3.5 h-3.5 ${className || ""}`, viewBox: "0 0 20 20", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx14("path", { fillRule: "evenodd", d: "M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z", clipRule: "evenodd" }) });
var SortOptions = ({ sortConfig, onSortChange, disabled }) => {
  if (disabled) {
    return /* @__PURE__ */ jsxs13("div", { className: "pt-1 pb-2 opacity-60", children: [
      /* @__PURE__ */ jsx14("p", { className: "text-sm font-medium text-slate-400 mb-1.5", children: "Sort Nodes By" }),
      /* @__PURE__ */ jsx14("p", { className: "text-xs text-slate-500", children: "Load data to enable sorting." })
    ] });
  }
  const currentOrderText = sortConfig.order === "asc" ? "Ascending" : "Descending";
  const buttonAriaLabel = `Change sort order. Current order is ${currentOrderText}. Click to switch to ${sortConfig.order === "asc" ? "Descending" : "Ascending"}.`;
  const buttonTitle = `Current sort order: ${currentOrderText} (for ${SORTABLE_NODE_METRICS.find((m) => m.key === sortConfig.key)?.label || sortConfig.key}). Click to switch to ${sortConfig.order === "asc" ? "Descending" : "Ascending"}.`;
  const selectedMetricLabel = SORTABLE_NODE_METRICS.find((m) => m.key === sortConfig.key)?.label || sortConfig.key;
  return /* @__PURE__ */ jsxs13("div", { className: "pt-1 pb-2", children: [
    /* @__PURE__ */ jsx14("p", { className: "block text-sm font-medium text-slate-200 mb-1.5", title: "Define the primary attribute and order for sorting nodes. This affects the node order in some lists and is crucial for layouts like Radial (for ring order) and Spiral (for path order).", children: "Sort Nodes By" }),
    /* @__PURE__ */ jsx14(
      "select",
      {
        value: sortConfig.key,
        onChange: (e) => onSortChange(e.target.value, sortConfig.order),
        className: "w-full pl-3 pr-8 py-2 text-sm bg-slate-100 text-slate-800 border border-slate-400/80 focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-sky-400 rounded-lg shadow-sm transition-colors duration-150",
        "aria-label": "Select sort metric for nodes",
        title: `Select the metric by which nodes will be sorted. Currently sorting by: ${selectedMetricLabel}. This impacts node lists and certain layouts (e.g., Radial, Spiral).`,
        disabled,
        children: SORTABLE_NODE_METRICS.map((metric) => /* @__PURE__ */ jsx14("option", { value: metric.key, className: "text-slate-800", title: `Sort nodes by ${metric.label}`, children: metric.label }, metric.key))
      }
    ),
    /* @__PURE__ */ jsx14("div", { className: "flex justify-end mt-1.5", children: /* @__PURE__ */ jsxs13(
      "button",
      {
        onClick: () => onSortChange(sortConfig.key, sortConfig.order === "asc" ? "desc" : "asc"),
        className: "px-2.5 py-[7px] border border-slate-500 rounded-lg shadow-sm text-slate-200 bg-slate-600 hover:bg-slate-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-700 focus:ring-sky-400 transition-colors duration-150 flex items-center space-x-1.5 text-xs",
        "aria-label": buttonAriaLabel,
        title: buttonTitle,
        disabled,
        children: [
          sortConfig.order === "asc" ? /* @__PURE__ */ jsx14(ArrowUpIcon, { className: "flex-shrink-0" }) : /* @__PURE__ */ jsx14(ArrowDownIcon, { className: "flex-shrink-0" }),
          /* @__PURE__ */ jsx14("span", { children: currentOrderText })
        ]
      }
    ) })
  ] });
};
var SortOptions_default = React13.memo(SortOptions);

// components/VisualizationPanel/NetworkGraph.tsx
import { useEffect as useEffect2, useRef, useMemo, useCallback as useCallback2 } from "react";
import * as d35 from "d3";

// src/layouts/forceDirectedLayout.ts
import * as d32 from "d3";
var getScaledNodeCollisionRadius = (node, dims) => {
  const baseRadius = node.has_piece ? PHYSICS_NODE_BASE_RADIUS_PIECE : PHYSICS_NODE_BASE_RADIUS_EMPTY;
  if (dims.width === 0 || dims.height === 0) {
    return baseRadius + PHYSICS_NODE_COLLIDE_PADDING;
  }
  const minDim = Math.min(dims.width, dims.height);
  let scale = minDim / NODE_VISUAL_SCALING_REFERENCE_DIMENSION;
  scale = Math.max(NODE_VISUAL_SCALING_MIN_FACTOR, Math.min(NODE_VISUAL_SCALING_MAX_FACTOR, scale));
  return baseRadius * scale + PHYSICS_NODE_COLLIDE_PADDING;
};
function applyForceDirectedLayout(simulation, nodes, links, dimensions, params) {
  const { width, height } = dimensions;
  simulation.force("link", d32.forceLink(links).id((d) => d.id).distance(params.linkDistance).strength(params.linkStrength)).force("charge", d32.forceManyBody().strength(params.chargeStrength)).force("collide", d32.forceCollide().radius((d) => getScaledNodeCollisionRadius(d, dimensions)).strength(params.collideStrength)).force("center", d32.forceCenter(width / 2, height / 2).strength(params.centerStrength / 2));
  const componentCenters = {};
  const uniqueComponentIds = Array.from(new Set(nodes.map((n) => n.component_id)));
  const baseComponentLayoutRadius = Math.min(width, height) / (uniqueComponentIds.length > 2 ? 3 : uniqueComponentIds.length > 1 ? 2.5 : 10);
  uniqueComponentIds.forEach((id, i) => {
    const angle = i / uniqueComponentIds.length * 2 * Math.PI;
    componentCenters[id] = {
      x: width / 2 + (uniqueComponentIds.length > 1 ? baseComponentLayoutRadius * Math.cos(angle) : 0),
      y: height / 2 + (uniqueComponentIds.length > 1 ? baseComponentLayoutRadius * Math.sin(angle) : 0)
    };
  });
  if (uniqueComponentIds.length > 1) {
    simulation.force("x", d32.forceX((d) => componentCenters[d.component_id]?.x || width / 2).strength(params.componentCenterStrength)).force("y", d32.forceY((d) => componentCenters[d.component_id]?.y || height / 2).strength(params.componentCenterStrength));
  } else {
    simulation.force("x", null).force("y", null);
    simulation.force("center", d32.forceCenter(width / 2, height / 2).strength(params.centerStrength));
  }
}

// src/layouts/radialLayout.ts
import * as d33 from "d3";
var getScaledNodeCollisionRadius2 = (node, dims) => {
  const baseRadius = node.has_piece ? PHYSICS_NODE_BASE_RADIUS_PIECE : PHYSICS_NODE_BASE_RADIUS_EMPTY;
  if (dims.width === 0 || dims.height === 0) {
    return baseRadius + PHYSICS_NODE_COLLIDE_PADDING;
  }
  const minDim = Math.min(dims.width, dims.height);
  let scale = minDim / NODE_VISUAL_SCALING_REFERENCE_DIMENSION;
  scale = Math.max(NODE_VISUAL_SCALING_MIN_FACTOR, Math.min(NODE_VISUAL_SCALING_MAX_FACTOR, scale));
  return baseRadius * scale + PHYSICS_NODE_COLLIDE_PADDING;
};
function applyRadialLayout(simulation, nodes, links, dimensions, sortConfig, params) {
  const { width, height } = dimensions;
  let uniqueGroupTags = Array.from(new Set(nodes.map((n) => n.groupTag)));
  const sortKeyIsNumericMetric = NODE_METRIC_KEYS.includes(sortConfig.key);
  if (sortKeyIsNumericMetric) {
    const groupAvgs = /* @__PURE__ */ new Map();
    uniqueGroupTags.forEach((tag) => {
      const nodesInGroup = nodes.filter((n) => n.groupTag === tag);
      if (nodesInGroup.length > 0) {
        const sum = nodesInGroup.reduce((acc, curr) => {
          const val = curr[sortConfig.key];
          return acc + (typeof val === "number" && !isNaN(val) ? val : 0);
        }, 0);
        groupAvgs.set(tag, sum / nodesInGroup.length);
      } else {
        groupAvgs.set(tag, 0);
      }
    });
    uniqueGroupTags.sort((a, b) => {
      const valA = groupAvgs.get(a) || 0;
      const valB = groupAvgs.get(b) || 0;
      return (valA - valB) * (sortConfig.order === "asc" ? 1 : -1);
    });
  } else if (sortConfig.key === "component_id") {
    uniqueGroupTags.sort((a, b) => {
      const compA = parseInt(a.split("-")[0]);
      const compB = parseInt(b.split("-")[0]);
      return (compA - compB) * (sortConfig.order === "asc" ? 1 : -1);
    });
  } else if (sortConfig.key === "community_id") {
    uniqueGroupTags.sort((a, b) => {
      const compA = parseInt(a.split("-")[0]);
      const compB = parseInt(b.split("-")[0]);
      if (compA !== compB) {
        return (compA - compB) * (sortConfig.order === "asc" ? 1 : -1);
      }
      const commA = parseInt(a.split("-")[1]);
      const commB = parseInt(b.split("-")[1]);
      return (commA - commB) * (sortConfig.order === "asc" ? 1 : -1);
    });
  } else {
    uniqueGroupTags.sort((a, b) => {
      return a.localeCompare(b) * (sortConfig.order === "asc" ? 1 : -1);
    });
  }
  const numRings = uniqueGroupTags.length;
  const maxOuterRadius = Math.min(width, height) / params.maxOuterRadiusFactor;
  const groupTagToRadius = /* @__PURE__ */ new Map();
  uniqueGroupTags.forEach((tag, i) => {
    let radius;
    if (numRings <= 1) {
      radius = numRings === 1 ? maxOuterRadius / 2 : 0;
    } else {
      const largestUnscaledPhysicsRadius = Math.max(PHYSICS_NODE_BASE_RADIUS_PIECE, PHYSICS_NODE_BASE_RADIUS_EMPTY);
      const minInnerRadius = (largestUnscaledPhysicsRadius + PHYSICS_NODE_COLLIDE_PADDING) * params.ringMinRadiusFactor;
      const availableRadiusSpace = maxOuterRadius - minInnerRadius;
      const ringSpacing = availableRadiusSpace > 0 && numRings > 1 ? availableRadiusSpace / (numRings - 1) : 0;
      radius = minInnerRadius + ringSpacing * i;
    }
    groupTagToRadius.set(tag, Math.max(0, radius));
  });
  nodes.forEach((node) => {
    node.targetRadius = groupTagToRadius.get(node.groupTag) ?? maxOuterRadius / 2;
  });
  const baseLinkDistance = DEFAULT_LAYOUT_PARAMS["force-directed"].linkDistance;
  const baseLinkStrength = DEFAULT_LAYOUT_PARAMS["force-directed"].linkStrength;
  simulation.force("link", d33.forceLink(links).id((d) => d.id).distance(baseLinkDistance * params.linkDistanceFactor).strength(baseLinkStrength * params.linkStrengthFactor)).force("charge", d33.forceManyBody().strength(params.chargeStrength)).force("collide", d33.forceCollide().radius((d) => getScaledNodeCollisionRadius2(d, dimensions)).strength(DEFAULT_LAYOUT_PARAMS["force-directed"].collideStrength)).force("r", d33.forceRadial(
    (d) => d.targetRadius,
    // Added non-null assertion
    width / 2,
    height / 2
  ).strength(params.radialStrength)).force("center", d33.forceCenter(width / 2, height / 2).strength(0.02));
  simulation.force("x", null).force("y", null);
}

// src/layouts/spiralLayout.ts
import * as d34 from "d3";
function applySpiralLayout(simulation, nodes, links, dimensions, params) {
  const { width, height } = dimensions;
  const numNodes = nodes.length;
  if (numNodes === 0) {
    simulation.force("link", d34.forceLink([]).id((d) => d.id));
    simulation.force("charge", null);
    simulation.force("collide", null);
    simulation.force("x", null);
    simulation.force("y", null);
    simulation.force("center", null);
    nodes.forEach((n) => {
      n.fx = null;
      n.fy = null;
    });
    return;
  }
  const maxRadius = Math.max(0, Math.min(width, height) / 2 - params.maxRadiusMargin);
  nodes.forEach((node, i) => {
    const t = numNodes > 1 ? i / (numNodes - 1) : 0.5;
    const angle = 2 * Math.PI * params.coils * t;
    const radius = numNodes > 1 ? maxRadius * t : 0;
    const targetX = width / 2 + radius * Math.cos(angle);
    const targetY = height / 2 + radius * Math.sin(angle);
    node.x = targetX;
    node.y = targetY;
    node.fx = targetX;
    node.fy = targetY;
  });
  simulation.force("link", d34.forceLink(links).id((d) => d.id).distance(params.linkDistance).strength(params.linkStrength)).force("charge", null).force("collide", null).force("x", null).force("y", null).force("center", null);
}

// components/VisualizationPanel/NetworkGraph.tsx
import { jsx as jsx15, jsxs as jsxs14 } from "react/jsx-runtime";
var ArrowsExpandIcon = ({ className }) => /* @__PURE__ */ jsx15("svg", { className: `w-5 h-5 ${className || ""}`, viewBox: "0 0 20 20", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx15("path", { d: "M2 3h3v1H3v2H2V3zm13 0h3v3h-2V4h-1V3zM2 14h3v2H3v1H2v-3zm13 0h3v3h-2v-1h-1v-2z" }) });
var DownloadIcon = ({ className }) => /* @__PURE__ */ jsx15("svg", { className: `w-5 h-5 ${className || ""}`, viewBox: "0 0 20 20", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx15("path", { fillRule: "evenodd", d: "M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z", clipRule: "evenodd" }) });
var getNodeVisualRadius = (node, svgDims) => {
  const baseRadius = node.has_piece ? VISUAL_NODE_BASE_RADIUS_PIECE : VISUAL_NODE_BASE_RADIUS_EMPTY;
  if (svgDims.width === 0 || svgDims.height === 0) return baseRadius;
  const minDim = Math.min(svgDims.width, svgDims.height);
  let scale = minDim / NODE_VISUAL_SCALING_REFERENCE_DIMENSION;
  scale = Math.max(NODE_VISUAL_SCALING_MIN_FACTOR, Math.min(NODE_VISUAL_SCALING_MAX_FACTOR, scale));
  return baseRadius * scale;
};
var NetworkGraph = ({
  nodes,
  // These are filteredSortedNodes from App.tsx
  links,
  layoutType,
  svgDimensions,
  onNodeHover,
  onNodeClick,
  selectedNodeId,
  sortConfig,
  appIsDisabled,
  currentMoveIndex,
  currentGraphScope,
  nodeColoringMetric,
  sequentialColorPalette,
  dataRangesForFilters,
  // These are the global ranges for the current scope
  currentLayoutParams
}) => {
  const svgRef = useRef(null);
  const simulationRef = useRef(null);
  const zoomRef = useRef(null);
  const gRef = useRef(null);
  const zoomTimeoutRef = useRef(null);
  const colorScale = useMemo(() => {
    if (nodeColoringMetric === "default") {
      return d35.scaleOrdinal(d35.schemeCategory10);
    }
    if (nodeColoringMetric === "component_id_color") {
      const uniqueComponentIds = Array.from(new Set(nodes.map((n) => n.component_id.toString()))).sort((a, b) => parseInt(a) - parseInt(b));
      return d35.scaleOrdinal(d35.schemeTableau10).domain(uniqueComponentIds);
    }
    if (nodeColoringMetric === "community_id_color") {
      const uniqueCommunityIds = Array.from(new Set(nodes.map((n) => n.community_id.toString()))).sort((a, b) => parseInt(a) - parseInt(b));
      return d35.scaleOrdinal(d35.schemeTableau10).domain(uniqueCommunityIds);
    }
    const metricKey = nodeColoringMetric;
    const dataRangeForMetricFromScope = dataRangesForFilters[metricKey];
    let finalDomain = [0, 1];
    const visibleNodeValues = nodes.map((n) => n[metricKey]).filter((v) => typeof v === "number" && !isNaN(v));
    if (visibleNodeValues.length > 0) {
      let minVal = Math.min(...visibleNodeValues);
      let maxVal = Math.max(...visibleNodeValues);
      if (minVal === maxVal) {
        finalDomain = [minVal - 0.5, maxVal + 0.5];
        if (minVal === 0) finalDomain = [-0.5, 0.5];
      } else {
        finalDomain = [minVal, maxVal];
      }
    } else if (dataRangeForMetricFromScope) {
      let scopeMin = dataRangeForMetricFromScope.min;
      let scopeMax = dataRangeForMetricFromScope.max;
      if (scopeMin === scopeMax) {
        finalDomain = [scopeMin - 0.5, scopeMax + 0.5];
        if (scopeMin === 0) finalDomain = [-0.5, 0.5];
      } else {
        finalDomain = [scopeMin, scopeMax];
      }
    }
    if (typeof finalDomain[0] !== "number" || typeof finalDomain[1] !== "number" || isNaN(finalDomain[0]) || isNaN(finalDomain[1]) || finalDomain[0] > finalDomain[1]) {
      finalDomain = [0, 1];
    }
    if (finalDomain[0] === 0 && finalDomain[1] === 0) {
      finalDomain = [-0.5, 0.5];
    }
    const interpolator = D3_SEQUENTIAL_INTERPOLATORS[sequentialColorPalette] || d35.interpolateViridis;
    return d35.scaleSequential(interpolator).domain(finalDomain);
  }, [nodes, nodeColoringMetric, dataRangesForFilters, sequentialColorPalette]);
  const getNodeFillColor = useCallback2((node) => {
    switch (nodeColoringMetric) {
      case "default":
        return colorScale(node.groupTag);
      case "component_id_color":
        return colorScale(node.component_id.toString());
      case "community_id_color":
        return colorScale(node.community_id.toString());
      default:
        if (NODE_METRIC_KEYS.includes(nodeColoringMetric)) {
          const value = node[nodeColoringMetric];
          if (typeof value === "number" && !isNaN(value)) {
            return colorScale(value);
          }
        }
        return "#ccc";
    }
  }, [colorScale, nodeColoringMetric]);
  const connectedNodeIds = useMemo(() => {
    if (!selectedNodeId || !links) return /* @__PURE__ */ new Set();
    const ids = /* @__PURE__ */ new Set();
    links.forEach((link) => {
      const sourceId = typeof link.source === "string" ? link.source : link.source.id;
      const targetId = typeof link.target === "string" ? link.target : link.target.id;
      if (sourceId === selectedNodeId) {
        ids.add(targetId);
      }
      if (targetId === selectedNodeId) {
        ids.add(sourceId);
      }
    });
    return ids;
  }, [selectedNodeId, links]);
  const performZoomToFit = useCallback2(() => {
    if (!svgRef.current || !gRef.current || !zoomRef.current || !nodes || nodes.length === 0 || svgDimensions.width === 0 || svgDimensions.height === 0) {
      return;
    }
    const svg = d35.select(svgRef.current);
    const g = d35.select(gRef.current);
    const zoomBehavior = zoomRef.current;
    const { width, height } = svgDimensions;
    const gNode = g.node();
    if (!gNode) return;
    const bounds = gNode.getBBox();
    if (bounds.width === 0 || bounds.height === 0 || !isFinite(bounds.x) || !isFinite(bounds.y)) {
      svg.transition().duration(layoutType === "spiral" ? 0 : 600).call(zoomBehavior.transform, d35.zoomIdentity.translate(width / 2, height / 2).scale(1));
      return;
    }
    const fullWidth = bounds.width + ZOOM_TO_FIT_PADDING * 2;
    const fullHeight = bounds.height + ZOOM_TO_FIT_PADDING * 2;
    const midX = bounds.x + bounds.width / 2;
    const midY = bounds.y + bounds.height / 2;
    const scale = Math.min(2, Math.max(0.1, Math.min(width / fullWidth, height / fullHeight)));
    const translateX = width / 2 - midX * scale;
    const translateY = height / 2 - midY * scale;
    svg.transition().duration(layoutType === "spiral" ? 0 : 600).call(zoomBehavior.transform, d35.zoomIdentity.translate(translateX, translateY).scale(scale));
  }, [nodes, layoutType, svgDimensions]);
  const handleDownloadPNG = useCallback2(() => {
    if (!svgRef.current || !nodes || nodes.length === 0 || svgDimensions.width === 0 || svgDimensions.height === 0) return;
    const PNG_EXPORT_SCALE = 2;
    const currentSvgWidth = svgDimensions.width;
    const currentSvgHeight = svgDimensions.height;
    const canvasWidth = currentSvgWidth * PNG_EXPORT_SCALE;
    const canvasHeight = currentSvgHeight * PNG_EXPORT_SCALE;
    const clonedSvgElement = svgRef.current.cloneNode(true);
    clonedSvgElement.setAttribute("width", currentSvgWidth.toString());
    clonedSvgElement.setAttribute("height", currentSvgHeight.toString());
    clonedSvgElement.removeAttribute("viewBox");
    const backgroundRect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
    backgroundRect.setAttribute("width", "100%");
    backgroundRect.setAttribute("height", "100%");
    backgroundRect.setAttribute("fill", "#ffffff");
    if (clonedSvgElement.firstChild) {
      clonedSvgElement.insertBefore(backgroundRect, clonedSvgElement.firstChild);
    } else {
      clonedSvgElement.appendChild(backgroundRect);
    }
    const serializer = new XMLSerializer();
    let svgString = serializer.serializeToString(clonedSvgElement);
    if (!svgString.includes('xmlns="http://www.w3.org/2000/svg"')) {
      svgString = svgString.replace("<svg", '<svg xmlns="http://www.w3.org/2000/svg"');
    }
    if (svgString.includes("marker-end") && !svgString.includes('xmlns:xlink="http://www.w3.org/1999/xlink"')) {
      svgString = svgString.replace("<svg", '<svg xmlns:xlink="http://www.w3.org/1999/xlink"');
    }
    const img = new Image();
    const canvas = document.createElement("canvas");
    canvas.width = canvasWidth;
    canvas.height = canvasHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      console.error("Failed to get canvas 2D context for PNG export.");
      return;
    }
    img.onload = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(img.src);
      const pngUrl = canvas.toDataURL("image/png");
      const a = document.createElement("a");
      a.href = pngUrl;
      a.download = `chess_network_move_${currentMoveIndex}_${currentGraphScope}_${layoutType}_color_${nodeColoringMetric}_palette_${sequentialColorPalette}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    };
    img.onerror = (e) => {
      console.error("Error loading SVG into image for PNG conversion:", e);
      URL.revokeObjectURL(img.src);
    };
    const svgBlob = new Blob([svgString], { type: "image/svg+xml;charset=utf-8" });
    img.src = URL.createObjectURL(svgBlob);
  }, [nodes, layoutType, currentMoveIndex, currentGraphScope, svgDimensions, nodeColoringMetric, sequentialColorPalette]);
  useEffect2(() => {
    if (!svgRef.current || !gRef.current || svgDimensions.width === 0 || svgDimensions.height === 0) return;
    const svg = d35.select(svgRef.current);
    const g = d35.select(gRef.current);
    let defs = svg.select("defs");
    if (defs.empty()) {
      defs = svg.append("defs");
    }
    let marker = defs.select("marker#arrowhead");
    if (marker.empty()) {
      marker = defs.append("marker").attr("id", "arrowhead").attr("viewBox", "0 0 10 10").attr("refX", 9).attr("refY", 5).attr("markerWidth", 6).attr("markerHeight", 6).attr("orient", "auto-start-reverse");
      marker.append("path").attr("d", "M 0 0 L 10 5 L 0 10 z").attr("fill", "#a0a0a0");
    }
    function ticked() {
      if (!gRef.current) return;
      const currentG = d35.select(gRef.current);
      currentG.selectAll(".link").attr("x1", (d) => d.source.x).attr("y1", (d) => d.source.y).attr("x2", (d_link) => {
        const s = d_link.source;
        const t = d_link.target;
        if (!s.x || !s.y || !t.x || !t.y) return t.x || 0;
        const dx = t.x - s.x;
        const dy = t.y - s.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist === 0) return t.x;
        const targetRadius = getNodeVisualRadius(t, svgDimensions) + 3;
        const scaleFactor = Math.max(0, (dist - targetRadius) / dist);
        return s.x + dx * scaleFactor;
      }).attr("y2", (d_link) => {
        const s = d_link.source;
        const t = d_link.target;
        if (!s.x || !s.y || !t.x || !t.y) return t.y || 0;
        const dx = t.x - s.x;
        const dy = t.y - s.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist === 0) return t.y;
        const targetRadius = getNodeVisualRadius(t, svgDimensions) + 3;
        const scaleFactor = Math.max(0, (dist - targetRadius) / dist);
        return s.y + dy * scaleFactor;
      });
      currentG.selectAll(".node").attr("transform", (d) => `translate(${d.x},${d.y})`);
    }
    if (!simulationRef.current) {
      simulationRef.current = d35.forceSimulation().on("tick", ticked);
    }
    const simulation = simulationRef.current;
    simulation.nodes(nodes);
    if (!zoomRef.current) {
      zoomRef.current = d35.zoom().scaleExtent([0.1, 10]).on("zoom", (event) => {
        if (gRef.current) {
          d35.select(gRef.current).attr("transform", event.transform);
        }
      });
      svg.call(zoomRef.current);
    }
    simulation.force("link", null).force("charge", null).force("collide", null).force("center", null).force("x", null).force("y", null).force("r", null);
    nodes.forEach((n) => {
      n.fx = null;
      n.fy = null;
    });
    switch (layoutType) {
      case "force-directed":
        applyForceDirectedLayout(simulation, nodes, links, svgDimensions, currentLayoutParams);
        break;
      case "radial":
        applyRadialLayout(simulation, nodes, links, svgDimensions, sortConfig, currentLayoutParams);
        break;
      case "spiral":
        applySpiralLayout(simulation, nodes, links, svgDimensions, currentLayoutParams);
        break;
    }
    const linkForce = simulation.force("link");
    if (linkForce) {
      linkForce.links(links);
    }
    simulation.alpha(0.3).restart();
  }, [nodes, links, layoutType, svgDimensions, sortConfig, currentLayoutParams]);
  useEffect2(() => {
    if (!svgRef.current || !onNodeClick) return;
    const svgElement = svgRef.current;
    const handleClick = (event) => {
      if (event.target === svgElement || event.target.classList?.contains("svg-background-rect")) {
        onNodeClick(null);
      }
    };
    svgElement.addEventListener("click", handleClick);
    return () => {
      svgElement.removeEventListener("click", handleClick);
    };
  }, [onNodeClick]);
  useEffect2(() => {
    if (!gRef.current || svgDimensions.width === 0 || !nodes) return;
    const g = d35.select(gRef.current);
    g.selectAll(".spiral-guide-path").remove();
    if (layoutType === "spiral" && svgDimensions.width > 0 && svgDimensions.height > 0 && nodes.length > 0) {
      const { width, height } = svgDimensions;
      const centerX = width / 2;
      const centerY = height / 2;
      const spiralParams = currentLayoutParams;
      const maxRadius = Math.max(0, Math.min(width, height) / 2 - spiralParams.maxRadiusMargin);
      const coils = spiralParams.coils;
      const numPathPoints = Math.max(100, nodes.length * 2);
      const spiralPoints = d35.range(numPathPoints + 1).map((i) => {
        const t = i / numPathPoints;
        const angle = 2 * Math.PI * coils * t;
        const radius = maxRadius * t;
        return [centerX + radius * Math.cos(angle), centerY + radius * Math.sin(angle)];
      });
      g.insert("path", ":first-child").datum(spiralPoints).attr("class", "spiral-guide-path").attr("fill", "none").attr("stroke", "#cbd5e1").attr("stroke-width", 0.8).attr("stroke-dasharray", "2,3").attr("d", d35.line());
    }
    g.selectAll(".hull").remove();
    g.selectAll(".link").data(links, (d) => `${d.source?.id || String(d.source)}-${d.target?.id || String(d.target)}`).join(
      (enter) => enter.append("line").attr("class", "link").attr("stroke", "#a0a0a0").attr("marker-end", "url(#arrowhead)"),
      (update) => update,
      (exit) => exit.remove()
    ).attr("stroke-width", (d) => Math.max(0.7, Math.sqrt(d.weight || 1) / 2)).transition().duration(300).style("stroke-opacity", (d_link) => {
      if (!selectedNodeId) return 0.5;
      const sourceId = typeof d_link.source === "string" ? d_link.source : d_link.source.id;
      const targetId = typeof d_link.target === "string" ? d_link.target : d_link.target.id;
      return sourceId === selectedNodeId || targetId === selectedNodeId ? 0.7 : 0.1;
    });
    const nodeSelection = g.selectAll(".node").data(nodes, (d) => d.id);
    nodeSelection.exit().remove();
    const nodeEnter = nodeSelection.enter().append("g").attr("class", "node cursor-pointer group").on("mouseover", (event, d_node) => {
      d35.select(event.currentTarget).select("circle").attr("stroke-width", 2.5).attr("stroke", "#3b82f6");
      const pieceInfo = d_node.has_piece ? `${d_node.piece_type_name} (${d_node.piece_color}, ${d_node.piece_symbol})` : "Empty";
      onNodeHover({
        content: `ID: ${d_node.id}
Piece: ${pieceInfo}
Group: ${d_node.groupTag}
In-Deg: ${d_node.in_degree_centrality.toFixed(2)}
Out-Deg: ${d_node.out_degree_centrality.toFixed(2)}`,
        x: event.pageX,
        y: event.pageY,
        visible: true
      });
    }).on("mouseout", (event, d_node) => {
      const currentTarget = event.currentTarget;
      const isSelected = d_node.id === selectedNodeId;
      const nodeFill = getNodeFillColor(d_node);
      d35.select(currentTarget).select("circle").attr("stroke-width", isSelected ? 2.5 : 1).attr("stroke", isSelected ? "#0ea5e9" : d35.color(nodeFill)?.darker(0.6).toString() || "#9ca3af");
      onNodeHover(null);
    }).on("click", (event, d_node) => {
      event.stopPropagation();
      onNodeClick(d_node);
    });
    nodeEnter.append("circle").attr("r", (d) => getNodeVisualRadius(d, svgDimensions));
    nodeEnter.append("text").attr("class", "node-label-main").attr("dy", ".35em").attr("text-anchor", "middle").style("pointer-events", "none").attr("aria-hidden", "true");
    nodeEnter.append("text").attr("class", "node-position-label").attr("text-anchor", "middle").style("pointer-events", "none").attr("aria-hidden", "true");
    const nodeUpdate = nodeEnter.merge(nodeSelection);
    nodeUpdate.transition().duration(300).style("opacity", (d_node) => {
      if (!selectedNodeId) return 1;
      return d_node.id === selectedNodeId || connectedNodeIds.has(d_node.id) ? 1 : 0.15;
    });
    nodeUpdate.select("circle").transition().duration(150).attr("r", (d) => getNodeVisualRadius(d, svgDimensions)).attr("fill", (d) => getNodeFillColor(d)).attr("stroke", (d) => {
      const nodeFill = getNodeFillColor(d);
      return d.id === selectedNodeId ? "#0ea5e9" : d35.color(nodeFill)?.darker(0.6).toString() || "#9ca3af";
    }).attr("stroke-width", (d) => d.id === selectedNodeId ? 2.5 : 1);
    nodeUpdate.select(".node-label-main").style("font-size", (d) => {
      const radius = getNodeVisualRadius(d, svgDimensions);
      if (d.has_piece) {
        return Math.max(10, Math.min(radius * 1.25, 26)) + "px";
      } else {
        return Math.max(8, Math.min(radius * 1, 13)) + "px";
      }
    }).style("font-weight", "bold").style("fill", (d) => {
      if (d.has_piece && d.piece_color) {
        return d.piece_color === "black" ? "#111827" : "#f8fafc";
      } else {
        const baseFill = getNodeFillColor(d);
        const baseHsl = d35.hsl(baseFill);
        return baseHsl.l > 0.58 ? "#1f2937" : "#f3f4f6";
      }
    }).text((d) => {
      if (d.has_piece && d.piece_symbol) {
        return PIECE_UNICODE_MAP[d.piece_symbol] || d.piece_symbol;
      } else {
        return d.id;
      }
    });
    nodeUpdate.select(".node-position-label").text((d) => d.has_piece ? d.id : "").attr("dy", (d) => getNodeVisualRadius(d, svgDimensions) + getNodeVisualRadius(d, svgDimensions) * 0.6 + 3).style("font-size", (d) => Math.max(8, Math.min(getNodeVisualRadius(d, svgDimensions) * 0.6, 14)) + "px").style("font-weight", "bold").style("fill", "#111827").style("display", (d) => d.has_piece ? null : "none");
  }, [nodes, links, getNodeFillColor, onNodeHover, onNodeClick, selectedNodeId, svgDimensions, layoutType, connectedNodeIds, nodeColoringMetric, currentLayoutParams]);
  useEffect2(() => {
    if (zoomTimeoutRef.current) {
      clearTimeout(zoomTimeoutRef.current);
      zoomTimeoutRef.current = null;
    }
    const timeoutDuration = ZOOM_SETTLE_DELAY + (layoutType === "force-directed" ? 200 : layoutType === "radial" ? 100 : 0);
    if (layoutType === "spiral") {
      performZoomToFit();
    } else {
      zoomTimeoutRef.current = window.setTimeout(performZoomToFit, timeoutDuration);
    }
    return () => {
      if (zoomTimeoutRef.current) {
        clearTimeout(zoomTimeoutRef.current);
      }
    };
  }, [performZoomToFit, layoutType, currentLayoutParams]);
  return /* @__PURE__ */ jsxs14("div", { className: "w-full h-full relative overflow-hidden", role: "figure", "aria-label": "Network graph visualization", children: [
    " ",
    /* @__PURE__ */ jsx15("svg", { ref: svgRef, width: svgDimensions.width, height: svgDimensions.height, className: "block", children: /* @__PURE__ */ jsx15("g", { ref: gRef }) }),
    !appIsDisabled && nodes.length > 0 && /* @__PURE__ */ jsxs14("div", { className: "absolute top-3 right-3 flex space-x-2", children: [
      /* @__PURE__ */ jsx15(
        "button",
        {
          onClick: handleDownloadPNG,
          className: "p-2 bg-slate-700/70 hover:bg-slate-600/90 text-slate-100 rounded-full shadow-lg transition-all duration-150 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 focus-visible:ring-opacity-75 disabled:opacity-50 disabled:cursor-not-allowed",
          "aria-label": "Download graph as HD PNG",
          title: "Download the current graph view as a high-resolution PNG image. Includes current layout, colors, and filters.",
          disabled: appIsDisabled || nodes.length === 0,
          children: /* @__PURE__ */ jsx15(DownloadIcon, { className: "w-4 h-4" })
        }
      ),
      /* @__PURE__ */ jsx15(
        "button",
        {
          onClick: performZoomToFit,
          className: "p-2 bg-slate-700/70 hover:bg-slate-600/90 text-slate-100 rounded-full shadow-lg transition-all duration-150 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 focus-visible:ring-opacity-75 disabled:opacity-50 disabled:cursor-not-allowed",
          "aria-label": "Zoom to fit all nodes",
          title: "Adjust zoom and pan to fit all currently visible nodes (after filtering) within the view.",
          disabled: appIsDisabled || nodes.length === 0,
          children: /* @__PURE__ */ jsx15(ArrowsExpandIcon, { className: "w-4 h-4" })
        }
      )
    ] })
  ] });
};
var NetworkGraph_default = NetworkGraph;

// components/VisualizationPanel/Legend.tsx
import React15, { useMemo as useMemo2, useState as useState4 } from "react";
import * as d36 from "d3";
import { jsx as jsx16, jsxs as jsxs15 } from "react/jsx-runtime";
var ChevronDownIcon2 = ({ className }) => /* @__PURE__ */ jsx16("svg", { className: `w-4 h-4 transition-transform duration-200 ${className}`, viewBox: "0 0 20 20", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx16("path", { fillRule: "evenodd", d: "M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z", clipRule: "evenodd" }) });
var formatLegendValue = (value) => {
  if (typeof value === "string") return value;
  if (typeof value !== "number" || isNaN(value)) return "N/A";
  if (Number.isInteger(value)) return value.toString();
  if (Math.abs(value) < 0.01 && value !== 0) return value.toExponential(1);
  return value.toFixed(2);
};
var Legend = ({ nodes, nodeColoringMetric, sequentialColorPalette, dataRanges }) => {
  const MAX_CATEGORICAL_ITEMS = 8;
  const [isOpen, setIsOpen] = useState4(false);
  const legendData = useMemo2(() => {
    const currentMetricOption = NODE_COLORING_METRIC_OPTIONS.find((opt) => opt.value === nodeColoringMetric);
    const title = `Color by: ${currentMetricOption?.label || "Unknown Metric"}`;
    if (nodeColoringMetric === "default") {
      const uniqueGroupTags = Array.from(new Set(nodes.map((n) => n.groupTag))).sort();
      const colorScale = d36.scaleOrdinal(d36.schemeCategory10).domain(uniqueGroupTags);
      const items = uniqueGroupTags.slice(0, MAX_CATEGORICAL_ITEMS).map((tag) => ({
        label: tag,
        color: colorScale(tag)
      }));
      return { title, items, type: "categorical", totalItems: uniqueGroupTags.length };
    }
    if (nodeColoringMetric === "component_id_color" || nodeColoringMetric === "community_id_color") {
      const idKey = nodeColoringMetric === "component_id_color" ? "component_id" : "community_id";
      const uniqueIds = Array.from(new Set(nodes.map((n) => n[idKey].toString()))).sort((a, b) => parseInt(a) - parseInt(b));
      const colorScale = d36.scaleOrdinal(d36.schemeTableau10).domain(uniqueIds);
      const items = uniqueIds.slice(0, MAX_CATEGORICAL_ITEMS).map((idStr) => ({
        label: `ID: ${idStr}`,
        color: colorScale(idStr)
      }));
      return { title, items, type: "categorical", totalItems: uniqueIds.length };
    }
    if (NODE_METRIC_KEYS.includes(nodeColoringMetric)) {
      const metricKey = nodeColoringMetric;
      let finalDomain = [0, 1];
      const visibleNodeValues = nodes.map((n) => n[metricKey]).filter((v) => typeof v === "number" && !isNaN(v) && isFinite(v));
      if (visibleNodeValues.length > 0) {
        let minVal = Math.min(...visibleNodeValues);
        let maxVal = Math.max(...visibleNodeValues);
        if (minVal === maxVal) {
          finalDomain = [minVal - 0.5, maxVal + 0.5];
          if (minVal === 0) finalDomain = [-0.5, 0.5];
        } else {
          finalDomain = [minVal, maxVal];
        }
      } else if (dataRanges[metricKey]) {
        const dr = dataRanges[metricKey];
        let scopeMin = typeof dr.min === "number" && isFinite(dr.min) ? dr.min : 0;
        let scopeMax = typeof dr.max === "number" && isFinite(dr.max) ? dr.max : 1;
        if (scopeMin > scopeMax) [scopeMin, scopeMax] = [scopeMax, scopeMin];
        if (scopeMin === scopeMax) {
          finalDomain = [scopeMin - 0.5, scopeMax + 0.5];
          if (scopeMin === 0) finalDomain = [-0.5, 0.5];
        } else {
          finalDomain = [scopeMin, scopeMax];
        }
      }
      if (typeof finalDomain[0] !== "number" || typeof finalDomain[1] !== "number" || isNaN(finalDomain[0]) || isNaN(finalDomain[1]) || !isFinite(finalDomain[0]) || !isFinite(finalDomain[1]) || finalDomain[0] > finalDomain[1]) {
        finalDomain = [0, 1];
      }
      if (finalDomain[0] === 0 && finalDomain[1] === 0) {
        finalDomain = [-0.5, 0.5];
      }
      const domain = finalDomain;
      const interpolator = D3_SEQUENTIAL_INTERPOLATORS[sequentialColorPalette] || d36.interpolateViridis;
      const colorScale = d36.scaleSequential(interpolator).domain(domain);
      const numTicksDesired = 5;
      let tickValuesFromD3 = d36.ticks(domain[0], domain[1], numTicksDesired);
      const tickSet = /* @__PURE__ */ new Set();
      tickValuesFromD3.forEach((t) => {
        if (isFinite(t)) tickSet.add(t);
      });
      if (isFinite(domain[0])) tickSet.add(domain[0]);
      if (isFinite(domain[1])) tickSet.add(domain[1]);
      let finalTickValues = Array.from(tickSet).filter((v) => typeof v === "number" && !isNaN(v) && isFinite(v)).sort((a, b) => a - b);
      if (domain[0] === domain[1]) {
        finalTickValues = [domain[0]];
      } else if (finalTickValues.length < 2) {
        finalTickValues = [domain[0], domain[1]];
      }
      finalTickValues = [...new Set(finalTickValues)].sort((a, b) => a - b);
      const items = finalTickValues.map((value) => ({
        label: formatLegendValue(value),
        color: colorScale(value)
      }));
      return { title, items, type: "sequential", domain };
    }
    return { title, items: [], type: "categorical", totalItems: 0, domain: [0, 1] };
  }, [nodes, nodeColoringMetric, dataRanges, sequentialColorPalette]);
  const shouldRenderContent = legendData.items.length > 0 && legendData.type !== "sequential" || legendData.type === "sequential" && legendData.domain && legendData.items.length >= (legendData.domain[0] === legendData.domain[1] ? 1 : 2);
  if (!shouldRenderContent && !isOpen) return null;
  if (legendData.items.length === 0 && legendData.type !== "sequential" && !isOpen) {
    return null;
  }
  return /* @__PURE__ */ jsxs15(
    "div",
    {
      className: `p-2.5 bg-slate-700/80 backdrop-blur-sm rounded-lg shadow-xl absolute bottom-3 right-3 ${isOpen ? "max-h-60" : ""} overflow-hidden text-xs border border-slate-600/60 custom-scrollbar`,
      "aria-label": legendData.title,
      children: [
        /* @__PURE__ */ jsxs15(
          "button",
          {
            onClick: () => setIsOpen(!isOpen),
            className: "w-full flex justify-between items-center text-left focus:outline-none focus-visible:ring-1 focus-visible:ring-sky-300 rounded-sm",
            "aria-expanded": isOpen,
            "aria-controls": "legend-content",
            title: `Click to ${isOpen ? "collapse" : "expand"} legend`,
            children: [
              /* @__PURE__ */ jsx16("h4", { className: "font-semibold text-slate-100 text-xs tracking-wide", children: legendData.title }),
              /* @__PURE__ */ jsx16(ChevronDownIcon2, { className: `text-slate-300 ${isOpen ? "transform rotate-180" : ""}` })
            ]
          }
        ),
        isOpen && shouldRenderContent && legendData.domain && // legendData.domain check for sequential
        /* @__PURE__ */ jsxs15("div", { id: "legend-content", className: `mt-2 ${isOpen ? "max-h-48 overflow-y-auto custom-scrollbar" : ""}`, children: [
          legendData.type === "categorical" && /* @__PURE__ */ jsx16("div", { className: "max-h-44 overflow-y-auto custom-scrollbar pr-1", children: legendData.items.map((item) => /* @__PURE__ */ jsxs15("div", { className: "flex items-center space-x-1.5 mb-1", children: [
            /* @__PURE__ */ jsx16(
              "div",
              {
                className: "w-2.5 h-2.5 rounded-sm border border-gray-400/40 flex-shrink-0",
                style: { backgroundColor: item.color },
                "aria-hidden": "true"
              }
            ),
            /* @__PURE__ */ jsx16("span", { className: "text-slate-200 text-[10px] truncate", title: item.label, children: item.label })
          ] }, item.label)) }),
          legendData.type === "categorical" && legendData.totalItems && legendData.totalItems > MAX_CATEGORICAL_ITEMS && /* @__PURE__ */ jsxs15("p", { className: "text-slate-300/80 mt-1.5 text-[10px] text-center", children: [
            "...and ",
            legendData.totalItems - MAX_CATEGORICAL_ITEMS,
            " more"
          ] }),
          legendData.type === "sequential" && legendData.domain && legendData.items.length >= (legendData.domain[0] === legendData.domain[1] ? 1 : 2) && /* @__PURE__ */ jsxs15("div", { className: "space-y-1 pt-1", children: [
            /* @__PURE__ */ jsx16(
              "div",
              {
                className: "w-full h-3.5 rounded-sm",
                style: { background: `linear-gradient(to right, ${legendData.items.map((i) => i.color).join(",")})` },
                title: `Gradient from ${formatLegendValue(legendData.domain[0])} to ${formatLegendValue(legendData.domain[1])}`
              }
            ),
            /* @__PURE__ */ jsxs15("div", { className: "flex justify-between text-[10px] text-slate-300 px-0.5", children: [
              /* @__PURE__ */ jsx16("span", { title: `Minimum value in range: ${formatLegendValue(legendData.domain[0])}`, children: formatLegendValue(legendData.domain[0]) }),
              /* @__PURE__ */ jsx16("span", { title: `Maximum value in range: ${formatLegendValue(legendData.domain[1])}`, children: formatLegendValue(legendData.domain[1]) })
            ] })
          ] })
        ] }),
        isOpen && !shouldRenderContent && /* @__PURE__ */ jsx16("p", { className: "text-slate-400 text-[10px] mt-1.5 italic", children: "No legend data to display for current settings." })
      ]
    }
  );
};
var Legend_default = React15.memo(Legend);

// components/InfoPanel/StatsDisplay.tsx
import React16 from "react";
import { jsx as jsx17, jsxs as jsxs16 } from "react/jsx-runtime";
var StatsDisplay = ({ stats, disabled }) => {
  if (disabled || !stats) {
    return /* @__PURE__ */ jsx17("div", { className: `py-1 ${disabled ? "opacity-60" : ""}`, children: /* @__PURE__ */ jsx17("p", { className: "text-xs text-slate-400", children: "Load data to view statistics." }) });
  }
  const formatValue = (value) => {
    if (value === null || value === void 0 || isNaN(value)) return "N/A";
    if (["out_diameter", "in_diameter"].includes(itemLabel.toLowerCase().replace(/\s/g, "_")) && Number.isInteger(value)) {
      return value.toString();
    }
    if (Number.isInteger(value)) return value.toString();
    if (Math.abs(value) < 1e-3 && value !== 0) return value.toExponential(2);
    return value.toFixed(3);
  };
  let itemLabel = "";
  const statItems = [
    { label: "Fiedler Value", value: stats.fiedler_value, important: true, tooltip: "Fiedler Value (Algebraic Connectivity): Measures graph connectivity. Higher values indicate a more robustly connected graph." },
    { label: "Modularity", value: stats.modularity, important: true, tooltip: "Modularity: Strength of division of a network into modules. Positive values indicate community structure." },
    { label: "Community Count", value: stats.community_count, tooltip: "Total number of detected communities." },
    { label: "Clustering Coeff.", value: stats.clustering, tooltip: "Global Clustering Coefficient: Degree to which nodes tend to cluster together." },
    { label: "Out-Diameter", value: stats.out_diameter, tooltip: "Out-Diameter: Longest shortest path considering edge directions (outgoing)." },
    { label: "In-Diameter", value: stats.in_diameter, tooltip: "In-Diameter: Longest shortest path traversing edges in reverse (incoming)." },
    { label: "Avg. In-Degree", value: stats.in_degree_avg, tooltip: "Average In-Degree: Average number of incoming links per node." },
    { label: "In-Degree Var.", value: stats.in_degree_var, tooltip: "In-Degree Variance: Statistical variance of in-degrees across nodes." },
    { label: "Avg. Out-Degree", value: stats.out_degree_avg, tooltip: "Average Out-Degree: Average number of outgoing links per node." },
    { label: "Out-Degree Var.", value: stats.out_degree_var, tooltip: "Out-Degree Variance: Statistical variance of out-degrees across nodes." },
    { label: "Avg. In-Betweenness", value: stats.in_betweenness_avg, tooltip: "Average In-Betweenness Centrality: Average of how often nodes appear on shortest paths leading to them." },
    { label: "In-Betweenness Var.", value: stats.in_betweenness_var, tooltip: "In-Betweenness Centrality Variance: Variance of in-betweenness centrality." },
    { label: "Avg. Out-Betweenness", value: stats.out_betweenness_avg, tooltip: "Average Out-Betweenness Centrality: Average of how often nodes appear on shortest paths originating from them." },
    { label: "Out-Betweenness Var.", value: stats.out_betweenness_var, tooltip: "Out-Betweenness Centrality Variance: Variance of out-betweenness centrality." },
    { label: "Avg. In-Closeness", value: stats.in_closeness_avg, tooltip: "Average In-Closeness Centrality: Average of how close nodes are to all other nodes reachable by incoming paths." },
    { label: "In-Closeness Var.", value: stats.in_closeness_var, tooltip: "In-Closeness Centrality Variance: Variance of in-closeness centrality." },
    { label: "Avg. Out-Closeness", value: stats.out_closeness_avg, tooltip: "Average Out-Closeness Centrality: Average of how close nodes are to all other nodes they can reach." },
    { label: "Out-Closeness Var.", value: stats.out_closeness_var, tooltip: "Out-Closeness Centrality Variance: Variance of out-closeness centrality." },
    { label: "Size Entropy", value: stats.size_entropy, tooltip: "Size Entropy of Components: Measures diversity in component sizes." }
  ];
  return /* @__PURE__ */ jsx17("div", { className: "py-1", children: /* @__PURE__ */ jsx17("dl", { className: "grid grid-cols-1 md:grid-cols-2 gap-x-3 gap-y-1 text-xs", children: statItems.map((item) => {
    itemLabel = item.label;
    return /* @__PURE__ */ jsxs16("div", { className: `flex justify-between items-baseline py-0.5 ${item.important ? "col-span-1 md:col-span-2 border-b border-slate-600/70" : ""}`, children: [
      /* @__PURE__ */ jsxs16("dt", { className: "text-slate-300 truncate pr-1", title: item.tooltip || item.label, children: [
        item.label,
        ":"
      ] }),
      /* @__PURE__ */ jsx17("dd", { className: `font-medium ${item.important ? "text-sky-300 text-sm" : "text-slate-100"} tabular-nums`, children: formatValue(item.value) })
    ] }, item.label);
  }) }) });
};
var StatsDisplay_default = React16.memo(StatsDisplay);

// components/InfoPanel/CapturedPieces.tsx
import React17 from "react";
import { jsx as jsx18, jsxs as jsxs17 } from "react/jsx-runtime";
var CapturedPiecesDisplay = ({ capturedPieces, disabled }) => {
  if (disabled) {
    return /* @__PURE__ */ jsx18("div", { className: `py-1 ${disabled ? "opacity-60" : ""}`, children: /* @__PURE__ */ jsx18("p", { className: "text-xs text-slate-400", children: "Load data to view captured pieces." }) });
  }
  const whiteCaptured = capturedPieces.filter((p) => p.c === "black");
  const blackCaptured = capturedPieces.filter((p) => p.c === "white");
  const renderPieceList = (pieces, capturerColor) => /* @__PURE__ */ jsxs17("div", { className: "mt-1", children: [
    /* @__PURE__ */ jsxs17(
      "h4",
      {
        className: "text-xs font-medium text-slate-300",
        title: `List of ${capturerColor === "White" ? "Black" : "White"} pieces that have been captured by ${capturerColor} up to the current move.`,
        children: [
          capturerColor,
          "'s Captures:"
        ]
      }
    ),
    pieces.length === 0 ? /* @__PURE__ */ jsx18("p", { className: "text-xs text-slate-400 italic ml-1", children: "None" }) : /* @__PURE__ */ jsx18("div", { className: "flex flex-wrap gap-x-1.5 gap-y-0.5 text-xl leading-none text-slate-100 pt-1", children: pieces.map((p) => {
      let pieceKeyForUnicode = void 0;
      const pieceTypeInitial = p.t === "Knight" ? "N" : p.t[0]?.toUpperCase();
      if (pieceTypeInitial) {
        pieceKeyForUnicode = p.c === "white" ? pieceTypeInitial.toUpperCase() : pieceTypeInitial.toLowerCase();
        if (p.t === "Knight") {
          pieceKeyForUnicode = p.c === "white" ? "N" : "n";
        }
      }
      const unicodeSymbol = pieceKeyForUnicode ? PIECE_UNICODE_MAP[pieceKeyForUnicode] || pieceKeyForUnicode : p.t[0];
      return /* @__PURE__ */ jsx18(
        "span",
        {
          title: `${p.c.charAt(0).toUpperCase() + p.c.slice(1)} ${p.t} (ID: ${p.id}) captured on move ${p.cap}. Originally on square ${p.sq}.`,
          className: "transition-transform hover:scale-110",
          "aria-label": `${p.c} ${p.t} captured`,
          children: unicodeSymbol
        },
        p.id
      );
    }) })
  ] });
  return /* @__PURE__ */ jsxs17("div", { className: "py-1", children: [
    renderPieceList(whiteCaptured, "White"),
    renderPieceList(blackCaptured, "Black"),
    whiteCaptured.length === 0 && blackCaptured.length === 0 && /* @__PURE__ */ jsx18("p", { className: "text-xs text-slate-400 italic mt-1", children: "No pieces captured yet in the game up to the current move." })
  ] });
};
var CapturedPieces_default = React17.memo(CapturedPiecesDisplay);

// components/InfoPanel/SelectedNodeInfo.tsx
import React18 from "react";
import { jsx as jsx19, jsxs as jsxs18 } from "react/jsx-runtime";
var SelectedNodeInfo = ({ nodeData }) => {
  if (!nodeData) {
    return null;
  }
  const {
    id,
    piece_symbol,
    piece_color,
    piece_type,
    // piece_type is now string like "Pawn"
    component_id,
    community_id,
    // Centralities
    in_degree_centrality,
    out_degree_centrality,
    in_betweenness_centrality,
    out_betweenness_centrality,
    in_closeness_centrality,
    out_closeness_centrality,
    // Global Variances
    in_degree_centrality_variance,
    out_degree_centrality_variance,
    in_betweenness_centrality_variance,
    out_betweenness_centrality_variance,
    in_closeness_centrality_variance,
    out_closeness_centrality_variance,
    // Component Averages
    in_degree_component_avg,
    out_degree_component_avg,
    in_betweenness_component_avg,
    out_betweenness_component_avg,
    in_closeness_component_avg,
    out_closeness_component_avg,
    // Component Variances
    in_degree_component_var,
    out_degree_component_var,
    in_betweenness_component_var,
    out_betweenness_component_var,
    in_closeness_component_var,
    out_closeness_component_var,
    // Deviations
    in_degree_deviation,
    out_degree_deviation,
    in_betweenness_deviation,
    out_betweenness_deviation,
    in_closeness_deviation,
    out_closeness_deviation,
    ...otherMetrics
    // Catch any other metrics if needed
  } = nodeData;
  const metricTooltips = {
    "Piece": "Information about the chess piece currently on this square.",
    "Component ID": "ID of the connected component this square belongs to.",
    "Community ID": "ID of the community (dense subgraph) this square belongs to.",
    "In-Degree": "In-Degree Centrality: Number of incoming influence links.",
    "Out-Degree": "Out-Degree Centrality: Number of outgoing influence links.",
    "In-Betweenness": "In-Betweenness Centrality: How often this node lies on shortest paths for incoming influence.",
    "Out-Betweenness": "Out-Betweenness Centrality: How often this node lies on shortest paths for outgoing influence.",
    "In-Closeness": "In-Closeness Centrality: Average shortest distance from all other nodes influencing this node.",
    "Out-Closeness": "Out-Closeness Centrality: Average shortest distance from this node to all nodes it influences.",
    "In-Degree Var. (Global)": "Global variance of In-Degree Centrality across all nodes in graph scope.",
    "Out-Degree Var. (Global)": "Global variance of Out-Degree Centrality across all nodes.",
    "In-Betweenness Var. (Global)": "Global variance of In-Betweenness Centrality.",
    "Out-Betweenness Var. (Global)": "Global variance of Out-Betweenness Centrality.",
    "In-Closeness Var. (Global)": "Global variance of In-Closeness Centrality.",
    "Out-Closeness Var. (Global)": "Global variance of Out-Closeness Centrality.",
    "Avg Comp In-Degree": "Average In-Degree of this node's component.",
    "Avg Comp Out-Degree": "Average Out-Degree of this node's component.",
    "Avg Comp In-Betweenness": "Average In-Betweenness of this node's component.",
    "Avg Comp Out-Betweenness": "Average Out-Betweenness of this node's component.",
    "Avg Comp In-Closeness": "Average In-Closeness of this node's component.",
    "Avg Comp Out-Closeness": "Average Out-Closeness of this node's component.",
    "Comp In-Degree Var.": "Variance of In-Degree within this node's component.",
    "Comp Out-Degree Var.": "Variance of Out-Degree within this node's component.",
    "Comp In-Betweenness Var.": "Variance of In-Betweenness within this node's component.",
    "Comp Out-Betweenness Var.": "Variance of Out-Betweenness within this node's component.",
    "Comp In-Closeness Var.": "Variance of In-Closeness within this node's component.",
    "Comp Out-Closeness Var.": "Variance of Out-Closeness within this node's component.",
    "In-Degree Dev.": "Deviation of this node's In-Degree from its component average.",
    "Out-Degree Dev.": "Deviation of this node's Out-Degree from its component average.",
    "In-Betweenness Dev.": "Deviation of In-Betweenness from component average.",
    "Out-Betweenness Dev.": "Deviation of Out-Betweenness from component average.",
    "In-Closeness Dev.": "Deviation of In-Closeness from component average.",
    "Out-Closeness Dev.": "Deviation of Out-Closeness from component average."
  };
  const displayMetrics = [
    { label: "Piece", value: piece_symbol ? `${piece_type || "Unknown Type"} (${piece_color || "N/A"}, ${piece_symbol})` : "Empty", tooltip: metricTooltips["Piece"] },
    { label: "Component ID", value: component_id, tooltip: metricTooltips["Component ID"] },
    { label: "Community ID", value: community_id, tooltip: metricTooltips["Community ID"] },
    { label: "In-Degree", value: in_degree_centrality, tooltip: metricTooltips["In-Degree"] },
    { label: "Out-Degree", value: out_degree_centrality, tooltip: metricTooltips["Out-Degree"] },
    { label: "In-Betweenness", value: in_betweenness_centrality, tooltip: metricTooltips["In-Betweenness"] },
    { label: "Out-Betweenness", value: out_betweenness_centrality, tooltip: metricTooltips["Out-Betweenness"] },
    { label: "In-Closeness", value: in_closeness_centrality, tooltip: metricTooltips["In-Closeness"] },
    { label: "Out-Closeness", value: out_closeness_centrality, tooltip: metricTooltips["Out-Closeness"] },
    { label: "In-Degree Var. (Global)", value: in_degree_centrality_variance, tooltip: metricTooltips["In-Degree Var. (Global)"] },
    { label: "Out-Degree Var. (Global)", value: out_degree_centrality_variance, tooltip: metricTooltips["Out-Degree Var. (Global)"] },
    { label: "In-Betweenness Var. (Global)", value: in_betweenness_centrality_variance, tooltip: metricTooltips["In-Betweenness Var. (Global)"] },
    { label: "Out-Betweenness Var. (Global)", value: out_betweenness_centrality_variance, tooltip: metricTooltips["Out-Betweenness Var. (Global)"] },
    { label: "In-Closeness Var. (Global)", value: in_closeness_centrality_variance, tooltip: metricTooltips["In-Closeness Var. (Global)"] },
    { label: "Out-Closeness Var. (Global)", value: out_closeness_centrality_variance, tooltip: metricTooltips["Out-Closeness Var. (Global)"] },
    { label: "Avg Comp In-Degree", value: in_degree_component_avg, tooltip: metricTooltips["Avg Comp In-Degree"] },
    { label: "Avg Comp Out-Degree", value: out_degree_component_avg, tooltip: metricTooltips["Avg Comp Out-Degree"] },
    { label: "Avg Comp In-Betweenness", value: in_betweenness_component_avg, tooltip: metricTooltips["Avg Comp In-Betweenness"] },
    { label: "Avg Comp Out-Betweenness", value: out_betweenness_component_avg, tooltip: metricTooltips["Avg Comp Out-Betweenness"] },
    { label: "Avg Comp In-Closeness", value: in_closeness_component_avg, tooltip: metricTooltips["Avg Comp In-Closeness"] },
    { label: "Avg Comp Out-Closeness", value: out_closeness_component_avg, tooltip: metricTooltips["Avg Comp Out-Closeness"] },
    { label: "Comp In-Degree Var.", value: in_degree_component_var, tooltip: metricTooltips["Comp In-Degree Var."] },
    { label: "Comp Out-Degree Var.", value: out_degree_component_var, tooltip: metricTooltips["Comp Out-Degree Var."] },
    { label: "Comp In-Betweenness Var.", value: in_betweenness_component_var, tooltip: metricTooltips["Comp In-Betweenness Var."] },
    { label: "Comp Out-Betweenness Var.", value: out_betweenness_component_var, tooltip: metricTooltips["Comp Out-Betweenness Var."] },
    { label: "Comp In-Closeness Var.", value: in_closeness_component_var, tooltip: metricTooltips["Comp In-Closeness Var."] },
    { label: "Comp Out-Closeness Var.", value: out_closeness_component_var, tooltip: metricTooltips["Comp Out-Closeness Var."] },
    { label: "In-Degree Dev.", value: in_degree_deviation, tooltip: metricTooltips["In-Degree Dev."] },
    { label: "Out-Degree Dev.", value: out_degree_deviation, tooltip: metricTooltips["Out-Degree Dev."] },
    { label: "In-Betweenness Dev.", value: in_betweenness_deviation, tooltip: metricTooltips["In-Betweenness Dev."] },
    { label: "Out-Betweenness Dev.", value: out_betweenness_deviation, tooltip: metricTooltips["Out-Betweenness Dev."] },
    { label: "In-Closeness Dev.", value: in_closeness_deviation, tooltip: metricTooltips["In-Closeness Dev."] },
    { label: "Out-Closeness Dev.", value: out_closeness_deviation, tooltip: metricTooltips["Out-Closeness Dev."] }
  ];
  const formatValue = (val) => {
    if (typeof val === "number") {
      if (Number.isInteger(val)) return val.toString();
      if (Math.abs(val) < 1e-3 && val !== 0) return val.toExponential(2);
      return val.toFixed(3);
    }
    return String(val);
  };
  return /* @__PURE__ */ jsxs18("div", { className: "max-h-[calc(50vh-3rem)] overflow-y-auto custom-scrollbar", children: [
    /* @__PURE__ */ jsxs18("h3", { className: "text-sm font-semibold text-slate-100 mb-0.5 sticky top-0 bg-slate-700/90 backdrop-blur-sm py-1.5 -mx-3 px-3 border-b border-slate-600", children: [
      "Node: ",
      /* @__PURE__ */ jsx19("span", { className: "text-sky-300 font-bold", children: nodeData.id })
    ] }),
    /* @__PURE__ */ jsx19("dl", { className: "space-y-0.5 text-xs mt-1.5", children: displayMetrics.map((item) => {
      if (item.value === void 0 || item.value === null || typeof item.value === "number" && isNaN(item.value)) {
        return null;
      }
      return /* @__PURE__ */ jsxs18("div", { className: "flex justify-between items-baseline py-0.5 border-b border-slate-600/80 last:border-b-0", children: [
        /* @__PURE__ */ jsxs18("dt", { className: "text-slate-300 truncate pr-1.5", title: item.tooltip || item.label, children: [
          item.label,
          ":"
        ] }),
        /* @__PURE__ */ jsx19("dd", { className: "font-medium text-slate-100 text-right pl-1.5 tabular-nums", children: formatValue(item.value) })
      ] }, item.label);
    }) })
  ] });
};
var SelectedNodeInfo_default = React18.memo(SelectedNodeInfo);

// hooks/useResizeObserver.ts
import { useState as useState5, useEffect as useEffect3 } from "react";
function useResizeObserver(ref) {
  const [dimensions, setDimensions] = useState5({ width: 0, height: 0 });
  useEffect3(() => {
    const element = ref.current;
    if (!element) return;
    const observer = new ResizeObserver((entries) => {
      if (entries[0]) {
        const { width: width2, height: height2 } = entries[0].contentRect;
        setDimensions({ width: width2, height: height2 });
      }
    });
    observer.observe(element);
    const { width, height } = element.getBoundingClientRect();
    setDimensions({ width, height });
    return () => {
      observer.unobserve(element);
    };
  }, [ref]);
  return dimensions;
}
var useResizeObserver_default = useResizeObserver;

// App.tsx
import { jsx as jsx20, jsxs as jsxs19 } from "react/jsx-runtime";
var ChevronDownIcon3 = ({ className }) => /* @__PURE__ */ jsx20("svg", { className: `w-5 h-5 transition-transform duration-200 ${className}`, viewBox: "0 0 20 20", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx20("path", { fillRule: "evenodd", d: "M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z", clipRule: "evenodd" }) });
var ChevronLeftIcon2 = ({ className }) => /* @__PURE__ */ jsx20("svg", { className: `w-5 h-5 ${className || ""}`, viewBox: "0 0 20 20", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx20("path", { fillRule: "evenodd", d: "M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z", clipRule: "evenodd" }) });
var ChevronRightIcon2 = ({ className }) => /* @__PURE__ */ jsx20("svg", { className: `w-5 h-5 ${className || ""}`, viewBox: "0 0 20 20", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx20("path", { fillRule: "evenodd", d: "M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z", clipRule: "evenodd" }) });
var RefreshIcon = ({ className }) => /* @__PURE__ */ jsx20("svg", { className: `w-4 h-4 ${className || ""}`, viewBox: "0 0 20 20", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx20("path", { fillRule: "evenodd", d: "M15.322 10.707a5.001 5.001 0 00-7.59-4.152L6.455 7.83A3.001 3.001 0 0111.95 9.57l.975 1.013a1 1 0 01-1.438 1.392l-1.303-.782a3.001 3.001 0 01-3.583-2.508L2.85 5.505a1 1 0 011.04-1.634l2.692.976A5.001 5.001 0 0015.322 10.707zm-.827 3.289a1 1 0 01-1.04 1.634l-2.691-.976a5.001 5.001 0 00-7.772-5.638L4.678 9.293a1 1 0 011.438-1.392l1.303.782a3.001 3.001 0 013.583 2.508l3.755 2.176a1 1 0 01-.696 1.81z", clipRule: "evenodd" }) });
var DatabaseIcon = ({ className }) => /* @__PURE__ */ jsx20("svg", { className: `w-5 h-5 ${className || ""}`, viewBox: "0 0 20 20", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx20("path", { fillRule: "evenodd", d: "M3 5a2 2 0 012-2h10a2 2 0 012 2v2.28a1 1 0 01-.4.8L12 10.4V15a1 1 0 01-1 1H9a1 1 0 01-1-1v-4.6L3.4 8.08A1 1 0 013 7.28V5zm1 0v1.586l4.293 2.146a.5.5 0 00.414 0L13 6.586V5H4zm10.293 8.293a1 1 0 011.414 0l.001.001.001.001a1.002 1.002 0 010 1.413l-.001.001a1.002 1.002 0 01-1.414 0L12 13.414l-2.293 2.293a1 1 0 01-1.414-1.414l2.293-2.293L9.172 10.5H10V8H8v2.5a.5.5 0 00.146.354l2.5 2.5zM10 11.414l-1.293-1.293a1 1 0 010-1.414L10 7.414l1.293 1.293a1 1 0 010 1.414L10 11.414z", clipRule: "evenodd" }) });
var CollapsibleSection = ({ title, children, defaultOpen = true, className, headerClassName, contentClassName, actionButton, tooltip }) => {
  const [isOpen, setIsOpen] = useState6(defaultOpen);
  return /* @__PURE__ */ jsxs19("div", { className: `bg-slate-700/80 rounded-lg shadow-md border border-slate-600/60 ${className || ""}`, children: [
    /* @__PURE__ */ jsxs19("div", { className: `flex justify-between items-center w-full p-2.5 text-left ${headerClassName || ""} ${isOpen ? "rounded-t-lg" : "rounded-lg"} hover:bg-slate-600/50 transition-colors duration-150`, children: [
      /* @__PURE__ */ jsxs19(
        "button",
        {
          onClick: () => setIsOpen(!isOpen),
          className: "flex-grow flex items-center text-xs sm:text-sm font-semibold text-slate-100 focus:outline-none focus-visible:ring-1 focus-visible:ring-sky-300",
          "aria-expanded": isOpen,
          title: tooltip || `Click to ${isOpen ? "collapse" : "expand"} the '${title}' section`,
          children: [
            /* @__PURE__ */ jsx20("span", { children: title }),
            /* @__PURE__ */ jsx20(ChevronDownIcon3, { className: `ml-1.5 sm:ml-2 text-slate-300 ${isOpen ? "transform rotate-180" : ""}` })
          ]
        }
      ),
      actionButton && /* @__PURE__ */ jsx20("div", { className: "flex-shrink-0 ml-2", children: actionButton })
    ] }),
    isOpen && /* @__PURE__ */ jsx20("div", { className: `p-2.5 border-t border-slate-600/50 ${contentClassName || ""}`, children })
  ] });
};
function App() {
  const [rawData, setRawData] = useState6(null);
  const [currentMoveIndex, setCurrentMoveIndex] = useState6(0);
  const [currentGraphScope, setCurrentGraphScope] = useState6("combined");
  const [processedMoveData, setProcessedMoveData] = useState6(null);
  const [filters, setFilters] = useState6(INITIAL_FILTERS_STATE);
  const [sortConfig, setSortConfig] = useState6({ key: "id", order: "asc" });
  const [layoutType, setLayoutType] = useState6("force-directed");
  const [layoutParams, setLayoutParams] = useState6(DEFAULT_LAYOUT_PARAMS);
  const [nodeColoringMetric, setNodeColoringMetric] = useState6("default");
  const [sequentialColorPalette, setSequentialColorPalette] = useState6("viridis");
  const [tooltip, setTooltip] = useState6(null);
  const [selectedNode, setSelectedNode] = useState6(null);
  const [isLoading, setIsLoading] = useState6(false);
  const [error, setError] = useState6(null);
  const [fileName, setFileName] = useState6(null);
  const [isLeftSidebarOpen, setIsLeftSidebarOpen] = useState6(true);
  const visualizationPanelRef = useRef2(null);
  const svgDimensions = useResizeObserver_default(visualizationPanelRef);
  const appIsDisabled = !rawData || isLoading;
  const isNodeColoringNumeric = useMemo3(
    () => NODE_METRIC_KEYS.includes(nodeColoringMetric),
    [nodeColoringMetric]
  );
  useEffect4(() => {
    if (rawData && rawData.moves.length > 0) {
      const currentMoveExists = currentMoveIndex >= 0 && currentMoveIndex < rawData.moves.length;
      if (!currentMoveExists) {
        const newIndex = Math.max(0, Math.min(currentMoveIndex, rawData.moves.length - 1));
        setCurrentMoveIndex(newIndex);
        return;
      }
      const move = rawData.moves[currentMoveIndex];
      if (move) {
        setIsLoading(true);
        try {
          const newProcessedData = processMoveData(move, currentGraphScope);
          setProcessedMoveData(newProcessedData);
          setFilters((prevFilters) => {
            const newFilters = { ...prevFilters };
            NODE_METRIC_KEYS.forEach((key) => {
              const newRange = newProcessedData.dataRangesForFilters[key];
              const oldFilterValue = prevFilters[key];
              if (newRange && oldFilterValue && typeof oldFilterValue === "object" && "currentMin" in oldFilterValue) {
                const oldDataMin = oldFilterValue.dataMin;
                const oldDataMax = oldFilterValue.dataMax;
                let newCurrentMin = newRange.min;
                let newCurrentMax = newRange.max;
                if (oldDataMin !== newRange.min || oldDataMax !== newRange.max) {
                  newCurrentMin = newRange.min;
                  newCurrentMax = newRange.max;
                } else {
                  newCurrentMin = Math.max(newRange.min, Math.min(oldFilterValue.currentMin, newRange.max));
                  newCurrentMax = Math.max(newRange.min, Math.min(oldFilterValue.currentMax, newRange.max));
                }
                newFilters[key] = {
                  currentMin: newCurrentMin,
                  currentMax: newCurrentMax,
                  dataMin: newRange.min,
                  dataMax: newRange.max
                };
              } else if (newRange) {
                newFilters[key] = {
                  currentMin: newRange.min,
                  currentMax: newRange.max,
                  dataMin: newRange.min,
                  dataMax: newRange.max
                };
              }
            });
            return newFilters;
          });
        } catch (e) {
          console.error("Error processing move data:", e);
          setError(`Error processing move: ${e.message}`);
          setProcessedMoveData(null);
        } finally {
          setIsLoading(false);
        }
      }
    } else {
      setProcessedMoveData(null);
      setFilters(INITIAL_FILTERS_STATE);
    }
    setSelectedNode(null);
  }, [rawData, currentMoveIndex, currentGraphScope]);
  const handleFileUpload = useCallback3((data, name) => {
    if (data) {
      setRawData(data);
      setCurrentMoveIndex(0);
      setCurrentGraphScope("combined");
      setLayoutType("force-directed");
      setLayoutParams(DEFAULT_LAYOUT_PARAMS);
      setNodeColoringMetric("default");
      setError(null);
      setFileName(name);
      setFilters(INITIAL_FILTERS_STATE);
      setSelectedNode(null);
    } else {
      setRawData(null);
      setProcessedMoveData(null);
      setFileName(null);
    }
  }, []);
  const { filteredSortedNodes, filteredLinks } = useMemo3(() => {
    if (!processedMoveData) return { filteredSortedNodes: [], filteredLinks: [] };
    return applyFiltersAndSort(processedMoveData.nodes, processedMoveData.links, filters, sortConfig);
  }, [processedMoveData, filters, sortConfig]);
  const capturedPieces = useMemo3(() => {
    if (!rawData) return [];
    return getCapturedPieces(rawData.moves, currentMoveIndex);
  }, [rawData, currentMoveIndex]);
  const handleNumericFilterChange = useCallback3((filterKey, newRange) => {
    setFilters((prev) => {
      const existingFilter = prev[filterKey];
      if (typeof existingFilter === "object" && "currentMin" in existingFilter) {
        const updatedMin = newRange.min !== void 0 ? Math.max(existingFilter.dataMin, Math.min(newRange.min, existingFilter.dataMax)) : existingFilter.currentMin;
        const updatedMax = newRange.max !== void 0 ? Math.max(existingFilter.dataMin, Math.min(newRange.max, existingFilter.dataMax)) : existingFilter.currentMax;
        const finalMin = Math.min(updatedMin, updatedMax);
        const finalMax = Math.max(updatedMin, updatedMax);
        return {
          ...prev,
          [filterKey]: {
            ...existingFilter,
            currentMin: finalMin,
            currentMax: finalMax
          }
        };
      }
      return prev;
    });
  }, []);
  const handleFilterChange = useCallback3((filterType, value) => {
    setFilters((prev) => ({ ...prev, [filterType]: value }));
  }, []);
  const resetAllFilters = useCallback3(() => {
    const resetFilters = { ...INITIAL_FILTERS_STATE };
    if (processedMoveData) {
      NODE_METRIC_KEYS.forEach((key) => {
        const range2 = processedMoveData.dataRangesForFilters[key];
        if (range2) {
          resetFilters[key] = {
            currentMin: range2.min,
            currentMax: range2.max,
            dataMin: range2.min,
            dataMax: range2.max
          };
        }
      });
    }
    setFilters(resetFilters);
  }, [processedMoveData]);
  const handleSortChange = useCallback3((key, order) => {
    setSortConfig({ key, order });
  }, []);
  const handleNodeHover = useCallback3((data) => {
    setTooltip(data);
  }, []);
  const handleNodeClick = useCallback3((nodeData) => {
    setSelectedNode(nodeData);
  }, []);
  const handleLayoutParamChange = useCallback3((lt, paramName, value) => {
    setLayoutParams((prev) => ({
      ...prev,
      [lt]: {
        ...prev[lt],
        [paramName]: value
      }
    }));
  }, []);
  const resetLayoutParams = useCallback3((layoutToReset) => {
    setLayoutParams((prev) => ({
      ...prev,
      [layoutToReset]: DEFAULT_LAYOUT_PARAMS[layoutToReset]
    }));
  }, []);
  const currentMoveSAN = useMemo3(() => {
    return rawData?.moves[currentMoveIndex]?.m || null;
  }, [rawData, currentMoveIndex]);
  return /* @__PURE__ */ jsxs19("div", { className: "flex flex-col h-screen bg-slate-200 text-slate-100", children: [
    /* @__PURE__ */ jsxs19("header", { className: "bg-slate-800 shadow-lg p-2 sm:p-3 flex items-center justify-between space-x-3 sm:space-x-4 z-40", children: [
      /* @__PURE__ */ jsxs19("div", { className: "flex items-center space-x-2 sm:space-x-3", children: [
        /* @__PURE__ */ jsx20(
          "button",
          {
            onClick: () => setIsLeftSidebarOpen(!isLeftSidebarOpen),
            className: "p-1.5 bg-slate-700 text-white rounded-md hover:bg-slate-600 transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-sky-400",
            title: isLeftSidebarOpen ? "Hide Sidebar" : "Show Sidebar",
            "aria-label": isLeftSidebarOpen ? "Hide Sidebar" : "Show Sidebar",
            "aria-controls": "left-sidebar-content",
            "aria-expanded": isLeftSidebarOpen,
            children: isLeftSidebarOpen ? /* @__PURE__ */ jsx20(ChevronLeftIcon2, { className: "w-5 h-5" }) : /* @__PURE__ */ jsx20(ChevronRightIcon2, { className: "w-5 h-5" })
          }
        ),
        /* @__PURE__ */ jsx20(DatabaseIcon, { className: "h-6 w-6 text-sky-400 flex-shrink-0" }),
        /* @__PURE__ */ jsx20("h1", { className: "text-base sm:text-lg font-semibold text-slate-100 truncate", title: "Interactive Chess Network Visualization Dashboard", children: "Chess Network Viz" })
      ] }),
      /* @__PURE__ */ jsx20("div", { className: "flex items-center space-x-2 sm:space-x-3 flex-grow justify-center max-w-lg", children: /* @__PURE__ */ jsx20(
        FileUpload_default,
        {
          onFileUpload: handleFileUpload,
          setLoading: setIsLoading,
          setError,
          currentDataSourceName: fileName
        }
      ) }),
      /* @__PURE__ */ jsx20("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsx20(
        MoveSelector_default,
        {
          currentMoveIndex,
          totalMoves: rawData?.moves.length || 0,
          currentMoveSAN,
          onMoveChange: setCurrentMoveIndex,
          disabled: appIsDisabled
        }
      ) })
    ] }),
    error && /* @__PURE__ */ jsxs19("div", { className: "p-2 bg-red-500 text-white text-xs text-center shadow-md z-30", role: "alert", children: [
      /* @__PURE__ */ jsx20("span", { className: "font-medium", children: "Error:" }),
      " ",
      error,
      /* @__PURE__ */ jsx20("button", { onClick: () => setError(null), className: "ml-3 text-red-100 hover:text-white font-bold text-sm", title: "Dismiss error message", children: "\u2715" })
    ] }),
    isLoading && /* @__PURE__ */ jsx20("div", { className: "absolute inset-x-0 top-0 h-1 bg-sky-500 animate-pulse z-50" }),
    /* @__PURE__ */ jsxs19("div", { className: "flex flex-1 overflow-hidden", children: [
      /* @__PURE__ */ jsx20(
        "aside",
        {
          id: "left-sidebar-content",
          className: `bg-slate-800 text-slate-100 shadow-lg flex flex-col 
                     border-slate-700 
                     transition-all duration-300 ease-in-out
                     ${isLeftSidebarOpen ? "overflow-y-auto custom-scrollbar border-r" : "overflow-y-hidden border-r-0"}`,
          style: {
            width: isLeftSidebarOpen ? "24rem" : "0px",
            // borderRightWidth is now handled by Tailwind classes 'border-r' or 'border-r-0'
            overflowX: "hidden"
          },
          "aria-hidden": !isLeftSidebarOpen,
          children: /* @__PURE__ */ jsxs19(
            "div",
            {
              className: `p-2 space-y-3 flex-grow transition-opacity duration-300 ease-in-out ${isLeftSidebarOpen ? "opacity-100" : "opacity-0 pointer-events-none"}`,
              children: [
                " ",
                /* @__PURE__ */ jsxs19(
                  CollapsibleSection,
                  {
                    title: "Graph Display & Data",
                    defaultOpen: true,
                    tooltip: "Select graph data scope, layout algorithm, and node coloring.",
                    children: [
                      /* @__PURE__ */ jsx20(GraphScopeSelector_default, { currentScope: currentGraphScope, onScopeChange: setCurrentGraphScope, disabled: appIsDisabled }),
                      /* @__PURE__ */ jsx20(LayoutSelector_default, { currentLayout: layoutType, onLayoutChange: setLayoutType, disabled: appIsDisabled })
                    ]
                  }
                ),
                /* @__PURE__ */ jsx20(
                  CollapsibleSection,
                  {
                    title: "Layout Parameters",
                    defaultOpen: false,
                    actionButton: /* @__PURE__ */ jsxs19(
                      "button",
                      {
                        onClick: () => resetLayoutParams(layoutType),
                        disabled: appIsDisabled,
                        className: "p-1 text-[10px] bg-slate-600 hover:bg-slate-500 text-slate-300 rounded shadow-sm disabled:opacity-50 flex items-center space-x-1",
                        title: `Reset ${layoutType.split("-").map((w) => w[0].toUpperCase() + w.slice(1)).join(" ")} parameters to defaults`,
                        children: [
                          /* @__PURE__ */ jsx20(RefreshIcon, { className: "w-3 h-3" }),
                          " ",
                          /* @__PURE__ */ jsx20("span", { children: "Reset" })
                        ]
                      }
                    ),
                    tooltip: `Adjust parameters for the current ${layoutType.replace("-", " ")} layout.`,
                    children: /* @__PURE__ */ jsx20(
                      LayoutParametersEditor_default,
                      {
                        currentLayout: layoutType,
                        layoutParams: layoutParams[layoutType],
                        onParamChange: handleLayoutParamChange,
                        disabled: appIsDisabled
                      }
                    )
                  }
                ),
                /* @__PURE__ */ jsxs19(
                  CollapsibleSection,
                  {
                    title: "Node Appearance & Order",
                    defaultOpen: true,
                    tooltip: "Configure how nodes are colored and sorted. Sorting affects some layouts.",
                    children: [
                      /* @__PURE__ */ jsx20(NodeColoringSelector_default, { currentColoringMetric: nodeColoringMetric, onColoringMetricChange: setNodeColoringMetric, disabled: appIsDisabled }),
                      isNodeColoringNumeric && /* @__PURE__ */ jsx20(
                        SequentialColorPaletteSelector_default,
                        {
                          currentPalette: sequentialColorPalette,
                          onPaletteChange: setSequentialColorPalette,
                          disabled: appIsDisabled || !isNodeColoringNumeric
                        }
                      ),
                      /* @__PURE__ */ jsx20(SortOptions_default, { sortConfig, onSortChange: handleSortChange, disabled: appIsDisabled })
                    ]
                  }
                ),
                /* @__PURE__ */ jsx20(
                  CollapsibleSection,
                  {
                    title: "Filtering Options",
                    defaultOpen: false,
                    actionButton: /* @__PURE__ */ jsxs19(
                      "button",
                      {
                        onClick: resetAllFilters,
                        disabled: appIsDisabled,
                        className: "p-1 text-[10px] bg-slate-600 hover:bg-slate-500 text-slate-300 rounded shadow-sm disabled:opacity-50 flex items-center space-x-1",
                        title: "Reset all node filters to their default (unfiltered) state.",
                        children: [
                          /* @__PURE__ */ jsx20(RefreshIcon, { className: "w-3 h-3" }),
                          " ",
                          /* @__PURE__ */ jsx20("span", { children: "Reset All" })
                        ]
                      }
                    ),
                    tooltip: "Filter nodes based on search, piece properties, structural attributes, or metric values.",
                    children: /* @__PURE__ */ jsx20(
                      FilterSidebar_default,
                      {
                        filters,
                        onFilterChange: handleFilterChange,
                        onNumericFilterChange: handleNumericFilterChange,
                        dataRanges: processedMoveData?.dataRangesForFilters || {},
                        processedNodes: processedMoveData?.nodes || [],
                        disabled: appIsDisabled,
                        isNodeSelected: !!selectedNode
                      }
                    )
                  }
                ),
                /* @__PURE__ */ jsx20("hr", { className: "my-4 border-slate-600/80" }),
                /* @__PURE__ */ jsx20(
                  CollapsibleSection,
                  {
                    title: "Selected Node Details",
                    defaultOpen: true,
                    tooltip: "Detailed metrics and information for the currently selected node in the graph.",
                    children: selectedNode ? /* @__PURE__ */ jsx20(SelectedNodeInfo_default, { nodeData: selectedNode }) : /* @__PURE__ */ jsx20("p", { className: "text-xs text-slate-400 italic p-1", children: "Click a node in the graph to see its details." })
                  }
                ),
                /* @__PURE__ */ jsx20(
                  CollapsibleSection,
                  {
                    title: "Aggregate Graph Statistics",
                    defaultOpen: false,
                    tooltip: "Overall statistics for the currently displayed graph scope and move.",
                    children: /* @__PURE__ */ jsx20(StatsDisplay_default, { stats: processedMoveData?.aggregateStats || null, disabled: appIsDisabled })
                  }
                ),
                /* @__PURE__ */ jsx20(
                  CollapsibleSection,
                  {
                    title: "Captured Pieces",
                    defaultOpen: false,
                    tooltip: "List of pieces captured by each side up to the current move.",
                    children: /* @__PURE__ */ jsx20(CapturedPieces_default, { capturedPieces, disabled: appIsDisabled })
                  }
                )
              ]
            }
          )
        }
      ),
      /* @__PURE__ */ jsxs19("div", { className: "flex-grow h-full relative", children: [
        /* @__PURE__ */ jsx20("main", { ref: visualizationPanelRef, className: "w-full h-full bg-white", children: processedMoveData && svgDimensions.width > 0 && svgDimensions.height > 0 ? /* @__PURE__ */ jsx20(
          NetworkGraph_default,
          {
            nodes: filteredSortedNodes,
            links: filteredLinks,
            layoutType,
            svgDimensions,
            onNodeHover: handleNodeHover,
            onNodeClick: handleNodeClick,
            selectedNodeId: selectedNode?.id || null,
            sortConfig,
            appIsDisabled,
            currentMoveIndex,
            currentGraphScope,
            nodeColoringMetric,
            sequentialColorPalette,
            dataRangesForFilters: processedMoveData.dataRangesForFilters,
            currentLayoutParams: layoutParams[layoutType]
          }
        ) : /* @__PURE__ */ jsx20("div", { className: "w-full h-full flex items-center justify-center bg-slate-50 text-slate-500", children: isLoading ? "Loading graph..." : rawData ? "Processing graph data..." : "Load a game data file to begin." }) }),
        processedMoveData && /* @__PURE__ */ jsx20(Legend_default, { nodes: filteredSortedNodes, nodeColoringMetric, dataRanges: processedMoveData.dataRangesForFilters, sequentialColorPalette }),
        tooltip && /* @__PURE__ */ jsx20(Tooltip_default, { ...tooltip })
      ] })
    ] })
  ] });
}

// index.tsx
import { jsx as jsx21 } from "react/jsx-runtime";
var rootElement = document.getElementById("root");
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}
var root = ReactDOM.createRoot(rootElement);
root.render(
  /* @__PURE__ */ jsx21(React20.StrictMode, { children: /* @__PURE__ */ jsx21(App, {}) })
);
