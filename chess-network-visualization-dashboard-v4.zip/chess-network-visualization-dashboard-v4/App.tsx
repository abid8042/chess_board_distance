
import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import * as d3 from 'd3';
import {
  RawChessData, Move, ProcessedGraphData, FiltersState, SortConfig,
  LayoutType, GraphScope, TooltipData, ProcessedNode, Piece,
  NODE_METRIC_KEYS, FilterMetricKey, NodeColoringMetricId, NodeNumericMetricKey,
  LayoutParamsState, LayoutParamKey, SequentialColorPaletteId
} from './types';
import { INITIAL_FILTERS_STATE, INITIAL_FILTER_VALUE_RANGE } from './constants';
import { DEFAULT_LAYOUT_PARAMS } from './src/constants';
import { processMoveData, applyFiltersAndSort, getCapturedPieces } from './utils/dataProcessor';
import { validateSchema } from './utils/schemaValidator';


import FileUpload from './components/ControlsPanel/FileUpload';
import MoveSelector from './components/ControlsPanel/MoveSelector';
import LayoutSelector from './components/ControlsPanel/LayoutSelector';
import GraphScopeSelector from './components/ControlsPanel/GraphScopeSelector';
import NodeColoringSelector from './components/ControlsPanel/NodeColoringSelector';
import SequentialColorPaletteSelector from './components/ControlsPanel/SequentialColorPaletteSelector';
import LayoutParametersEditor from './components/ControlsPanel/LayoutParametersEditor';
import FilterSidebar from './components/ControlsPanel/FilterSidebar';
import SortOptions from './components/ControlsPanel/SortOptions';
import NetworkGraph from './components/VisualizationPanel/NetworkGraph';
import Tooltip from './components/VisualizationPanel/Tooltip';
import Legend from './components/VisualizationPanel/Legend';
import StatsDisplay from './components/InfoPanel/StatsDisplay';
import CapturedPiecesDisplay from './components/InfoPanel/CapturedPieces';
import SelectedNodeInfo from './components/InfoPanel/SelectedNodeInfo';
import useResizeObserver from './hooks/useResizeObserver';

// Icons
const ChevronDownIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={`w-5 h-5 transition-transform duration-200 ${className}`} viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
    <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
  </svg>
);

const ChevronLeftIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={`w-5 h-5 ${className || ''}`} viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
    <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
  </svg>
);

const ChevronRightIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={`w-5 h-5 ${className || ''}`} viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
    <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
  </svg>
);

const RefreshIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={`w-4 h-4 ${className || ''}`} viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
        <path fillRule="evenodd" d="M15.322 10.707a5.001 5.001 0 00-7.59-4.152L6.455 7.83A3.001 3.001 0 0111.95 9.57l.975 1.013a1 1 0 01-1.438 1.392l-1.303-.782a3.001 3.001 0 01-3.583-2.508L2.85 5.505a1 1 0 011.04-1.634l2.692.976A5.001 5.001 0 0015.322 10.707zm-.827 3.289a1 1 0 01-1.04 1.634l-2.691-.976a5.001 5.001 0 00-7.772-5.638L4.678 9.293a1 1 0 011.438-1.392l1.303.782a3.001 3.001 0 013.583 2.508l3.755 2.176a1 1 0 01-.696 1.81z" clipRule="evenodd" />
    </svg>
);

const DatabaseIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={`w-5 h-5 ${className || ''}`} viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
    <path fillRule="evenodd" d="M3 5a2 2 0 012-2h10a2 2 0 012 2v2.28a1 1 0 01-.4.8L12 10.4V15a1 1 0 01-1 1H9a1 1 0 01-1-1v-4.6L3.4 8.08A1 1 0 013 7.28V5zm1 0v1.586l4.293 2.146a.5.5 0 00.414 0L13 6.586V5H4zm10.293 8.293a1 1 0 011.414 0l.001.001.001.001a1.002 1.002 0 010 1.413l-.001.001a1.002 1.002 0 01-1.414 0L12 13.414l-2.293 2.293a1 1 0 01-1.414-1.414l2.293-2.293L9.172 10.5H10V8H8v2.5a.5.5 0 00.146.354l2.5 2.5zM10 11.414l-1.293-1.293a1 1 0 010-1.414L10 7.414l1.293 1.293a1 1 0 010 1.414L10 11.414z" clipRule="evenodd" />
  </svg>
);


interface CollapsibleSectionProps {
  title: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
  className?: string;
  headerClassName?: string;
  contentClassName?: string;
  actionButton?: React.ReactNode;
  tooltip?: string;
}

const CollapsibleSection: React.FC<CollapsibleSectionProps> = ({ title, children, defaultOpen = true, className, headerClassName, contentClassName, actionButton, tooltip }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className={`bg-slate-700/80 rounded-lg shadow-md border border-slate-600/60 ${className || ''}`}>
      <div className={`flex justify-between items-center w-full p-2.5 text-left ${headerClassName || ''} ${isOpen ? 'rounded-t-lg' : 'rounded-lg'} hover:bg-slate-600/50 transition-colors duration-150`}>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex-grow flex items-center text-xs sm:text-sm font-semibold text-slate-100 focus:outline-none focus-visible:ring-1 focus-visible:ring-sky-300"
          aria-expanded={isOpen}
          title={tooltip || `Click to ${isOpen ? 'collapse' : 'expand'} the '${title}' section`}
        >
          <span>{title}</span>
          <ChevronDownIcon className={`ml-1.5 sm:ml-2 text-slate-300 ${isOpen ? 'transform rotate-180' : ''}`} />
        </button>
        {actionButton && <div className="flex-shrink-0 ml-2">{actionButton}</div>}
      </div>
      {isOpen && (
        <div className={`p-2.5 border-t border-slate-600/50 ${contentClassName || ''}`}>
          {children}
        </div>
      )}
    </div>
  );
};


export default function App() {
  const [rawData, setRawData] = useState<RawChessData | null>(null);
  const [currentMoveIndex, setCurrentMoveIndex] = useState<number>(0);
  const [currentGraphScope, setCurrentGraphScope] = useState<GraphScope>('combined');
  const [processedMoveData, setProcessedMoveData] = useState<ProcessedGraphData | null>(null);

  const [filters, setFilters] = useState<FiltersState>(INITIAL_FILTERS_STATE);
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: 'id', order: 'asc' });

  const [layoutType, setLayoutType] = useState<LayoutType>('force-directed');
  const [layoutParams, setLayoutParams] = useState<LayoutParamsState>(DEFAULT_LAYOUT_PARAMS);

  const [nodeColoringMetric, setNodeColoringMetric] = useState<NodeColoringMetricId>('default');
  const [sequentialColorPalette, setSequentialColorPalette] = useState<SequentialColorPaletteId>('viridis');

  const [tooltip, setTooltip] = useState<TooltipData | null>(null);
  const [selectedNode, setSelectedNode] = useState<ProcessedNode | null>(null);

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  
  const [isLeftSidebarOpen, setIsLeftSidebarOpen] = useState<boolean>(true);


  const visualizationPanelRef = useRef<HTMLDivElement>(null);
  const svgDimensions = useResizeObserver(visualizationPanelRef);

  const appIsDisabled = !rawData || isLoading;
  const isNodeColoringNumeric = useMemo(() =>
    NODE_METRIC_KEYS.includes(nodeColoringMetric as NodeNumericMetricKey),
  [nodeColoringMetric]);


  useEffect(() => {
    if (rawData && rawData.moves.length > 0) {
      const currentMoveExists = currentMoveIndex >= 0 && currentMoveIndex < rawData.moves.length;
      if (!currentMoveExists) {
        const newIndex = Math.max(0, Math.min(currentMoveIndex, rawData.moves.length - 1));
        setCurrentMoveIndex(newIndex);
        return;
      }

      const move = rawData.moves[currentMoveIndex];
      if (move) {
        setIsLoading(true);
        try {
          const newProcessedData = processMoveData(move, currentGraphScope);
          setProcessedMoveData(newProcessedData);

          setFilters(prevFilters => {
            const newFilters = { ...prevFilters };
            NODE_METRIC_KEYS.forEach(key => {
              const newRange = newProcessedData.dataRangesForFilters[key];
              const oldFilterValue = prevFilters[key];
              if (newRange && oldFilterValue && typeof oldFilterValue === 'object' && 'currentMin' in oldFilterValue) {
                const oldDataMin = oldFilterValue.dataMin;
                const oldDataMax = oldFilterValue.dataMax;
                let newCurrentMin = newRange.min;
                let newCurrentMax = newRange.max;
                if(oldDataMin !== newRange.min || oldDataMax !== newRange.max) { // If data range changed
                    // Reset current filter to new data range
                    newCurrentMin = newRange.min;
                    newCurrentMax = newRange.max;
                } else { // Data range is same, keep user's current selection but clamp it
                    newCurrentMin = Math.max(newRange.min, Math.min(oldFilterValue.currentMin, newRange.max));
                    newCurrentMax = Math.max(newRange.min, Math.min(oldFilterValue.currentMax, newRange.max));
                }

                newFilters[key] = {
                  currentMin: newCurrentMin,
                  currentMax: newCurrentMax,
                  dataMin: newRange.min,
                  dataMax: newRange.max,
                };
              } else if (newRange) { // Initialize if not present
                 newFilters[key] = {
                    currentMin: newRange.min,
                    currentMax: newRange.max,
                    dataMin: newRange.min,
                    dataMax: newRange.max,
                };
              }
            });
            return newFilters;
          });


        } catch (e) {
          console.error("Error processing move data:", e);
          setError(`Error processing move: ${(e as Error).message}`);
          setProcessedMoveData(null);
        } finally {
          setIsLoading(false);
        }
      }
    } else {
      setProcessedMoveData(null);
      setFilters(INITIAL_FILTERS_STATE); 
    }
    setSelectedNode(null); 
  }, [rawData, currentMoveIndex, currentGraphScope]);

  const handleFileUpload = useCallback((data: RawChessData | null, name: string) => {
    if (data) {
      setRawData(data);
      setCurrentMoveIndex(0);
      setCurrentGraphScope('combined');
      setLayoutType('force-directed');
      setLayoutParams(DEFAULT_LAYOUT_PARAMS);
      setNodeColoringMetric('default');
      setError(null);
      setFileName(name);
      setFilters(INITIAL_FILTERS_STATE); 
      setSelectedNode(null);
    } else {
      // Error handled by FileUpload, or no data (reset)
      setRawData(null);
      setProcessedMoveData(null);
      setFileName(null);
      // setError is likely already set by FileUpload
    }
  }, []);

  const { filteredSortedNodes, filteredLinks } = useMemo(() => {
    if (!processedMoveData) return { filteredSortedNodes: [], filteredLinks: [] };
    return applyFiltersAndSort(processedMoveData.nodes, processedMoveData.links, filters, sortConfig);
  }, [processedMoveData, filters, sortConfig]);

  const capturedPieces = useMemo(() => {
    if (!rawData) return [];
    return getCapturedPieces(rawData.moves, currentMoveIndex);
  }, [rawData, currentMoveIndex]);
  
  const handleNumericFilterChange = useCallback((filterKey: FilterMetricKey, newRange: { min?: number; max?: number }) => {
    setFilters(prev => {
      const existingFilter = prev[filterKey];
      if (typeof existingFilter === 'object' && 'currentMin' in existingFilter) {
        const updatedMin = newRange.min !== undefined ? Math.max(existingFilter.dataMin, Math.min(newRange.min, existingFilter.dataMax)) : existingFilter.currentMin;
        const updatedMax = newRange.max !== undefined ? Math.max(existingFilter.dataMin, Math.min(newRange.max, existingFilter.dataMax)) : existingFilter.currentMax;
        
        // Ensure min <= max
        const finalMin = Math.min(updatedMin, updatedMax);
        const finalMax = Math.max(updatedMin, updatedMax);

        return {
          ...prev,
          [filterKey]: {
            ...existingFilter,
            currentMin: finalMin,
            currentMax: finalMax,
          }
        };
      }
      return prev; 
    });
  }, []);

  const handleFilterChange = useCallback(<K extends keyof FiltersState>(filterType: K, value: FiltersState[K]) => {
    setFilters(prev => ({ ...prev, [filterType]: value }));
  }, []);

  const resetAllFilters = useCallback(() => {
    const resetFilters = { ...INITIAL_FILTERS_STATE };
    if (processedMoveData) {
      NODE_METRIC_KEYS.forEach(key => {
        const range = processedMoveData.dataRangesForFilters[key];
        if (range) {
          resetFilters[key] = {
            currentMin: range.min,
            currentMax: range.max,
            dataMin: range.min,
            dataMax: range.max,
          };
        }
      });
    }
    setFilters(resetFilters);
  }, [processedMoveData]);
  
  const handleSortChange = useCallback((key: string, order: 'asc' | 'desc') => {
    setSortConfig({ key, order });
  }, []);

  const handleNodeHover = useCallback((data: TooltipData | null) => {
    setTooltip(data);
  }, []);

  const handleNodeClick = useCallback((nodeData: ProcessedNode | null) => {
    setSelectedNode(nodeData);
  }, []);

  const handleLayoutParamChange = useCallback(<T extends LayoutType, K extends LayoutParamKey<T>>(
    lt: T, 
    paramName: K, 
    value: number
  ) => {
    setLayoutParams(prev => ({
      ...prev,
      [lt]: {
        ...prev[lt],
        [paramName]: value,
      }
    }));
  }, []);

  const resetLayoutParams = useCallback((layoutToReset: LayoutType) => {
    setLayoutParams(prev => ({
      ...prev,
      [layoutToReset]: DEFAULT_LAYOUT_PARAMS[layoutToReset]
    }));
  }, []);

  const currentMoveSAN = useMemo(() => {
    return rawData?.moves[currentMoveIndex]?.m || null;
  }, [rawData, currentMoveIndex]);


  return (
    <div className="flex flex-col h-screen bg-slate-200 text-slate-100">
      {/* Header */}
      <header className="bg-slate-800 shadow-lg p-2 sm:p-3 flex items-center justify-between space-x-3 sm:space-x-4 z-40">
        <div className="flex items-center space-x-2 sm:space-x-3">
          <button
            onClick={() => setIsLeftSidebarOpen(!isLeftSidebarOpen)}
            className="p-1.5 bg-slate-700 text-white rounded-md hover:bg-slate-600 transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-sky-400"
            title={isLeftSidebarOpen ? "Hide Sidebar" : "Show Sidebar"}
            aria-label={isLeftSidebarOpen ? "Hide Sidebar" : "Show Sidebar"}
            aria-controls="left-sidebar-content"
            aria-expanded={isLeftSidebarOpen}
          >
            {isLeftSidebarOpen ? <ChevronLeftIcon className="w-5 h-5" /> : <ChevronRightIcon className="w-5 h-5" />}
          </button>
          <DatabaseIcon className="h-6 w-6 text-sky-400 flex-shrink-0" />
          <h1 className="text-base sm:text-lg font-semibold text-slate-100 truncate" title="Interactive Chess Network Visualization Dashboard">
            Chess Network Viz
          </h1>
        </div>
        <div className="flex items-center space-x-2 sm:space-x-3 flex-grow justify-center max-w-lg">
            <FileUpload 
                onFileUpload={handleFileUpload} 
                setLoading={setIsLoading} 
                setError={setError} 
                currentDataSourceName={fileName}
            />
        </div>
        <div className="flex-shrink-0">
            <MoveSelector
                currentMoveIndex={currentMoveIndex}
                totalMoves={rawData?.moves.length || 0}
                currentMoveSAN={currentMoveSAN}
                onMoveChange={setCurrentMoveIndex}
                disabled={appIsDisabled}
            />
        </div>
      </header>

      {error && (
        <div className="p-2 bg-red-500 text-white text-xs text-center shadow-md z-30" role="alert">
          <span className="font-medium">Error:</span> {error}
          <button onClick={() => setError(null)} className="ml-3 text-red-100 hover:text-white font-bold text-sm" title="Dismiss error message">✕</button>
        </div>
      )}
      {isLoading && (
        <div className="absolute inset-x-0 top-0 h-1 bg-sky-500 animate-pulse z-50"></div>
      )}

      {/* Main Content Area */}
      <div className="flex flex-1 overflow-hidden">
        {/* Combined Left Sidebar (Controls + Info) */}
        <aside 
          id="left-sidebar-content"
          className={`bg-slate-800 text-slate-100 shadow-lg flex flex-col 
                     border-slate-700 
                     transition-all duration-300 ease-in-out
                     ${isLeftSidebarOpen ? 'overflow-y-auto custom-scrollbar border-r' : 'overflow-y-hidden border-r-0'}`}
          style={{ 
            width: isLeftSidebarOpen ? '24rem' : '0px',
            // borderRightWidth is now handled by Tailwind classes 'border-r' or 'border-r-0'
            overflowX: 'hidden', 
          }} 
          aria-hidden={!isLeftSidebarOpen}
        >
          <div 
            className={`p-2 space-y-3 flex-grow transition-opacity duration-300 ease-in-out ${isLeftSidebarOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
          > {/* This div will contain all sections and allow scrolling */}
            {/* Controls Sections */}
            <CollapsibleSection 
                title="Graph Display & Data" 
                defaultOpen={true} 
                tooltip="Select graph data scope, layout algorithm, and node coloring."
            >
                <GraphScopeSelector currentScope={currentGraphScope} onScopeChange={setCurrentGraphScope} disabled={appIsDisabled} />
                <LayoutSelector currentLayout={layoutType} onLayoutChange={setLayoutType} disabled={appIsDisabled} />
            </CollapsibleSection>

            <CollapsibleSection 
                title="Layout Parameters" 
                defaultOpen={false} 
                actionButton={
                    <button
                        onClick={() => resetLayoutParams(layoutType)}
                        disabled={appIsDisabled}
                        className="p-1 text-[10px] bg-slate-600 hover:bg-slate-500 text-slate-300 rounded shadow-sm disabled:opacity-50 flex items-center space-x-1"
                        title={`Reset ${layoutType.split('-').map(w=>w[0].toUpperCase()+w.slice(1)).join(' ')} parameters to defaults`}
                    >
                        <RefreshIcon className="w-3 h-3" /> <span>Reset</span>
                    </button>
                }
                tooltip={`Adjust parameters for the current ${layoutType.replace('-', ' ')} layout.`}
            >
              <LayoutParametersEditor
                currentLayout={layoutType}
                layoutParams={layoutParams[layoutType]}
                onParamChange={handleLayoutParamChange}
                disabled={appIsDisabled}
              />
            </CollapsibleSection>
            
            <CollapsibleSection 
                title="Node Appearance & Order" 
                defaultOpen={true}
                tooltip="Configure how nodes are colored and sorted. Sorting affects some layouts."
            >
                <NodeColoringSelector currentColoringMetric={nodeColoringMetric} onColoringMetricChange={setNodeColoringMetric} disabled={appIsDisabled} />
                {isNodeColoringNumeric && (
                    <SequentialColorPaletteSelector 
                        currentPalette={sequentialColorPalette} 
                        onPaletteChange={setSequentialColorPalette}
                        disabled={appIsDisabled || !isNodeColoringNumeric} 
                    />
                )}
                <SortOptions sortConfig={sortConfig} onSortChange={handleSortChange} disabled={appIsDisabled} />
            </CollapsibleSection>

            <CollapsibleSection 
                title="Filtering Options" 
                defaultOpen={false} 
                actionButton={
                     <button
                        onClick={resetAllFilters}
                        disabled={appIsDisabled}
                        className="p-1 text-[10px] bg-slate-600 hover:bg-slate-500 text-slate-300 rounded shadow-sm disabled:opacity-50 flex items-center space-x-1"
                        title="Reset all node filters to their default (unfiltered) state."
                    >
                         <RefreshIcon className="w-3 h-3" /> <span>Reset All</span>
                    </button>
                }
                tooltip="Filter nodes based on search, piece properties, structural attributes, or metric values."
            >
                <FilterSidebar
                    filters={filters}
                    onFilterChange={handleFilterChange}
                    onNumericFilterChange={handleNumericFilterChange}
                    dataRanges={processedMoveData?.dataRangesForFilters || {}}
                    processedNodes={processedMoveData?.nodes || []}
                    disabled={appIsDisabled}
                    isNodeSelected={!!selectedNode}
                />
            </CollapsibleSection>

            {/* Divider (optional, can be an <hr /> or just margin) */}
            <hr className="my-4 border-slate-600/80" />

            {/* Info Sections */}
            <CollapsibleSection 
                title="Selected Node Details" 
                defaultOpen={true}
                tooltip="Detailed metrics and information for the currently selected node in the graph."
            >
                {selectedNode ? <SelectedNodeInfo nodeData={selectedNode} /> : <p className="text-xs text-slate-400 italic p-1">Click a node in the graph to see its details.</p>}
            </CollapsibleSection>
            <CollapsibleSection 
                title="Aggregate Graph Statistics" 
                defaultOpen={false}
                tooltip="Overall statistics for the currently displayed graph scope and move."
            >
                <StatsDisplay stats={processedMoveData?.aggregateStats || null} disabled={appIsDisabled} />
            </CollapsibleSection>
            <CollapsibleSection 
                title="Captured Pieces" 
                defaultOpen={false}
                tooltip="List of pieces captured by each side up to the current move."
            >
                <CapturedPiecesDisplay capturedPieces={capturedPieces} disabled={appIsDisabled} />
            </CollapsibleSection>
          </div>
        </aside>

        {/* Visualization Panel */}
        <div className="flex-grow h-full relative">
          <main ref={visualizationPanelRef} className="w-full h-full bg-white">
            {processedMoveData && svgDimensions.width > 0 && svgDimensions.height > 0 ? (
              <NetworkGraph
                nodes={filteredSortedNodes}
                links={filteredLinks}
                layoutType={layoutType}
                svgDimensions={svgDimensions}
                onNodeHover={handleNodeHover}
                onNodeClick={handleNodeClick}
                selectedNodeId={selectedNode?.id || null}
                sortConfig={sortConfig}
                appIsDisabled={appIsDisabled}
                currentMoveIndex={currentMoveIndex}
                currentGraphScope={currentGraphScope}
                nodeColoringMetric={nodeColoringMetric}
                sequentialColorPalette={sequentialColorPalette}
                dataRangesForFilters={processedMoveData.dataRangesForFilters}
                currentLayoutParams={layoutParams[layoutType]}
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-slate-50 text-slate-500">
                {isLoading ? 'Loading graph...' : (rawData ? 'Processing graph data...' : 'Load a game data file to begin.')}
              </div>
            )}
          </main>
          {processedMoveData && <Legend nodes={filteredSortedNodes} nodeColoringMetric={nodeColoringMetric} dataRanges={processedMoveData.dataRangesForFilters} sequentialColorPalette={sequentialColorPalette} />}
          {tooltip && <Tooltip {...tooltip} />}
          
        </div>
      </div>
    </div>
  );
}
