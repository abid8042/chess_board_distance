
// From JSON Schema
export interface Metadata {
  schema_version: string;
  description: string;
}

export interface Piece {
  id: string;
  t: string; // type: "pawn", "knight", etc. (lowercase)
  c: string; // color: "white" or "black"
  sq: string;
  st: string; // status: "active", "inactive", "captured", "promoted"
  mc: number; // move created
  cap: number | null; // move captured
}

export interface AggregateStats {
  fiedler_value: number | null;
  out_diameter: number; // Schema says int, sample was float. Using number.
  in_diameter: number;  // Schema says int, sample was float. Using number.
  in_degree_avg: number;
  in_degree_var: number;
  out_degree_avg: number;
  out_degree_var: number;
  in_betweenness_avg: number;
  in_betweenness_var: number;
  out_betweenness_avg: number;
  out_betweenness_var: number;
  in_closeness_avg: number;
  in_closeness_var: number;
  out_closeness_avg: number;
  out_closeness_var: number;
  modularity: number;
  community_count: number;
  clustering: number;
  size_entropy: number;
}

export interface ComponentData {
  index: number;
  size: number;
  fiedler: number | null;
  out_diameter: number;
  in_diameter: number;
  out_diameter_paths: [string, string][];
  in_diameter_paths: [string, string][];
  modularity: number;
  community_count: number;
  clustering: number;
  nodes: string[];
  // New centrality averages and variances for components (as per schema)
  in_degree_centrality_avg: number;
  in_degree_centrality_var: number;
  out_degree_centrality_avg: number;
  out_degree_centrality_var: number;
  in_betweenness_centrality_avg: number;
  in_betweenness_centrality_var: number;
  out_betweenness_centrality_avg: number;
  out_betweenness_centrality_var: number;
  in_closeness_centrality_avg: number;
  in_closeness_centrality_var: number;
  out_closeness_centrality_avg: number;
  out_closeness_centrality_var: number;
}

export interface NodeData {
  id: string; // square name e.g. "a1"
  position: string; // e.g. "a1" (node key)
  has_piece: boolean;
  piece_symbol: string | null; 
  piece_color: string | null; // "white" or "black"
  piece_type: string | number | null; // "Pawn", "Knight" etc. (Capitalized string name) OR number from sample data

  // Centrality values
  in_degree_centrality: number;
  out_degree_centrality: number;
  in_betweenness_centrality: number;
  out_betweenness_centrality: number;
  in_closeness_centrality: number;
  out_closeness_centrality: number;

  // Global variances (now on node for context, as per schema)
  in_degree_centrality_variance: number;
  out_degree_centrality_variance: number;
  in_betweenness_centrality_variance: number;
  out_betweenness_centrality_variance: number;
  in_closeness_centrality_variance: number;
  out_closeness_centrality_variance: number;

  // Component info
  community_id: number;
  component_id: number;

  // Component averages for centralities
  in_degree_component_avg: number;
  out_degree_component_avg: number;
  in_betweenness_component_avg: number;
  out_betweenness_component_avg: number;
  in_closeness_component_avg: number;
  out_closeness_component_avg: number;

  // Component variances for centralities
  in_degree_component_var: number;
  out_degree_component_var: number;
  in_betweenness_component_var: number;
  out_betweenness_component_var: number;
  in_closeness_component_var: number;
  out_closeness_component_var: number;

  // Deviations from component means
  in_degree_deviation: number;
  out_degree_deviation: number;
  in_betweenness_deviation: number;
  out_betweenness_deviation: number;
  in_closeness_deviation: number;
  out_closeness_deviation: number;
}

export interface LinkData {
  source: string; // node ID
  target: string; // node ID
  weight: number;
  piece_symbol: string | null;
  piece_color: string | null;
  piece_type: string | number | null; // "Pawn", "Knight" etc. (Capitalized string name) OR number from sample data
}

export interface GraphScopeData {
  agg: AggregateStats;
  cmp: ComponentData[];
  nds: NodeData[];
  lks: LinkData[];
}

export interface Move {
  n: number;
  m: string;
  f: string;
  p: Piece[];
  g: {
    combined: GraphScopeData;
    white: GraphScopeData;
    black: GraphScopeData;
  };
}

export interface RawChessData {
  metadata: Metadata;
  moves: Move[];
}

// Processed/Derived Types
// ProcessedNode.piece_type will be string | null after conversion in dataProcessor
export interface ProcessedNode extends Omit<NodeData, 'piece_type'> {
  piece_type: string | null; // Ensure this is string | null for consistent downstream use
  groupTag: string; // "${component_id}-${community_id}"
  original_piece_id?: string; 
  piece_type_name?: string; // Derived, e.g. "Pawn", "Knight" 
  x?: number;
  y?: number;
  fx?: number | null;
  fy?: number | null;
  targetRadius?: number; // For radial layout
}

// ProcessedLink.piece_type will be string | null after conversion in dataProcessor
export interface ProcessedLink { 
  source: ProcessedNode | string; 
  target: ProcessedNode | string; 
  weight: number;
  piece_symbol: string | null;
  piece_color: string | null;
  piece_type: string | null; // Ensure this is string | null for consistent downstream use
}

export interface CommunityGroup {
  groupTag: string;
  nodes: ProcessedNode[];
}

export interface DataRangesForFilters {
  [metricKey: string]: { min: number; max: number };
}

export interface ProcessedGraphData {
  nodes: ProcessedNode[];
  links: ProcessedLink[];
  communityGroups: CommunityGroup[];
  aggregateStats: AggregateStats;
  dataRangesForFilters: DataRangesForFilters;
}

export interface FilterValueRange {
  currentMin: number;
  currentMax: number;
  dataMin: number;
  dataMax: number;
}

export const NODE_METRIC_KEYS = [
  'in_degree_centrality', 'out_degree_centrality',
  'in_betweenness_centrality', 'out_betweenness_centrality',
  'in_closeness_centrality', 'out_closeness_centrality',
  'in_degree_centrality_variance', 'out_degree_centrality_variance',
  'in_betweenness_centrality_variance', 'out_betweenness_centrality_variance',
  'in_closeness_centrality_variance', 'out_closeness_centrality_variance',
  'in_degree_component_avg', 'out_degree_component_avg',
  'in_betweenness_component_avg', 'out_betweenness_component_avg',
  'in_closeness_component_avg', 'out_closeness_component_avg',
  'in_degree_component_var', 'out_degree_component_var',
  'in_betweenness_component_var', 'out_betweenness_component_var',
  'in_closeness_component_var', 'out_closeness_component_var',
  'in_degree_deviation', 'out_degree_deviation',
  'in_betweenness_deviation', 'out_betweenness_deviation',
  'in_closeness_deviation', 'out_closeness_deviation',
] as const;

export type NodeNumericMetricKey = typeof NODE_METRIC_KEYS[number];

export interface FiltersStateBase {
  searchTerm: string;
  pieceTypes: string[]; 
  pieceColor: string | null; 
  componentIds: number[];
  communityIds: number[];
}

export type FiltersState = FiltersStateBase & {
  [K in NodeNumericMetricKey]: FilterValueRange;
};


export interface SortConfig {
  key: string; 
  order: 'asc' | 'desc';
}

export interface TooltipData {
  content: string | React.ReactNode;
  x: number;
  y: number;
  visible: boolean;
}

export type LayoutType = 'force-directed' | 'radial' | 'spiral';
export type GraphScope = 'combined' | 'white' | 'black';

export type FilterMetricKey = NodeNumericMetricKey;

export const PIECE_TYPE_NAMES: { [id: string]: string } = {
  "pawn": "Pawn", "knight": "Knight", "bishop": "Bishop",
  "rook": "Rook", "queen": "Queen", "king": "King"
};

export const NUMERIC_PIECE_TYPE_TO_NAME_MAP: { [key: number]: string } = {
  1: "Pawn",
  2: "Knight",
  3: "Bishop",
  4: "Rook",
  5: "Queen",
  6: "King",
};

export const AVAILABLE_PIECE_TYPES: string[] = ["Pawn", "Knight", "Bishop", "Rook", "Queen", "King"];


export const PIECE_COLOR_MAP: { [key: string]: string } = {
  'white': "White",
  'black': "Black"
};

export type NodeColoringMetricId = 'default' | 'component_id_color' | 'community_id_color' | NodeNumericMetricKey;

export type SequentialColorPaletteId = 
  | 'viridis' 
  | 'magma' 
  | 'plasma' 
  | 'cividis' 
  | 'cool' 
  | 'blues';

export interface ForceDirectedLayoutParams {
  linkDistance: number;
  linkStrength: number;
  chargeStrength: number;
  collideStrength: number;
  centerStrength: number; 
  componentCenterStrength: number; 
}

export interface RadialLayoutParams {
  chargeStrength: number;
  linkDistanceFactor: number;
  linkStrengthFactor: number;
  radialStrength: number; 
  ringMinRadiusFactor: number; 
  maxOuterRadiusFactor: number; 
}

export interface SpiralLayoutParams {
  coils: number;
  maxRadiusMargin: number; 
  linkDistance: number;
  linkStrength: number;
}

export interface LayoutParamsState {
  'force-directed': ForceDirectedLayoutParams;
  'radial': RadialLayoutParams;
  'spiral': SpiralLayoutParams;
}

export type LayoutParamKey<T extends LayoutType> = keyof LayoutParamsState[T];

export interface LayoutParameterUIDefinition<T extends LayoutType, K extends LayoutParamKey<T>> {
  key: K;
  label: string;
  type: 'slider' | 'number';
  min?: number;
  max?: number;
  step?: number;
  description?: string;
}

export type SpecificLayoutParameterUIDefinitions<T extends LayoutType> = Array<LayoutParameterUIDefinition<T, LayoutParamKey<T>>>;

export interface AllLayoutParameterUIDefinitions {
  'force-directed': SpecificLayoutParameterUIDefinitions<'force-directed'>;
  'radial': SpecificLayoutParameterUIDefinitions<'radial'>;
  'spiral': SpecificLayoutParameterUIDefinitions<'spiral'>;
}
