=== JSON Output Schema ===
metadata: {
    schema_version: string,       # e.g. "2.2"
    description:     string       # human-readable summary
}

moves: [                         # array of per-move objects
  {
    n:    integer,               # move_number (0=start)
    m:    string,                # SAN move or "start"
    f:    string,                # FEN of board state
    p: [                         # piece_states (flattened)
      {
        id:  string,             # "p1", "p2", ...
        t:   string,             # "pawn","knight",...
        c:   string,             # "white" or "black"
        sq:  string,             # square name, e.g. "e4"
        st:  string,             # "active","inactive","captured","promoted"
        mc:  integer,            # move index when created
        cap: integer|null        # move index when captured
      }, ...
    ],
    g: {                         # graph_data bundles per color
      combined: {                # same keys for white & black
        agg: {                   # aggregate-level metrics (expanded)
            fiedler_value:    float|null,
            out_diameter:     int,
            in_diameter:      int,
            in_degree_avg:    float,
            in_degree_var:    float,
            out_degree_avg:   float,
            out_degree_var:   float,
            in_betweenness_avg:   float,
            in_betweenness_var:   float,
            out_betweenness_avg:  float,
            out_betweenness_var:  float,
            in_closeness_avg:     float,
            in_closeness_var:     float,
            out_closeness_avg:    float,
            out_closeness_var:    float,
            modularity:       float,
            community_count:  int,
            clustering:       float,
            size_entropy:     float
        },
        cmp: [                   # component-level array (expanded)
          {
            index:           int,
            size:            int,
            fiedler:         float|null,
            out_diameter:    int,
            in_diameter:     int,
            out_diameter_paths: [[string,string],...],
            in_diameter_paths:  [[string,string],...],
            modularity:      float,
            community_count: int,
            clustering:      float,
            nodes:           [string,...],
            # All centrality averages and variances
            in_degree_centrality_avg:    float,
            in_degree_centrality_var:    float,
            out_degree_centrality_avg:   float,
            out_degree_centrality_var:   float,
            in_betweenness_centrality_avg:   float,
            in_betweenness_centrality_var:   float,
            out_betweenness_centrality_avg:  float,
            out_betweenness_centrality_var:  float,
            in_closeness_centrality_avg:     float,
            in_closeness_centrality_var:     float,
            out_closeness_centrality_avg:    float,
            out_closeness_centrality_var:    float
          }, ...
        ],
        nds: [                   # node-level list (expanded)
          {
            id:                    string,
            position:              string,      # node key
            has_piece:             bool,
            piece_color:           string|null,
            piece_type:            string|null,
            # All 6 centrality values
            in_degree_centrality:  float,
            out_degree_centrality: float,
            in_betweenness_centrality:  float,
            out_betweenness_centrality: float,
            in_closeness_centrality:    float,
            out_closeness_centrality:   float,
            # Global variances for all centralities
            in_degree_centrality_variance:      float,
            out_degree_centrality_variance:     float,
            in_betweenness_centrality_variance: float,
            out_betweenness_centrality_variance:float,
            in_closeness_centrality_variance:   float,
            out_closeness_centrality_variance:  float,
            # Component info
            community_id:         int,
            component_id:         int,
            # Component averages for all centralities
            in_degree_component_avg:     float,
            out_degree_component_avg:    float,
            in_betweenness_component_avg:    float,
            out_betweenness_component_avg:   float,
            in_closeness_component_avg:      float,
            out_closeness_component_avg:     float,
            # Component variances for all centralities
            in_degree_component_var:     float,
            out_degree_component_var:    float,
            in_betweenness_component_var:    float,
            out_betweenness_component_var:   float,
            in_closeness_component_var:      float,
            out_closeness_component_var:     float,
            # Deviations from component means
            in_degree_deviation:         float,
            out_degree_deviation:        float,
            in_betweenness_deviation:    float,
            out_betweenness_deviation:   float,
            in_closeness_deviation:      float,
            out_closeness_deviation:     float
          }, ...
        ],
        lks: [                   # edge-level list
          {
            source:      string,   # node id
            target:      string,   # node id
            weight:      float,
            piece_symbol: string|null,
            piece_color:  string|null,
            piece_type:   string|null
          }, ...
        ]
      },
      white: { /* same as combined */ },
      black: { /* same as combined */ }
    }
  }, ...
]
"""