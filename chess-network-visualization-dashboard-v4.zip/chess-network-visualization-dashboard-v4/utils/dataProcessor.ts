
import { RawChessData, Move, GraphScope, ProcessedNode, ProcessedLink, CommunityGroup, ProcessedGraphData, NodeData, LinkData, Piece, DataRangesForFilters, NODE_METRIC_KEYS, FiltersState, SortConfig, NodeNumericMetricKey, NUMERIC_PIECE_TYPE_TO_NAME_MAP } from '../types';

// Helper to get piece symbol from type (e.g., "pawn") and color ("white")
function getPieceSymbol(type: string | null, color: string | null): string | null {
    if (!type || !color) return null;
    const lowerType = type.toLowerCase();
    const typeInitial = lowerType === "knight" ? "N" : type[0]?.toUpperCase();
    if (!typeInitial) return null;

    let symbol = color.toLowerCase() === 'white' ? typeInitial.toUpperCase() : typeInitial.toLowerCase();
    if (lowerType === "knight") {
        symbol = color.toLowerCase() === 'white' ? "N" : "n";
    }
    return symbol;
}


export function processMoveData(moveData: Move, graphScope: GraphScope): ProcessedGraphData {
  const targetGraph = moveData.g[graphScope];
  const dataRangesForFilters: DataRangesForFilters = {};

  NODE_METRIC_KEYS.forEach(key => {
    dataRangesForFilters[key] = { min: Infinity, max: -Infinity };
  });
  
  const pieceMapBySquare = new Map<string, Piece>();
  moveData.p.forEach(p => {
    if (p.st === "active") { 
        pieceMapBySquare.set(p.sq, p);
    }
  });

  const processedNodes: ProcessedNode[] = targetGraph.nds.map((nd: NodeData) => {
    let resolvedPieceTypeString: string | null = null;
    if (typeof nd.piece_type === 'number') {
      resolvedPieceTypeString = NUMERIC_PIECE_TYPE_TO_NAME_MAP[nd.piece_type] || null;
    } else if (typeof nd.piece_type === 'string') {
      resolvedPieceTypeString = nd.piece_type;
    }

    const { piece_type: originalPieceType, ...restOfNd } = nd;

    const augmentedNode: ProcessedNode = {
      ...restOfNd,
      piece_type: resolvedPieceTypeString, // Store the resolved string version
      groupTag: `${nd.component_id}-${nd.community_id}`,
    };
    
    if (augmentedNode.has_piece) {
        const pieceOnSquare = pieceMapBySquare.get(nd.id);
        if (pieceOnSquare) {
            augmentedNode.original_piece_id = pieceOnSquare.id;
            // Derive piece_type_name from pieceOnSquare.t (e.g. "pawn" -> "Pawn")
            augmentedNode.piece_type_name = pieceOnSquare.t.charAt(0).toUpperCase() + pieceOnSquare.t.slice(1);
            if (pieceOnSquare.t === "knight") augmentedNode.piece_type_name = "Knight";

            // Ensure augmentedNode.piece_type also has the correct string name if it wasn't resolved from nd.piece_type
            if (!augmentedNode.piece_type && augmentedNode.piece_type_name) {
                augmentedNode.piece_type = augmentedNode.piece_type_name;
            }
            
            // If piece_symbol is missing from NodeData, derive it
            if (augmentedNode.piece_symbol === null || augmentedNode.piece_symbol === undefined) {
                 augmentedNode.piece_symbol = getPieceSymbol(augmentedNode.piece_type_name, pieceOnSquare.c);
            }
            // If piece_color is missing from NodeData, use from Piece object
            if (!augmentedNode.piece_color && pieceOnSquare.c) {
                augmentedNode.piece_color = pieceOnSquare.c;
            }

        } else if (augmentedNode.piece_type) { // If no piece in 'p' array but nd.piece_type (now resolved string) exists
           augmentedNode.piece_type_name = augmentedNode.piece_type; // Use the resolved string name
           if (!augmentedNode.piece_symbol && augmentedNode.piece_color) { // nd.piece_color is from original NodeData
               augmentedNode.piece_symbol = getPieceSymbol(augmentedNode.piece_type, augmentedNode.piece_color);
           }
        }
    }


    NODE_METRIC_KEYS.forEach(key => {
      const value = (augmentedNode as any)[key];
      if (typeof value === 'number' && !isNaN(value)) {
        if (value < dataRangesForFilters[key].min) dataRangesForFilters[key].min = value;
        if (value > dataRangesForFilters[key].max) dataRangesForFilters[key].max = value;
      }
    });
    return augmentedNode;
  });
  
  NODE_METRIC_KEYS.forEach(key => {
    if (dataRangesForFilters[key].min === Infinity) dataRangesForFilters[key].min = 0;
    if (dataRangesForFilters[key].max === -Infinity) dataRangesForFilters[key].max = 0;
    if (dataRangesForFilters[key].min > dataRangesForFilters[key].max) { // Should not happen if init correctly
        if (dataRangesForFilters[key].min === dataRangesForFilters[key].max) { // Single value
            dataRangesForFilters[key].min = Math.max(0, dataRangesForFilters[key].min - 0.5); // Expand range slightly
            dataRangesForFilters[key].max = dataRangesForFilters[key].max + 0.5;
            if (dataRangesForFilters[key].min === dataRangesForFilters[key].max && dataRangesForFilters[key].min === 0) { // Case [0,0] -> [-0.5, 0.5] then fix to [0,1]
                 dataRangesForFilters[key].max = 1; 
            }
        } else { // Should be caught by Infinity/-Infinity, but as a fallback
             [dataRangesForFilters[key].min, dataRangesForFilters[key].max] = [dataRangesForFilters[key].max, dataRangesForFilters[key].min];
        }
    }
  });

  const processedLinks: ProcessedLink[] = targetGraph.lks.map((lk: LinkData) => {
    let finalLinkPieceType: string | null = null;
    if (typeof lk.piece_type === 'number') {
      finalLinkPieceType = NUMERIC_PIECE_TYPE_TO_NAME_MAP[lk.piece_type] || null;
    } else if (typeof lk.piece_type === 'string') {
      finalLinkPieceType = lk.piece_type;
    }
    return {
      source: lk.source,
      target: lk.target,
      weight: lk.weight,
      piece_symbol: lk.piece_symbol,
      piece_color: lk.piece_color,
      piece_type: finalLinkPieceType, // Ensure ProcessedLink.piece_type is string | null
    };
  });

  const communityGroupsMap = new Map<string, ProcessedNode[]>();
  processedNodes.forEach(node => {
    if (!communityGroupsMap.has(node.groupTag)) {
      communityGroupsMap.set(node.groupTag, []);
    }
    communityGroupsMap.get(node.groupTag)!.push(node);
  });

  const communityGroups: CommunityGroup[] = Array.from(communityGroupsMap.entries()).map(([tag, nodes]) => ({
    groupTag: tag,
    nodes: nodes,
  }));
  
  return {
    nodes: processedNodes,
    links: processedLinks,
    communityGroups,
    aggregateStats: targetGraph.agg,
    dataRangesForFilters,
  };
}

export function applyFiltersAndSort(
  nodes: ProcessedNode[],
  links: ProcessedLink[],
  filters: FiltersState, 
  sortConfig: SortConfig 
): { filteredSortedNodes: ProcessedNode[]; filteredLinks: ProcessedLink[] } {
  
  let filteredNodes = nodes.filter(node => {
    if (filters.searchTerm) {
      const term = filters.searchTerm.toLowerCase();
      const nodeIdMatch = node.id.toLowerCase().includes(term);
      const pieceSymbolMatch = node.has_piece && node.piece_symbol && node.piece_symbol.toLowerCase().includes(term);
      if (!nodeIdMatch && !pieceSymbolMatch) return false;
    }

    // Piece Type Filter (node.piece_type is now consistently string | null in ProcessedNode)
    if (filters.pieceTypes.length > 0) {
      if (!node.has_piece || !node.piece_type || !filters.pieceTypes.includes(node.piece_type)) {
        return false;
      }
    }
    
    if (filters.pieceColor) {
      if (!node.has_piece || node.piece_color !== filters.pieceColor) {
        return false;
      }
    }

    if (filters.componentIds.length > 0) {
      if (!filters.componentIds.includes(node.component_id)) {
        return false;
      }
    }

    if (filters.communityIds.length > 0) {
      if (!filters.communityIds.includes(node.community_id)) {
        return false;
      }
    }
    
    for (const key of NODE_METRIC_KEYS) {
        const filterKeyTyped = key as NodeNumericMetricKey; 
        const filterRange = filters[filterKeyTyped]; 
        
        if (filterRange && typeof filterRange === 'object' && 'currentMin' in filterRange && 'currentMax' in filterRange) {
            const nodeValue = (node as any)[filterKeyTyped];
            if (typeof nodeValue === 'number' && !isNaN(nodeValue)) {
                if (nodeValue < filterRange.currentMin || nodeValue > filterRange.currentMax) {
                    return false;
                }
            } else if (filterRange.currentMin > filterRange.dataMin || filterRange.currentMax < filterRange.dataMax) {
                // If nodeValue is not a number (e.g. null/undefined for some metrics not present on all nodes)
                // and the filter is active (not at full data range), then filter out this node.
                return false;
            }
        }
    }
    return true;
  });

  const { key: sortKey, order: sortOrder } = sortConfig;
  const filteredSortedNodes = [...filteredNodes].sort((a, b) => {
    const valA = (a as any)[sortKey];
    const valB = (b as any)[sortKey];

    if (valA === null || valA === undefined) return sortOrder === 'asc' ? -1 : 1;
    if (valB === null || valB === undefined) return sortOrder === 'asc' ? 1 : -1;
    
    if (typeof valA === 'string' && typeof valB === 'string') {
      return sortOrder === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
    }
    if (typeof valA === 'number' && typeof valB === 'number') {
      return sortOrder === 'asc' ? valA - valB : valB - valA;
    }
    return 0;
  });

  const filteredNodeIds = new Set(filteredSortedNodes.map(n => n.id));
  const filteredLinks = links.filter(link => {
    const sourceId = typeof link.source === 'string' ? link.source : (link.source as ProcessedNode).id;
    const targetId = typeof link.target === 'string' ? link.target : (link.target as ProcessedNode).id;
    return filteredNodeIds.has(sourceId) && filteredNodeIds.has(targetId);
  });

  return { filteredSortedNodes, filteredLinks };
}


export function getCapturedPieces(allMoves: Move[], currentMoveIndex: number): Piece[] {
    if (!allMoves || allMoves.length === 0) return [];
    
    const relevantPieces = new Map<string, Piece>();

    for (let i = 0; i <= Math.min(currentMoveIndex, allMoves.length - 1); i++) {
        const move = allMoves[i];
        move.p.forEach(piece => {
            relevantPieces.set(piece.id, {...piece}); // Store a copy to avoid mutation issues if pieces are re-used across moves 
        });
    }
    
    return Array.from(relevantPieces.values()).filter(p => 
        p.st === 'captured' && p.cap !== null && p.cap <= currentMoveIndex // p.cap should be the move index it was captured
    ).sort((a,b) => (a.cap ?? 0) - (b.cap ?? 0)); // Sort by capture move index
}

